import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';
import { SYSTEM_PROMPT } from '@/lib/ai/system-prompt';
import { getMCPManager } from '@/lib/mcp/client';

const anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY || '',
});

let mcpInitialized = false;

async function ensureMCPInitialized() {
    if (!mcpInitialized) {
        try {
            const manager = getMCPManager();
            await manager.initialize();
            mcpInitialized = true;
            console.log('[Chat] MCP initialized, servers:', manager.getConnectedServerNames());
        } catch (err) {
            console.warn('[Chat] MCP initialization failed (will work without tools):', err);
            mcpInitialized = true; // Don't retry on subsequent requests
        }
    }
}

export async function POST(req: NextRequest) {
    try {
        const { message, history = [] } = await req.json();

        if (!message || typeof message !== 'string') {
            return NextResponse.json({ error: 'Message is required' }, { status: 400 });
        }

        // Initialize MCP servers (lazy)
        await ensureMCPInitialized();

        const mcpManager = getMCPManager();
        const tools = mcpManager.getClaudeToolDefinitions();

        // Build message history for Claude
        const messages: Anthropic.MessageParam[] = [
            ...history.map((h: { role: string; content: string }) => ({
                role: h.role as 'user' | 'assistant',
                content: h.content,
            })),
            { role: 'user' as const, content: message },
        ];

        // Create streaming response
        const encoder = new TextEncoder();
        const stream = new ReadableStream({
            async start(controller) {
                try {
                    const sendEvent = (event: { type: string; content?: string; toolCall?: unknown }) => {
                        controller.enqueue(
                            encoder.encode(`data: ${JSON.stringify(event)}\n\n`)
                        );
                    };

                    // Call Claude with tools
                    let response = await anthropic.messages.create({
                        model: 'claude-sonnet-4-20250514',
                        max_tokens: 8192,
                        system: SYSTEM_PROMPT,
                        messages,
                        tools: tools.length > 0 ? tools as Anthropic.Tool[] : undefined,
                    });

                    // Agentic loop: handle tool use
                    let currentMessages = [...messages];

                    while (response.stop_reason === 'tool_use') {
                        const assistantContent = response.content;
                        const toolUseBlocks = assistantContent.filter(
                            (block): block is Anthropic.ToolUseBlock => block.type === 'tool_use'
                        );
                        const textBlocks = assistantContent.filter(
                            (block): block is Anthropic.TextBlock => block.type === 'text'
                        );

                        // Stream any text before tool calls
                        for (const textBlock of textBlocks) {
                            sendEvent({ type: 'text', content: textBlock.text });
                        }

                        // Execute tool calls
                        const toolResults: Anthropic.ToolResultBlockParam[] = [];

                        for (const toolUse of toolUseBlocks) {
                            sendEvent({
                                type: 'tool_use',
                                toolCall: {
                                    id: toolUse.id,
                                    name: toolUse.name,
                                    input: toolUse.input,
                                    isLoading: true,
                                },
                            });

                            const result = await mcpManager.executeTool(
                                toolUse.name,
                                toolUse.input as Record<string, unknown>
                            );

                            sendEvent({
                                type: 'tool_result',
                                toolCall: {
                                    id: toolUse.id,
                                    name: toolUse.name,
                                    input: toolUse.input,
                                    result: result.content,
                                    isError: result.isError,
                                    isLoading: false,
                                },
                            });

                            toolResults.push({
                                type: 'tool_result',
                                tool_use_id: toolUse.id,
                                content: result.content,
                                is_error: result.isError,
                            });
                        }

                        // Continue the conversation with tool results
                        currentMessages = [
                            ...currentMessages,
                            { role: 'assistant' as const, content: assistantContent },
                            { role: 'user' as const, content: toolResults },
                        ];

                        response = await anthropic.messages.create({
                            model: 'claude-sonnet-4-20250514',
                            max_tokens: 8192,
                            system: SYSTEM_PROMPT,
                            messages: currentMessages,
                            tools: tools as Anthropic.Tool[],
                        });
                    }

                    // Stream final text response
                    const finalTextBlocks = response.content.filter(
                        (block): block is Anthropic.TextBlock => block.type === 'text'
                    );

                    for (const block of finalTextBlocks) {
                        sendEvent({ type: 'text', content: block.text });
                    }

                    sendEvent({ type: 'done' });
                    controller.close();
                } catch (err) {
                    const errorMsg = err instanceof Error ? err.message : 'Unknown error';
                    controller.enqueue(
                        encoder.encode(
                            `data: ${JSON.stringify({ type: 'error', content: errorMsg })}\n\n`
                        )
                    );
                    controller.close();
                }
            },
        });

        return new Response(stream, {
            headers: {
                'Content-Type': 'text/event-stream',
                'Cache-Control': 'no-cache',
                Connection: 'keep-alive',
            },
        });
    } catch (err) {
        console.error('[Chat] Error:', err);
        return NextResponse.json(
            { error: err instanceof Error ? err.message : 'Internal server error' },
            { status: 500 }
        );
    }
}

// GET endpoint to check MCP status
export async function GET() {
    await ensureMCPInitialized();
    const manager = getMCPManager();
    const servers = manager.getConnectedServerNames();
    const tools = manager.getAllTools();

    return NextResponse.json({
        status: 'ok',
        mcpServers: servers,
        availableTools: tools.map((t) => ({ name: t.name, server: t.serverName })),
    });
}
