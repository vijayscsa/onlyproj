'use client';

import { useState, useEffect } from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import ChatArea from '@/components/ChatArea';
import { Conversation, Message } from '@/lib/types';
import { v4 as uuidv4 } from 'uuid';

export default function Home() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const activeConversation = conversations.find(c => c.id === activeConversationId) || null;

  function createNewChat() {
    const newConv: Conversation = {
      id: uuidv4(),
      title: 'New Conversation',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setConversations(prev => [newConv, ...prev]);
    setActiveConversationId(newConv.id);
    return newConv.id;
  }

  function addMessage(conversationId: string, message: Message) {
    setConversations(prev =>
      prev.map(c => {
        if (c.id === conversationId) {
          const updatedMessages = [...c.messages];
          const existingIdx = updatedMessages.findIndex(m => m.id === message.id);
          if (existingIdx >= 0) {
            updatedMessages[existingIdx] = message;
          } else {
            updatedMessages.push(message);
          }

          // Update title from first user message
          let title = c.title;
          if (title === 'New Conversation' && message.role === 'user') {
            title = message.content.slice(0, 50) + (message.content.length > 50 ? '...' : '');
          }

          return { ...c, messages: updatedMessages, title, updatedAt: Date.now() };
        }
        return c;
      })
    );
  }

  function updateMessage(conversationId: string, messageId: string, updates: Partial<Message>) {
    setConversations(prev =>
      prev.map(c => {
        if (c.id === conversationId) {
          return {
            ...c,
            messages: c.messages.map(m =>
              m.id === messageId ? { ...m, ...updates } : m
            ),
            updatedAt: Date.now(),
          };
        }
        return c;
      })
    );
  }

  return (
    <div className="app-layout">
      <Sidebar
        conversations={conversations}
        activeConversationId={activeConversationId}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
        onSelectConversation={setActiveConversationId}
        onNewChat={createNewChat}
      />
      <div className="main-content">
        <Header
          theme={theme}
          onToggleTheme={() => setTheme(t => t === 'light' ? 'dark' : 'light')}
        />
        <ChatArea
          conversation={activeConversation}
          onCreateChat={createNewChat}
          onAddMessage={addMessage}
          onUpdateMessage={updateMessage}
        />
      </div>
    </div>
  );
}
