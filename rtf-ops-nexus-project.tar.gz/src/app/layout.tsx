import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "RTF DP&E Ops Nexus",
  description: "Enterprise AI Operations Assistant — Powered by Claude Sonnet",
  keywords: ["AI", "Operations", "Chatbot", "Enterprise", "MCP", "Confluence"],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>{children}</body>
    </html>
  );
}
