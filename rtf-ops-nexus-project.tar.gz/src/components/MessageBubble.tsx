'use client';

import { useState } from 'react';
import { Message, ToolCall } from '@/lib/types';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface MessageBubbleProps {
    message: Message;
}

export default function MessageBubble({ message }: MessageBubbleProps) {
    return (
        <div className={`message ${message.role}`}>
            <div className="message-avatar">
                {message.role === 'assistant' ? '✦' : 'U'}
            </div>
            <div className="message-content">
                {/* Tool Calls */}
                {message.toolCalls && message.toolCalls.length > 0 && (
                    <div style={{ marginBottom: '8px' }}>
                        {message.toolCalls.map(tc => (
                            <ToolCallBlock key={tc.id} toolCall={tc} />
                        ))}
                    </div>
                )}

                {/* Message Text */}
                {message.content && (
                    <div className="message-bubble">
                        {message.role === 'assistant' ? (
                            <ReactMarkdown remarkPlugins={[remarkGfm]}>
                                {message.content}
                            </ReactMarkdown>
                        ) : (
                            <p>{message.content}</p>
                        )}
                    </div>
                )}

                {/* Streaming Indicator */}
                {message.isStreaming && !message.content && (
                    <div className="message-bubble">
                        <div className="typing-indicator">
                            <div className="typing-dot" />
                            <div className="typing-dot" />
                            <div className="typing-dot" />
                        </div>
                    </div>
                )}

                {/* Message Actions */}
                {message.role === 'assistant' && message.content && !message.isStreaming && (
                    <div className="message-actions">
                        <button
                            className="msg-action-btn"
                            title="Copy"
                            onClick={() => navigator.clipboard.writeText(message.content)}
                        >
                            📋
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}

function ToolCallBlock({ toolCall }: { toolCall: ToolCall }) {
    const [expanded, setExpanded] = useState(false);

    const statusClass = toolCall.isLoading ? 'loading' : toolCall.isError ? 'error' : 'success';
    const statusText = toolCall.isLoading ? '● Running...' : toolCall.isError ? '● Error' : '● Complete';

    return (
        <div className="tool-call-block">
            <div className="tool-call-header" onClick={() => setExpanded(!expanded)}>
                <span className="tool-icon">🔧</span>
                <span className="tool-call-name">{toolCall.name}</span>
                <span className={`tool-call-status ${statusClass}`}>{statusText}</span>
                <span style={{ fontSize: '10px', color: 'var(--text-tertiary)' }}>
                    {expanded ? '▲' : '▼'}
                </span>
            </div>
            {expanded && toolCall.result && (
                <div className="tool-call-body">
                    {toolCall.result}
                </div>
            )}
        </div>
    );
}
