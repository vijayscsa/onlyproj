'use client';

interface HeaderProps {
    theme: 'light' | 'dark';
    onToggleTheme: () => void;
}

export default function Header({ theme, onToggleTheme }: HeaderProps) {
    return (
        <header className="header">
            <div className="header-left">
                <h1 className="header-title">RTF DP&E Ops Nexus</h1>
                <span className="header-badge">AI Agent</span>
            </div>
            <div className="header-right">
                <button className="theme-toggle" onClick={onToggleTheme} title="Toggle theme">
                    {theme === 'light' ? '🌙' : '☀️'}
                </button>
                <div className="user-avatar">VR</div>
            </div>
        </header>
    );
}
