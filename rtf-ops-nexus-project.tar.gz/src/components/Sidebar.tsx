'use client';

import { Conversation } from '@/lib/types';

interface SidebarProps {
    conversations: Conversation[];
    activeConversationId: string | null;
    collapsed: boolean;
    onToggle: () => void;
    onSelectConversation: (id: string) => void;
    onNewChat: () => void;
}

export default function Sidebar({
    conversations,
    activeConversationId,
    collapsed,
    onToggle,
    onSelectConversation,
    onNewChat,
}: SidebarProps) {
    return (
        <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
            {/* Header */}
            <div className="sidebar-header">
                <div className="sidebar-logo">
                    <span>N</span>
                </div>
                {!collapsed && (
                    <div>
                        <div className="sidebar-title">RTF DP&E</div>
                        <div className="sidebar-subtitle">Ops Nexus</div>
                    </div>
                )}
                <button className="sidebar-toggle" onClick={onToggle} title="Toggle sidebar">
                    {collapsed ? '☰' : '◀'}
                </button>
            </div>

            {/* New Chat Button */}
            {!collapsed && (
                <button className="new-chat-btn" onClick={onNewChat}>
                    <span>＋</span> New Chat
                </button>
            )}
            {collapsed && (
                <button
                    className="new-chat-btn"
                    onClick={onNewChat}
                    style={{ margin: '12px 8px', padding: '8px' }}
                >
                    ＋
                </button>
            )}

            {/* Conversations */}
            <div className="conversation-list">
                {!collapsed && conversations.length === 0 && (
                    <div style={{
                        padding: '24px 16px',
                        textAlign: 'center',
                        color: 'var(--text-placeholder)',
                        fontSize: '13px',
                    }}>
                        No conversations yet.<br />Start a new chat!
                    </div>
                )}
                {!collapsed && conversations.map(conv => (
                    <div
                        key={conv.id}
                        className={`conversation-item ${conv.id === activeConversationId ? 'active' : ''}`}
                        onClick={() => onSelectConversation(conv.id)}
                    >
                        💬 {conv.title}
                    </div>
                ))}
            </div>

            {/* Footer with MCP Status */}
            {!collapsed && (
                <div className="sidebar-footer">
                    <div className="mcp-status">
                        <span className="status-dot connecting"></span>
                        <span>MCP: Atlassian</span>
                    </div>
                    <div className="mcp-status" style={{ marginTop: '4px' }}>
                        <span className="status-dot disconnected"></span>
                        <span>MCP: Ready to connect</span>
                    </div>
                </div>
            )}
        </aside>
    );
}
