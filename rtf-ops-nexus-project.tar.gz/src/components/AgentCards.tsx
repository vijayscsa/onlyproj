'use client';

import { QuickAction } from '@/lib/types';

interface AgentCardsProps {
    onQuickAction: (prompt: string) => void;
}

const QUICK_ACTIONS: QuickAction[] = [
    { id: '1', label: 'Search Confluence', prompt: 'Search Confluence for recent pages about deployment procedures', icon: '🔍', category: 'search' },
    { id: '2', label: 'Create wiki page', prompt: 'Help me create a new Confluence wiki page', icon: '📝', category: 'create' },
    { id: '3', label: 'Sprint planning', prompt: 'Help me with sprint planning documentation', icon: '📋', category: 'planning' },
    { id: '4', label: 'Incident report', prompt: 'Create an incident report template in Confluence', icon: '🚨', category: 'ops' },
    { id: '5', label: 'Review changes', prompt: 'Show me recent changes in our Confluence space', icon: '📊', category: 'review' },
    { id: '6', label: 'Architecture docs', prompt: 'Search for architecture documentation in Confluence', icon: '🏗️', category: 'search' },
];

const AGENT_CARDS = [
    {
        id: 'confluence-search',
        icon: '🔍',
        color: 'blue',
        title: 'Confluence Search',
        desc: 'Search and discover knowledge across your Confluence wiki spaces',
        prompt: 'Search Confluence for pages about',
    },
    {
        id: 'page-creator',
        icon: '📝',
        color: 'green',
        title: 'Page Creator',
        desc: 'Create new Confluence pages with templates and smart content suggestions',
        prompt: 'Help me create a Confluence page about',
    },
    {
        id: 'sprint-planner',
        icon: '🎯',
        color: 'purple',
        title: 'Sprint Planner',
        desc: 'Organize sprint documentation, retros, and planning artifacts',
        prompt: 'Help me with sprint planning for',
    },
    {
        id: 'incident-manager',
        icon: '🚨',
        color: 'orange',
        title: 'Incident Manager',
        desc: 'Create and manage incident reports, RCA docs, and post-mortems',
        prompt: 'Create an incident report for',
    },
    {
        id: 'knowledge-hub',
        icon: '📚',
        color: 'teal',
        title: 'Knowledge Hub',
        desc: 'Discover and organize team knowledge, runbooks, and playbooks',
        prompt: 'Find documentation about',
    },
    {
        id: 'change-tracker',
        icon: '📊',
        color: 'pink',
        title: 'Change Tracker',
        desc: 'Track content changes, updates, and team activity across spaces',
        prompt: 'Show me recent changes for',
    },
];

export default function AgentCards({ onQuickAction }: AgentCardsProps) {
    return (
        <>
            {/* Quick Action Chips */}
            <div className="quick-actions">
                {QUICK_ACTIONS.map(action => (
                    <button
                        key={action.id}
                        className="quick-action-chip"
                        onClick={() => onQuickAction(action.prompt)}
                    >
                        <span className="chip-icon">✦</span>
                        {action.label}
                    </button>
                ))}
            </div>

            {/* Agent Cards Grid */}
            <div className="agent-cards-section">
                <h2 className="agent-cards-title">Browse by AI Solutions</h2>
                <p className="agent-cards-subtitle">Explore agent capabilities and integrations for your team</p>
                <div className="agent-cards-grid">
                    {AGENT_CARDS.map(card => (
                        <div
                            key={card.id}
                            className="agent-card"
                            onClick={() => onQuickAction(card.prompt)}
                        >
                            <div className={`agent-card-icon ${card.color}`}>
                                {card.icon}
                            </div>
                            <div className="agent-card-title">{card.title}</div>
                            <div className="agent-card-desc">{card.desc}</div>
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
}
