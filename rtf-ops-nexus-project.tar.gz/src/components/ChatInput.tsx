'use client';

import { useState, useRef, useEffect, KeyboardEvent } from 'react';

interface ChatInputProps {
    onSend: (message: string) => void;
    disabled: boolean;
    initialValue?: string;
}

export default function ChatInput({ onSend, disabled, initialValue }: ChatInputProps) {
    const [value, setValue] = useState(initialValue || '');
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        if (initialValue) {
            setValue(initialValue);
            // Auto-focus and place cursor at end
            setTimeout(() => {
                textareaRef.current?.focus();
            }, 100);
        }
    }, [initialValue]);

    // Auto-resize textarea
    useEffect(() => {
        const textarea = textareaRef.current;
        if (textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
        }
    }, [value]);

    function handleSubmit() {
        const trimmed = value.trim();
        if (!trimmed || disabled) return;
        onSend(trimmed);
        setValue('');
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
        }
    }

    function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit();
        }
    }

    return (
        <div className="chat-input-container">
            <div className="chat-input-wrapper">
                <div className="chat-input-box">
                    <textarea
                        ref={textareaRef}
                        value={value}
                        onChange={e => setValue(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="Ask RTF Ops Nexus anything..."
                        rows={1}
                        disabled={disabled}
                    />
                    <button
                        className={`send-btn ${disabled ? 'loading' : ''}`}
                        onClick={handleSubmit}
                        disabled={disabled || !value.trim()}
                        title="Send message"
                    >
                        {disabled ? '⏳' : '➤'}
                    </button>
                </div>
                <div className="input-footer">
                    <span>Powered by Claude Sonnet</span>
                    <span>•</span>
                    <span>Shift+Enter for new line</span>
                </div>
            </div>
        </div>
    );
}
