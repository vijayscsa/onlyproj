'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { Conversation, Message, ToolCall, StreamEvent } from '@/lib/types';
import MessageBubble from './MessageBubble';
import ChatInput from './ChatInput';
import AgentCards from './AgentCards';
import { v4 as uuidv4 } from 'uuid';

interface ChatAreaProps {
    conversation: Conversation | null;
    onCreateChat: () => string;
    onAddMessage: (conversationId: string, message: Message) => void;
    onUpdateMessage: (conversationId: string, messageId: string, updates: Partial<Message>) => void;
}

export default function ChatArea({ conversation, onCreateChat, onAddMessage, onUpdateMessage }: ChatAreaProps) {
    const [isLoading, setIsLoading] = useState(false);
    const [quickActionPrompt, setQuickActionPrompt] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = useCallback(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, []);

    useEffect(() => {
        scrollToBottom();
    }, [conversation?.messages, scrollToBottom]);

    async function handleSend(content: string) {
        let convId = conversation?.id;

        // Create new conversation if needed
        if (!convId) {
            convId = onCreateChat();
        }

        // Add user message
        const userMsg: Message = {
            id: uuidv4(),
            role: 'user',
            content,
            timestamp: Date.now(),
        };
        onAddMessage(convId, userMsg);

        // Create placeholder assistant message
        const assistantMsgId = uuidv4();
        const assistantMsg: Message = {
            id: assistantMsgId,
            role: 'assistant',
            content: '',
            timestamp: Date.now(),
            isStreaming: true,
            toolCalls: [],
        };
        onAddMessage(convId, assistantMsg);

        setIsLoading(true);

        try {
            // Build history (without the current message)
            const history = (conversation?.messages || [])
                .filter(m => !m.isStreaming)
                .map(m => ({ role: m.role, content: m.content }));

            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: content, history }),
            });

            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }

            const reader = response.body?.getReader();
            if (!reader) throw new Error('No response stream');

            const decoder = new TextDecoder();
            let fullText = '';
            let toolCalls: ToolCall[] = [];

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value, { stream: true });
                const lines = chunk.split('\n');

                for (const line of lines) {
                    if (!line.startsWith('data: ')) continue;
                    const jsonStr = line.slice(6).trim();
                    if (!jsonStr) continue;

                    try {
                        const event: StreamEvent = JSON.parse(jsonStr);

                        switch (event.type) {
                            case 'text':
                                fullText += event.content || '';
                                onUpdateMessage(convId!, assistantMsgId, {
                                    content: fullText,
                                    isStreaming: true,
                                });
                                break;

                            case 'tool_use':
                                if (event.toolCall) {
                                    toolCalls = [...toolCalls, event.toolCall as ToolCall];
                                    onUpdateMessage(convId!, assistantMsgId, {
                                        toolCalls: [...toolCalls],
                                        isStreaming: true,
                                    });
                                }
                                break;

                            case 'tool_result':
                                if (event.toolCall) {
                                    toolCalls = toolCalls.map(tc =>
                                        tc.id === event.toolCall!.id
                                            ? { ...tc, ...event.toolCall } as ToolCall
                                            : tc
                                    );
                                    onUpdateMessage(convId!, assistantMsgId, {
                                        toolCalls: [...toolCalls],
                                        isStreaming: true,
                                    });
                                }
                                break;

                            case 'done':
                                onUpdateMessage(convId!, assistantMsgId, {
                                    content: fullText,
                                    toolCalls,
                                    isStreaming: false,
                                });
                                break;

                            case 'error':
                                onUpdateMessage(convId!, assistantMsgId, {
                                    content: `⚠️ Error: ${event.content || 'Something went wrong'}`,
                                    isStreaming: false,
                                });
                                break;
                        }
                    } catch {
                        // Skip malformed JSON lines
                    }
                }
            }
        } catch (err) {
            const errorMsg = err instanceof Error ? err.message : 'Unknown error';
            onUpdateMessage(conversation?.id || '', assistantMsgId, {
                content: `⚠️ Failed to connect: ${errorMsg}\n\nPlease ensure your ANTHROPIC_API_KEY is set in .env.local and the server is running.`,
                isStreaming: false,
            });
        } finally {
            setIsLoading(false);
            setQuickActionPrompt('');
        }
    }

    function handleQuickAction(prompt: string) {
        setQuickActionPrompt(prompt);
    }

    const showWelcome = !conversation || conversation.messages.length === 0;

    return (
        <div className="chat-container">
            <div className="messages-container">
                {showWelcome ? (
                    <div className="welcome-hero">
                        {/* Floating background icons */}
                        <div className="hero-background">
                            <div className="floating-icon">📄</div>
                            <div className="floating-icon">⚡</div>
                            <div className="floating-icon">🔗</div>
                            <div className="floating-icon">🤖</div>
                            <div className="floating-icon">🎯</div>
                            <div className="floating-icon">📊</div>
                            <div className="floating-icon">💡</div>
                            <div className="floating-icon">🔐</div>
                        </div>

                        {/* Hero Content */}
                        <div className="hero-content">
                            <h1 className="hero-title">
                                Explore <span className="highlight-blue">agent capabilities</span> and{' '}
                                <span className="highlight-purple">integrations</span>
                                <br />for your operations.
                            </h1>
                            <p className="hero-subtitle">
                                Your AI-powered operations assistant with Confluence, Jira, and more.
                                Built for the RTF Digital Platforms & Engineering team.
                            </p>
                        </div>

                        {/* Hero Search Bar */}
                        <div className="hero-search-container">
                            <span className="hero-search-icon">✦</span>
                            <input
                                type="text"
                                className="hero-search"
                                placeholder="Ask the operations agent..."
                                value={quickActionPrompt}
                                onChange={e => setQuickActionPrompt(e.target.value)}
                                onKeyDown={e => {
                                    if (e.key === 'Enter' && quickActionPrompt.trim()) {
                                        handleSend(quickActionPrompt.trim());
                                    }
                                }}
                            />
                            <button
                                className="hero-search-submit"
                                onClick={() => quickActionPrompt.trim() && handleSend(quickActionPrompt.trim())}
                                disabled={!quickActionPrompt.trim() || isLoading}
                            >
                                ➤
                            </button>
                        </div>

                        <AgentCards onQuickAction={handleQuickAction} />
                    </div>
                ) : (
                    <div className="messages-wrapper">
                        {conversation.messages.map(msg => (
                            <MessageBubble key={msg.id} message={msg} />
                        ))}
                        <div ref={messagesEndRef} />
                    </div>
                )}
            </div>

            {/* Chat Input (shown when in conversation) */}
            {!showWelcome && (
                <ChatInput
                    onSend={handleSend}
                    disabled={isLoading}
                    initialValue={quickActionPrompt}
                />
            )}
        </div>
    );
}
