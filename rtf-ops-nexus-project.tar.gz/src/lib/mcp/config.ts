import { readFileSync, existsSync } from 'fs';
import { join } from 'path';

export interface MCPServerConfig {
    type: 'stdio' | 'sse';
    command: string;
    args: string[];
    cwd?: string;
    env?: Record<string, string>;
    disabled?: boolean;
    alwaysAllow?: string[];
    timeout?: number;
}

export interface MCPSettings {
    mcpServers: Record<string, MCPServerConfig>;
}

let cachedSettings: MCPSettings | null = null;

export function loadMCPSettings(): MCPSettings {
    if (cachedSettings) return cachedSettings;

    const settingsPath = join(process.cwd(), 'mcp_settings.json');

    if (!existsSync(settingsPath)) {
        console.warn('[MCP] mcp_settings.json not found, using empty config');
        cachedSettings = { mcpServers: {} };
        return cachedSettings;
    }

    try {
        const raw = readFileSync(settingsPath, 'utf-8');
        cachedSettings = JSON.parse(raw) as MCPSettings;
        console.log(`[MCP] Loaded ${Object.keys(cachedSettings.mcpServers).length} server(s)`);
        return cachedSettings;
    } catch (err) {
        console.error('[MCP] Failed to parse mcp_settings.json:', err);
        cachedSettings = { mcpServers: {} };
        return cachedSettings;
    }
}

export function getEnabledServers(): Record<string, MCPServerConfig> {
    const settings = loadMCPSettings();
    const enabled: Record<string, MCPServerConfig> = {};

    for (const [name, config] of Object.entries(settings.mcpServers)) {
        if (!config.disabled) {
            enabled[name] = config;
        }
    }

    return enabled;
}
