import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { getEnabledServers, MCPServerConfig } from './config';

interface MCPTool {
    name: string;
    description?: string;
    input_schema: Record<string, unknown>;
    serverName: string;
}

interface ConnectedServer {
    client: Client;
    config: MCPServerConfig;
    tools: MCPTool[];
}

class MCPClientManager {
    private servers: Map<string, ConnectedServer> = new Map();
    private initialized = false;

    async initialize(): Promise<void> {
        if (this.initialized) return;

        const configs = getEnabledServers();

        for (const [name, config] of Object.entries(configs)) {
            try {
                await this.connectServer(name, config);
                console.log(`[MCP] Connected to ${name}`);
            } catch (err) {
                console.warn(`[MCP] Failed to connect to ${name}:`, err);
            }
        }

        this.initialized = true;
    }

    private async connectServer(name: string, config: MCPServerConfig): Promise<void> {
        const transport = new StdioClientTransport({
            command: config.command,
            args: config.args,
            cwd: config.cwd,
            env: {
                ...process.env,
                ...config.env,
            } as Record<string, string>,
        });

        const client = new Client(
            { name: 'rtf-ops-nexus', version: '1.0.0' },
            { capabilities: {} }
        );

        await client.connect(transport);

        // Discover tools
        const toolsResult = await client.listTools();
        const tools: MCPTool[] = (toolsResult.tools || []).map((t) => ({
            name: t.name,
            description: t.description,
            input_schema: t.inputSchema as Record<string, unknown>,
            serverName: name,
        }));

        this.servers.set(name, { client, config, tools });
    }

    getAllTools(): MCPTool[] {
        const allTools: MCPTool[] = [];
        for (const server of this.servers.values()) {
            allTools.push(...server.tools);
        }
        return allTools;
    }

    getClaudeToolDefinitions(): Array<{
        name: string;
        description: string;
        input_schema: Record<string, unknown>;
    }> {
        return this.getAllTools().map((tool) => ({
            name: tool.name,
            description: tool.description || `Tool: ${tool.name}`,
            input_schema: tool.input_schema,
        }));
    }

    private findServerForTool(toolName: string): ConnectedServer | undefined {
        for (const server of this.servers.values()) {
            if (server.tools.some((t) => t.name === toolName)) {
                return server;
            }
        }
        return undefined;
    }

    async executeTool(
        toolName: string,
        args: Record<string, unknown>
    ): Promise<{ content: string; isError: boolean }> {
        const server = this.findServerForTool(toolName);
        if (!server) {
            return {
                content: `Tool "${toolName}" not found on any connected MCP server.`,
                isError: true,
            };
        }

        try {
            const result = await server.client.callTool({
                name: toolName,
                arguments: args,
            });

            const textContent = (result.content as Array<{ type: string; text?: string }>)
                .filter((c) => c.type === 'text')
                .map((c) => c.text || '')
                .join('\n');

            return { content: textContent, isError: !!result.isError };
        } catch (err) {
            return {
                content: `Error executing tool "${toolName}": ${err instanceof Error ? err.message : String(err)}`,
                isError: true,
            };
        }
    }

    getConnectedServerNames(): string[] {
        return Array.from(this.servers.keys());
    }

    async disconnect(): Promise<void> {
        for (const [name, server] of this.servers) {
            try {
                await server.client.close();
                console.log(`[MCP] Disconnected from ${name}`);
            } catch (err) {
                console.warn(`[MCP] Error disconnecting from ${name}:`, err);
            }
        }
        this.servers.clear();
        this.initialized = false;
    }
}

// Singleton instance
let mcpManager: MCPClientManager | null = null;

export function getMCPManager(): MCPClientManager {
    if (!mcpManager) {
        mcpManager = new MCPClientManager();
    }
    return mcpManager;
}

export type { MCPTool, ConnectedServer };
