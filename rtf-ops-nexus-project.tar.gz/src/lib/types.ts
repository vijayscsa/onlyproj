export interface Message {
    id: string;
    role: 'user' | 'assistant';
    content: string;
    timestamp: number;
    toolCalls?: ToolCall[];
    isStreaming?: boolean;
}

export interface ToolCall {
    id: string;
    name: string;
    input: Record<string, unknown>;
    result?: string;
    isError?: boolean;
    isLoading?: boolean;
}

export interface Conversation {
    id: string;
    title: string;
    messages: Message[];
    createdAt: number;
    updatedAt: number;
}

export interface ChatRequest {
    message: string;
    conversationId?: string;
    history?: Array<{ role: 'user' | 'assistant'; content: string }>;
}

export interface StreamEvent {
    type: 'text' | 'tool_use' | 'tool_result' | 'done' | 'error';
    content?: string;
    toolCall?: ToolCall;
}

export interface MCPServerStatus {
    name: string;
    connected: boolean;
    toolCount: number;
}

export interface QuickAction {
    id: string;
    label: string;
    prompt: string;
    icon: string;
    category: string;
}
