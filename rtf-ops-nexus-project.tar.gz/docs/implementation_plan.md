# RTF DP&E Ops Nexus — Agentic AI Chatbot

An enterprise-grade Agentic AI conversational chatbot powered by Claude Sonnet, with MCP server integrations and a premium UI inspired by Kore.ai's Agent Marketplace.

## Architecture Overview

```mermaid
graph TB
    subgraph Frontend["Next.js Frontend (React + TypeScript)"]
        UI["Enterprise Chat UI"]
        Cards["Agent Template Cards"]
        Stream["SSE Streaming Display"]
    end
    
    subgraph Backend["Next.js API Routes"]
        API["Chat API /api/chat"]
        MCPRouter["MCP Tool Router"]
        Session["Session Manager"]
    end
    
    subgraph MCP["MCP Servers"]
        Atlassian["mcp-atlassian (Confluence)"]
        Future["Future MCP Servers..."]
    end
    
    subgraph AI["AI Engine"]
        Claude["Claude Sonnet (Anthropic API)"]
    end
    
    UI --> API
    API --> Claude
    Claude -->|Tool Calls| MCPRouter
    MCPRouter --> Atlassian
    MCPRouter --> Future
    MCPRouter -->|Tool Results| Claude
    Claude -->|Streaming Response| Stream
```

## Technology Stack

| Layer | Technology | Rationale |
|-------|-----------|-----------|
| Framework | Next.js 14 (App Router) | Full-stack React, SSR, API routes |
| Language | TypeScript | Type safety for enterprise |
| AI SDK | Anthropic SDK (`@anthropic-ai/sdk`) | Direct Claude Sonnet integration |
| MCP Client | `@modelcontextprotocol/sdk` | Standard MCP client protocol |
| Styling | Vanilla CSS with design tokens | Maximum control, Kore.ai-inspired |
| Font | Inter (Google Fonts) | Matches Kore.ai enterprise style |
| Deployment | Docker → AWS ECS | Container-first architecture |

## Proposed Changes

---

### Project Configuration

#### [NEW] [package.json](file:///home/ravinv1/rtf-ops-nexus/package.json)
- Next.js 14 project with TypeScript, Anthropic SDK, MCP SDK dependencies
- Scripts for dev, build, start, docker

#### [NEW] [tsconfig.json](file:///home/ravinv1/rtf-ops-nexus/tsconfig.json)
- Standard Next.js TypeScript config with path aliases

#### [NEW] [next.config.js](file:///home/ravinv1/rtf-ops-nexus/next.config.js)
- Next.js configuration with environment variables

#### [NEW] [.env.local](file:///home/ravinv1/rtf-ops-nexus/.env.local)
- `ANTHROPIC_API_KEY` — Claude Sonnet API key
- `CONFLUENCE_URL`, `CONFLUENCE_USERNAME`, `CONFLUENCE_API_TOKEN` — Atlassian config
- `MCP_ATLASSIAN_PATH` — Path to mcp-atlassian binary

---

### Backend — AI & MCP Integration

#### [NEW] [src/app/api/chat/route.ts](file:///home/ravinv1/rtf-ops-nexus/src/app/api/chat/route.ts)
- POST endpoint for chat messages
- Initializes Claude Sonnet with system prompt for the RTF DP&E Ops Nexus agent
- Implements streaming responses via Server-Sent Events (SSE)
- Routes tool calls to the appropriate MCP server
- Handles multi-turn conversation context

#### [NEW] [src/lib/mcp/client.ts](file:///home/ravinv1/rtf-ops-nexus/src/lib/mcp/client.ts)
- MCP client manager that connects to configured MCP servers
- Discovers available tools from each server
- Converts MCP tools to Claude-compatible tool definitions
- Executes tool calls and returns results

#### [NEW] [src/lib/mcp/config.ts](file:///home/ravinv1/rtf-ops-nexus/src/lib/mcp/config.ts)
- MCP server configuration loader (reads from `mcp_settings.json`)
- Server registry with connection status tracking

#### [NEW] [mcp_settings.json](file:///home/ravinv1/rtf-ops-nexus/mcp_settings.json)
- MCP server definitions (starting with mcp-atlassian)
- Matches the user's existing configuration format

#### [NEW] [src/lib/ai/system-prompt.ts](file:///home/ravinv1/rtf-ops-nexus/src/lib/ai/system-prompt.ts)
- System prompt defining the RTF DP&E Ops Nexus agent persona
- Instructions for tool usage, response formatting, and behavior

---

### Frontend — Enterprise UI

#### [NEW] [src/app/layout.tsx](file:///home/ravinv1/rtf-ops-nexus/src/app/layout.tsx)
- Root layout with Inter font, metadata, theme provider

#### [NEW] [src/app/page.tsx](file:///home/ravinv1/rtf-ops-nexus/src/app/page.tsx)
- Main page composing sidebar + chat area

#### [NEW] [src/app/globals.css](file:///home/ravinv1/rtf-ops-nexus/src/app/globals.css)
- Design tokens (colors, spacing, shadows, radii) inspired by Kore.ai
- Global styles, dark mode variables, animations
- Glassmorphism effects, gradient backgrounds

#### [NEW] [src/components/Sidebar.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/Sidebar.tsx)
- Collapsible left sidebar with:
  - App logo and branding
  - Conversation history list
  - "New Chat" button
  - MCP server status indicators
  - Settings link

#### [NEW] [src/components/ChatArea.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/ChatArea.tsx)
- Main chat area with:
  - Welcome hero section (Kore.ai marketplace-style with floating icons)
  - Search/input bar with animated border
  - Quick action suggestion chips
  - Agent template cards ("Browse by AI Solutions")
  - Message thread view when chatting

#### [NEW] [src/components/ChatInput.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/ChatInput.tsx)
- Enterprise chat input with:
  - Auto-resizing textarea
  - Send button with loading animation
  - MCP tool attachment indicators
  - Keyboard shortcuts (Enter to send, Shift+Enter for newline)

#### [NEW] [src/components/MessageBubble.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/MessageBubble.tsx)
- User and assistant message components
- Markdown rendering for assistant responses
- Tool call/result display with collapsible details
- Typing indicator animation
- Copy-to-clipboard button

#### [NEW] [src/components/AgentCards.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/AgentCards.tsx)
- Kore.ai-inspired agent template cards
- Quick action chips with sparkle icons
- Categories: Confluence Search, Page Creation, Sprint Planning, etc.

#### [NEW] [src/components/Header.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/Header.tsx)
- Top header bar with app title, user avatar, theme toggle

---

### Deployment

#### [NEW] [Dockerfile](file:///home/ravinv1/rtf-ops-nexus/Dockerfile)
- Multi-stage build: deps → build → production
- Node.js 20 Alpine base
- Optimized for Next.js standalone output

#### [NEW] [docker-compose.yml](file:///home/ravinv1/rtf-ops-nexus/docker-compose.yml)
- Service definition for the app
- Environment variable passthrough
- Port mapping (3000)

#### [NEW] [.dockerignore](file:///home/ravinv1/rtf-ops-nexus/.dockerignore)
- Ignore node_modules, .next, .env files

#### [NEW] [aws/ecs-task-definition.json](file:///home/ravinv1/rtf-ops-nexus/aws/ecs-task-definition.json)
- ECS Fargate task definition
- Container definitions, resource allocations, log configuration

---

## User Review Required

> [!IMPORTANT]
> **Anthropic API Key Required**: You will need a valid `ANTHROPIC_API_KEY` set in `.env.local` for the Claude Sonnet integration to work. Please have this ready.

> [!WARNING]
> **MCP Atlassian Path**: The `mcp_settings.json` references your MacBook path `/Users/vijayakumar.ravindran/benesta1/mcps/mcp-atlassian/`. Since we're developing on this Linux machine, the MCP Atlassian server won't be available here. The app will work without it (graceful degradation), and will fully connect when you run it on your Mac. Should I also set up a mock MCP mode for testing?

> [!NOTE]
> **macOS vs Linux**: The project will be developed here at `/home/ravinv1/rtf-ops-nexus` and is designed to be portable. When you copy it to your MacBook at `/Users/vijayakumar.ravindran/benesta1/rtf-ops-nexus`, the MCP connections will activate automatically.

## Verification Plan

### Automated Tests
1. **Dev server startup**: Run `npm run dev` and confirm the server starts on port 3000
2. **Browser UI verification**: Use the browser tool to navigate to `http://localhost:3000` and visually verify:
   - Enterprise UI renders with proper styling
   - Sidebar, header, chat area, agent cards all display
   - Quick action chips and search bar are interactive
   - Theme/dark mode toggle works
3. **API endpoint check**: Send a test request to `/api/chat` and verify response format
4. **Build verification**: Run `npm run build` to ensure production build succeeds

### Manual Verification
- After setting up on your MacBook with the `ANTHROPIC_API_KEY`:
  1. Start with `npm run dev`
  2. Visit `http://localhost:3000`
  3. Try sending a chat message — should get Claude Sonnet response
  4. Try a Confluence query like "Search for pages about deployment" — should route to mcp-atlassian
  5. Verify Docker build with `docker build -t rtf-ops-nexus .` and `docker run -p 3000:3000 rtf-ops-nexus`
