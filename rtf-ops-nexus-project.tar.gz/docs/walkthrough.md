# RTF DP&E Ops Nexus — Walkthrough

## What Was Built

A full-stack enterprise Agentic AI chatbot powered by Claude Sonnet with MCP server integration for Confluence, featuring a premium UI inspired by Kore.ai's Agent Marketplace.

## Architecture

```mermaid
graph LR
    UI["React Frontend"] -->|SSE Stream| API["Next.js API /api/chat"]
    API --> Claude["Claude Sonnet"]
    Claude -->|Tool Calls| MCP["MCP Client Manager"]
    MCP --> Atlassian["mcp-atlassian"]
    MCP --> Future["Future MCP Servers"]
```

## Files Created

| Category | File | Purpose |
|----------|------|---------|
| **Config** | [package.json](file:///home/ravinv1/rtf-ops-nexus/package.json) | Dependencies & scripts |
| | [next.config.ts](file:///home/ravinv1/rtf-ops-nexus/next.config.ts) | Standalone output, external packages |
| | [mcp_settings.json](file:///home/ravinv1/rtf-ops-nexus/mcp_settings.json) | MCP server definitions |
| | [.env.local](file:///home/ravinv1/rtf-ops-nexus/.env.local) | API keys & secrets |
| **Backend** | [api/chat/route.ts](file:///home/ravinv1/rtf-ops-nexus/src/app/api/chat/route.ts) | Chat API with SSE streaming + tool loop |
| | [lib/mcp/client.ts](file:///home/ravinv1/rtf-ops-nexus/src/lib/mcp/client.ts) | MCP client manager |
| | [lib/mcp/config.ts](file:///home/ravinv1/rtf-ops-nexus/src/lib/mcp/config.ts) | MCP config loader |
| | [lib/ai/system-prompt.ts](file:///home/ravinv1/rtf-ops-nexus/src/lib/ai/system-prompt.ts) | Agent persona & instructions |
| | [lib/types.ts](file:///home/ravinv1/rtf-ops-nexus/src/lib/types.ts) | TypeScript type definitions |
| **Frontend** | [globals.css](file:///home/ravinv1/rtf-ops-nexus/src/app/globals.css) | Full design system with dark mode |
| | [page.tsx](file:///home/ravinv1/rtf-ops-nexus/src/app/page.tsx) | Main page with state management |
| | [ChatArea.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/ChatArea.tsx) | Chat orchestrator (hero + messages) |
| | [MessageBubble.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/MessageBubble.tsx) | Markdown messages + tool calls |
| | [ChatInput.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/ChatInput.tsx) | Auto-resize input with shortcuts |
| | [Sidebar.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/Sidebar.tsx) | Collapsible sidebar + MCP status |
| | [Header.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/Header.tsx) | Header with theme toggle |
| | [AgentCards.tsx](file:///home/ravinv1/rtf-ops-nexus/src/components/AgentCards.tsx) | Kore.ai-style template cards |
| **Deploy** | [Dockerfile](file:///home/ravinv1/rtf-ops-nexus/Dockerfile) | Multi-stage production build |
| | [docker-compose.yml](file:///home/ravinv1/rtf-ops-nexus/docker-compose.yml) | Docker Compose config |
| | [ecs-task-definition.json](file:///home/ravinv1/rtf-ops-nexus/aws/ecs-task-definition.json) | AWS ECS Fargate task def |

## Verification Results

| Check | Result |
|-------|--------|
| TypeScript compilation | ✅ No errors |
| Next.js production build | ✅ All pages + API routes generated |
| Dev server (port 3000) | ✅ Serving correctly |
| Frontend HTML response | ✅ Correct metadata: "RTF DP&E Ops Nexus" |
| API `/api/chat` GET | ✅ Returns `{"status":"ok"}` |
| MCP graceful degradation | ✅ No errors when servers unavailable |

## How to Run on macOS

```bash
# 1. Copy project to your Mac
cp -r /home/ravinv1/rtf-ops-nexus /Users/vijayakumar.ravindran/benesta1/rtf-ops-nexus

# 2. Set your API key in .env.local
echo "ANTHROPIC_API_KEY=sk-ant-..." >> .env.local

# 3. Install & run
npm install
npm run dev
# → http://localhost:3000
```

## Docker Deployment

```bash
# Build & run locally
docker compose up --build

# Push to AWS ECR
aws ecr get-login-password | docker login --username AWS --password-stdin ACCOUNT.dkr.ecr.REGION.amazonaws.com
docker tag rtf-ops-nexus:latest ACCOUNT.dkr.ecr.REGION.amazonaws.com/rtf-ops-nexus:latest
docker push ACCOUNT.dkr.ecr.REGION.amazonaws.com/rtf-ops-nexus:latest

# Deploy to ECS
aws ecs register-task-definition --cli-input-json file://aws/ecs-task-definition.json
```
