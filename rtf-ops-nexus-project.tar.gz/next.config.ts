import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: 'standalone',
  serverExternalPackages: [
    '@modelcontextprotocol/sdk',
    '@anthropic-ai/sdk',
  ],
};

export default nextConfig;
