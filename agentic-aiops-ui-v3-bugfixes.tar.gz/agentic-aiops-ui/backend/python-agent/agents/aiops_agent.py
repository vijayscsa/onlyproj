"""
AIOps Agent - LangChain-based AI agent for incident management
"""
import os
from typing import Dict, Any, List, Optional, AsyncGenerator
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_openai_functions_agent
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.memory import ConversationBufferWindowMemory
from langchain.tools import Tool
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

from mcp.pagerduty_client import PagerDutyMCPClient
from config.services_config import (
    ALLOWED_SERVICES,
    ALLOWED_TEAM,
    get_allowed_service_ids,
    get_allowed_service_names,
    get_team_id,
    get_team_name
)


class AIOpsAgent:
    """AI-powered operations agent for PagerDuty incident management"""
    
    def __init__(self, mcp_client: PagerDutyMCPClient):
        self.mcp_client = mcp_client
        self.conversations: Dict[str, ConversationBufferWindowMemory] = {}
        
        # Initialize LLM
        self.llm = ChatOpenAI(
            base_url=os.getenv("OPENAI_API_BASE", "https://api.studio.genai.cbaa"),
            api_key=os.getenv("OPENAI_API_KEY"),
            model=os.getenv("OPENAI_MODEL", "AIPE-bedrock-claude-4-sonnet"),
            temperature=0.1,
            streaming=True
        )
        
        # Create tools from MCP
        self.tools = self._create_tools()
        
        # Create agent
        self.agent = self._create_agent()
    
    def _create_tools(self) -> List[Tool]:
        """Create LangChain tools from MCP client"""
        tools = []
        
        # List incidents tool
        async def list_incidents_func(query: str = "") -> str:
            try:
                # Filter by allowed service IDs and team
                allowed_service_ids = get_allowed_service_ids()
                team_id = get_team_id()
                
                result = await self.mcp_client.execute_tool("list_incidents", {
                    "limit": 20,
                    "service_ids": allowed_service_ids,
                    "team_ids": [team_id]
                })
                incidents = result.get("incidents", [])
                if not incidents:
                    return f"No incidents found for the monitored services ({', '.join(get_allowed_service_names())})."
                
                output = f"Found {len(incidents)} incidents for {get_team_name()} team:\n\n"
                for inc in incidents:
                    output += f"• [{inc.get('urgency', 'unknown').upper()}] {inc.get('title', 'No title')}\n"
                    output += f"  ID: {inc.get('id')} | Status: {inc.get('status')} | Service: {inc.get('service', {}).get('summary', 'Unknown')}\n\n"
                return output
            except Exception as e:
                return f"Error listing incidents: {str(e)}"
        
        tools.append(Tool(
            name="list_incidents",
            description=f"List current PagerDuty incidents for the monitored services: {', '.join(get_allowed_service_names())}. Use this to see what incidents are active.",
            func=lambda x: None,  # Sync placeholder
            coroutine=list_incidents_func
        ))
        
        # Get incident details tool
        async def get_incident_func(incident_id: str) -> str:
            try:
                result = await self.mcp_client.execute_tool("get_incident_details", {"incident_id": incident_id})
                incident = result.get("incident", result)
                
                output = f"Incident Details:\n"
                output += f"• Title: {incident.get('title', 'N/A')}\n"
                output += f"• ID: {incident.get('id', 'N/A')}\n"
                output += f"• Status: {incident.get('status', 'N/A')}\n"
                output += f"• Urgency: {incident.get('urgency', 'N/A')}\n"
                output += f"• Service: {incident.get('service', {}).get('summary', 'N/A')}\n"
                output += f"• Created: {incident.get('created_at', 'N/A')}\n"
                output += f"• Description: {incident.get('description', 'No description')}\n"
                
                if incident.get("assignments"):
                    output += f"• Assigned to: {', '.join([a.get('assignee', {}).get('summary', 'Unknown') for a in incident.get('assignments', [])])}\n"
                
                return output
            except Exception as e:
                return f"Error getting incident details: {str(e)}"
        
        tools.append(Tool(
            name="get_incident",
            description="Get detailed information about a specific incident. Input should be the incident ID.",
            func=lambda x: None,
            coroutine=get_incident_func
        ))
        
        # List services tool
        async def list_services_func(query: str = "") -> str:
            try:
                # Return only the allowed services
                allowed_service_ids = get_allowed_service_ids()
                services = []
                
                for service_id in allowed_service_ids:
                    try:
                        result = await self.mcp_client.execute_tool("get_service", {"service_id": service_id})
                        if result.get("service"):
                            services.append(result["service"])
                    except Exception as e:
                        print(f"Warning: Could not fetch service {service_id}: {e}")
                
                if not services:
                    return "No monitored services available."
                
                output = f"Monitored services for {get_team_name()} team ({len(services)} total):\n\n"
                for svc in services:
                    output += f"• {svc.get('name', 'Unknown')}\n"
                    output += f"  ID: {svc.get('id')} | Status: {svc.get('status', 'unknown')}\n\n"
                return output
            except Exception as e:
                return f"Error listing services: {str(e)}"
        
        tools.append(Tool(
            name="list_services",
            description=f"List the monitored PagerDuty services: {', '.join(get_allowed_service_names())}. These are the services managed by {get_team_name()} team.",
            func=lambda x: None,
            coroutine=list_services_func
        ))
        
        # Acknowledge incident tool
        async def acknowledge_incident_func(incident_id: str) -> str:
            try:
                result = await self.mcp_client.execute_tool("acknowledge_incident", {"incident_id": incident_id})
                return f"Successfully acknowledged incident {incident_id}"
            except Exception as e:
                return f"Error acknowledging incident: {str(e)}"
        
        tools.append(Tool(
            name="acknowledge_incident",
            description="Acknowledge a PagerDuty incident. Input should be the incident ID.",
            func=lambda x: None,
            coroutine=acknowledge_incident_func
        ))
        
        # Resolve incident tool
        async def resolve_incident_func(incident_id: str) -> str:
            try:
                result = await self.mcp_client.execute_tool("resolve_incident", {"incident_id": incident_id})
                return f"Successfully resolved incident {incident_id}"
            except Exception as e:
                return f"Error resolving incident: {str(e)}"
        
        tools.append(Tool(
            name="resolve_incident",
            description="Resolve a PagerDuty incident. Input should be the incident ID.",
            func=lambda x: None,
            coroutine=resolve_incident_func
        ))
        
        # Get on-call users tool
        async def get_oncall_func(query: str = "") -> str:
            try:
                result = await self.mcp_client.execute_tool("list_oncalls", {})
                oncalls = result.get("oncalls", [])
                if not oncalls:
                    return "No on-call users found."
                
                output = "Current on-call users:\n\n"
                for oc in oncalls:
                    user = oc.get("user", {})
                    schedule = oc.get("schedule", {})
                    output += f"• {user.get('summary', 'Unknown')}\n"
                    output += f"  Schedule: {schedule.get('summary', 'Unknown')}\n\n"
                return output
            except Exception as e:
                return f"Error getting on-call users: {str(e)}"
        
        tools.append(Tool(
            name="get_oncall",
            description="Get current on-call users and schedules.",
            func=lambda x: None,
            coroutine=get_oncall_func
        ))
        
        return tools
    
    def _create_agent(self) -> AgentExecutor:
        """Create the LangChain agent"""
        # Build service names list for the prompt
        service_names = ", ".join(get_allowed_service_names())
        team_name = get_team_name()
        
        system_prompt = f"""You are an expert AIOps assistant for the {team_name} team, helping manage PagerDuty incidents and services.

You are specifically monitoring these services:
{chr(10).join([f"- {name}" for name in get_allowed_service_names()])}

Your role is to:
1. Help users understand incidents for the monitored services listed above
2. Provide insights and analysis on incidents
3. Execute actions like acknowledging and resolving incidents
4. Recommend prioritization and triage strategies
5. Help identify patterns and root causes

When responding:
- Be concise but thorough
- Always provide actionable insights
- If you need to take an action, confirm with the user first
- Use the available tools to fetch real-time data
- Remember you are focused on the {team_name} team's services

Available capabilities:
- List and search incidents for {service_names}
- Get detailed incident information
- List services and their status
- Acknowledge and resolve incidents
- View on-call schedules
"""
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad")
        ])
        
        agent = create_openai_functions_agent(self.llm, self.tools, prompt)
        
        return AgentExecutor(
            agent=agent,
            tools=self.tools,
            verbose=os.getenv("DEBUG", "false").lower() == "true",
            handle_parsing_errors=True,
            max_iterations=5
        )
    
    def _get_memory(self, conversation_id: str) -> ConversationBufferWindowMemory:
        """Get or create conversation memory"""
        if conversation_id not in self.conversations:
            self.conversations[conversation_id] = ConversationBufferWindowMemory(
                memory_key="chat_history",
                return_messages=True,
                k=10  # Keep last 10 exchanges
            )
        return self.conversations[conversation_id]
    
    async def chat(self, message: str, conversation_id: str) -> Dict[str, Any]:
        """Process a chat message and return response"""
        memory = self._get_memory(conversation_id)
        
        try:
            # Get chat history
            history = memory.load_memory_variables({})
            chat_history = history.get("chat_history", [])
            
            # Run agent
            result = await self.agent.ainvoke({
                "input": message,
                "chat_history": chat_history
            })
            
            response = result.get("output", "I couldn't process your request.")
            
            # Save to memory
            memory.save_context(
                {"input": message},
                {"output": response}
            )
            
            # Extract tools used
            tools_used = []
            if "intermediate_steps" in result:
                for step in result["intermediate_steps"]:
                    if hasattr(step[0], "tool"):
                        tools_used.append(step[0].tool)
            
            return {
                "response": response,
                "tools_used": tools_used
            }
        except Exception as e:
            return {
                "response": f"I encountered an error: {str(e)}. Please try again.",
                "tools_used": [],
                "error": str(e)
            }
    
    async def stream_chat(self, message: str, conversation_id: str) -> AsyncGenerator[str, None]:
        """Stream chat response"""
        memory = self._get_memory(conversation_id)
        history = memory.load_memory_variables({})
        chat_history = history.get("chat_history", [])
        
        try:
            async for event in self.agent.astream_events(
                {"input": message, "chat_history": chat_history},
                version="v1"
            ):
                kind = event.get("event")
                if kind == "on_chat_model_stream":
                    content = event.get("data", {}).get("chunk", {})
                    if hasattr(content, "content") and content.content:
                        yield content.content
        except Exception as e:
            yield f"Error: {str(e)}"
    
    async def execute_query(self, query: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute a specific query without conversation context"""
        try:
            result = await self.agent.ainvoke({
                "input": query,
                "chat_history": []
            })
            return {
                "response": result.get("output", ""),
                "context": context
            }
        except Exception as e:
            return {
                "response": f"Error executing query: {str(e)}",
                "error": str(e)
            }
    
    async def analyze_incident(self, incident: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze an incident and provide insights"""
        title = incident.get("title", "Unknown")
        status = incident.get("status", "unknown")
        urgency = incident.get("urgency", "unknown")
        service = incident.get("service", {}).get("summary", "Unknown")
        description = incident.get("description", "No description provided")
        
        analysis_prompt = f"""Analyze this PagerDuty incident and provide:
1. A summary of the issue
2. Potential root causes
3. Recommended remediation steps
4. Priority assessment

Incident Details:
- Title: {title}
- Status: {status}
- Urgency: {urgency}
- Service: {service}
- Description: {description}

Provide a structured analysis."""
        
        try:
            result = await self.llm.ainvoke([
                SystemMessage(content="You are an expert SRE analyzing incidents. Provide actionable insights."),
                HumanMessage(content=analysis_prompt)
            ])
            
            return {
                "summary": result.content,
                "incident_id": incident.get("id"),
                "urgency": urgency,
                "status": status
            }
        except Exception as e:
            return {
                "error": str(e),
                "incident_id": incident.get("id")
            }
