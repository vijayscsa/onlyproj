import React, { useState, useRef, useEffect, useCallback } from 'react';

export default function InputArea({ onSend, onAbort, isStreaming, disabled }) {
  const [input, setInput] = useState('');
  const textareaRef = useRef(null);

  // Auto-resize textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (ta) {
      ta.style.height = '24px';
      ta.style.height = Math.min(ta.scrollHeight, 200) + 'px';
    }
  }, [input]);

  // Focus textarea on mount
  useEffect(() => {
    textareaRef.current?.focus();
  }, []);

  const handleSubmit = useCallback(() => {
    if (isStreaming) {
      onAbort();
      return;
    }
    if (!input.trim() || disabled) return;
    onSend(input);
    setInput('');
  }, [input, isStreaming, disabled, onSend, onAbort]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  }, [handleSubmit]);

  return (
    <div className="input-area" id="input-area">
      <div className="input-wrapper">
        <div className="input-box">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={disabled ? 'Connecting to server...' : 'Ask Roo anything... (Shift+Enter for new line)'}
            disabled={disabled}
            rows={1}
            id="chat-input"
          />
          <button
            className={`send-btn ${isStreaming ? 'abort' : ''}`}
            onClick={handleSubmit}
            disabled={disabled && !isStreaming}
            title={isStreaming ? 'Stop generating' : 'Send message'}
            id="btn-send"
          >
            {isStreaming ? (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <rect x="6" y="6" width="12" height="12" rx="2"/>
              </svg>
            ) : (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13"/>
                <polygon points="22 2 15 22 11 13 2 9 22 2"/>
              </svg>
            )}
          </button>
        </div>
        <div className="input-hints">
          <span><kbd>Enter</kbd> Send</span>
          <span><kbd>Shift+Enter</kbd> New line</span>
          {isStreaming && <span style={{ color: 'var(--accent-warning)' }}>⏳ Generating...</span>}
        </div>
      </div>
    </div>
  );
}
