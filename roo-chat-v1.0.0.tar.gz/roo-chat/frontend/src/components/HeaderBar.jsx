import React from 'react';

export default function HeaderBar({
  title,
  modelInfo,
  sidebarOpen,
  onToggleSidebar,
  rightPanelOpen,
  onToggleRightPanel
}) {
  return (
    <header className="header-bar" id="header-bar">
      <button
        className="toggle-sidebar"
        onClick={onToggleSidebar}
        title={sidebarOpen ? 'Hide sidebar' : 'Show sidebar'}
        id="btn-toggle-sidebar"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
          <line x1="9" y1="3" x2="9" y2="21"/>
        </svg>
      </button>

      <span className="header-title">{title}</span>

      <div className="model-badge" id="model-badge">
        <svg className="model-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2a4 4 0 0 0-4 4v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2h-2V6a4 4 0 0 0-4-4z"/>
          <circle cx="9" cy="15" r="1"/>
          <circle cx="15" cy="15" r="1"/>
        </svg>
        {modelInfo?.model || 'gpt-4'}
      </div>

      <div className="header-actions">
        <button
          onClick={onToggleRightPanel}
          title={rightPanelOpen ? 'Hide panel' : 'Show tools panel'}
          id="btn-toggle-right-panel"
          className={rightPanelOpen ? 'active' : ''}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
            <line x1="15" y1="3" x2="15" y2="21"/>
          </svg>
        </button>
      </div>
    </header>
  );
}
