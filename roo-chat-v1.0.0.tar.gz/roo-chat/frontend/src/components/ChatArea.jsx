import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

function CopyButton({ text }) {
    const [copied, setCopied] = useState(false);
    const handleCopy = () => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };
    return (
        <button className={`copy-btn ${copied ? 'copied' : ''}`} onClick={handleCopy}>
            {copied ? (
                <>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                    Copied
                </>
            ) : (
                <>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>
                    Copy
                </>
            )}
        </button>
    );
}

function CodeBlock({ language, children }) {
    const codeString = String(children).replace(/\n$/, '');
    return (
        <div>
            <div className="code-block-header">
                <span>{language || 'text'}</span>
                <CopyButton text={codeString} />
            </div>
            <SyntaxHighlighter
                language={language || 'text'}
                style={oneDark}
                customStyle={{
                    margin: 0,
                    padding: '16px',
                    fontSize: '13px',
                    borderRadius: 0,
                    background: '#0d1117',
                }}
                wrapLongLines
            >
                {codeString}
            </SyntaxHighlighter>
        </div>
    );
}

function ToolCallItem({ toolCall }) {
    const [expanded, setExpanded] = useState(false);
    const name = toolCall.name || toolCall.toolName || 'unknown';
    const serverName = toolCall.serverName || '';
    const status = toolCall.status || 'pending';
    let argsStr = '';
    try {
        const args = typeof toolCall.arguments === 'string'
            ? JSON.parse(toolCall.arguments)
            : toolCall.arguments;
        argsStr = JSON.stringify(args, null, 2);
    } catch {
        argsStr = String(toolCall.arguments || '{}');
    }

    let resultStr = '';
    if (toolCall.result) {
        try {
            resultStr = typeof toolCall.result === 'string'
                ? toolCall.result
                : JSON.stringify(toolCall.result, null, 2);
        } catch {
            resultStr = String(toolCall.result);
        }
    }

    const statusIcons = {
        pending: (
            <svg className="tool-status" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>
        ),
        running: (
            <svg className="tool-status running" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12a9 9 0 1 1-6.219-8.56" /></svg>
        ),
        success: (
            <svg className="tool-status success" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></svg>
        ),
        error: (
            <svg className="tool-status error" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10" /><line x1="15" y1="9" x2="9" y2="15" /><line x1="9" y1="9" x2="15" y2="15" /></svg>
        ),
    };

    return (
        <div className="tool-call">
            <div className="tool-call-header" onClick={() => setExpanded(!expanded)}>
                <svg className="tool-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
                </svg>
                <span className="tool-name">{name}</span>
                {serverName && <span className="tool-server">{serverName}</span>}
                <svg
                    width="14" height="14" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" strokeWidth="2"
                    style={{ transform: expanded ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s', marginLeft: 'auto', marginRight: '4px', color: 'var(--text-tertiary)' }}
                >
                    <polyline points="6 9 12 15 18 9" />
                </svg>
                {statusIcons[status] || statusIcons.pending}
            </div>
            {expanded && (
                <>
                    <div className="tool-call-args">
                        <span className="arg-label">Arguments:</span>
                        <pre style={{ margin: '4px 0 0', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{argsStr}</pre>
                    </div>
                    {resultStr && (
                        <div className="tool-call-body">
                            {resultStr.length > 2000 ? resultStr.substring(0, 2000) + '\n... (truncated)' : resultStr}
                        </div>
                    )}
                </>
            )}
        </div>
    );
}

function MessageContent({ content }) {
    if (!content) return null;
    return (
        <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
                code({ node, inline, className, children, ...props }) {
                    const match = /language-(\w+)/.exec(className || '');
                    if (!inline && match) {
                        return <CodeBlock language={match[1]}>{children}</CodeBlock>;
                    }
                    if (!inline && !match && String(children).includes('\n')) {
                        return <CodeBlock language="text">{children}</CodeBlock>;
                    }
                    return <code className={className} {...props}>{children}</code>;
                },
                pre({ children }) {
                    return <pre>{children}</pre>;
                }
            }}
        >
            {content}
        </ReactMarkdown>
    );
}

function Message({ message, onSuggestionClick }) {
    const isUser = message.role === 'user';
    const isError = message.isError;
    const time = message.created_at
        ? new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : '';

    return (
        <div className={`message ${isError ? 'error' : ''}`} id={`msg-${message.id}`}>
            <div className="message-header">
                <div className={`message-avatar ${isUser ? 'user' : 'assistant'}`}>
                    {isUser ? '👤' : '🤖'}
                </div>
                <span className="message-author">{isUser ? 'You' : 'Roo'}</span>
                {time && <span className="message-time">{time}</span>}
            </div>
            <div className="message-body">
                <MessageContent content={message.content} />
                {/* Tool calls */}
                {message.tool_calls && Array.isArray(message.tool_calls) && message.tool_calls.length > 0 && (
                    <div className="tool-calls-container">
                        {message.tool_calls.map((tc, idx) => (
                            <ToolCallItem key={tc.id || idx} toolCall={tc} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

function StreamingMessage({ content, toolCalls, isStreaming }) {
    return (
        <div className="message" id="streaming-message">
            <div className="message-header">
                <div className="message-avatar assistant">🤖</div>
                <span className="message-author">Roo</span>
                {isStreaming && (
                    <span className="streaming-badge">
                        <span className="streaming-indicator">
                            <span className="dot" />
                            <span className="dot" />
                            <span className="dot" />
                        </span>
                    </span>
                )}
            </div>
            <div className="message-body">
                {content && <MessageContent content={content} />}
                {(!content && isStreaming && (!toolCalls || toolCalls.length === 0)) && (
                    <div className="streaming-indicator">
                        <span className="dot" />
                        <span className="dot" />
                        <span className="dot" />
                    </div>
                )}
                {toolCalls && toolCalls.length > 0 && (
                    <div className="tool-calls-container">
                        {toolCalls.map((tc, idx) => (
                            <ToolCallItem key={tc.id || idx} toolCall={tc} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

export default function ChatArea({
    messages,
    streamingContent,
    isStreaming,
    toolCalls,
    messagesEndRef,
    onSuggestionClick
}) {
    return (
        <div className="messages-container" id="messages-container">
            <div className="messages-inner">
                {messages.map((msg, idx) => (
                    <Message key={msg.id || idx} message={msg} onSuggestionClick={onSuggestionClick} />
                ))}
                {(isStreaming || streamingContent) && (
                    <StreamingMessage
                        content={streamingContent}
                        toolCalls={toolCalls}
                        isStreaming={isStreaming}
                    />
                )}
                <div ref={messagesEndRef} />
            </div>
        </div>
    );
}
