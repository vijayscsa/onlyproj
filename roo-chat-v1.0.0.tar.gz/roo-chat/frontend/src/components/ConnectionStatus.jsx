import React, { useState, useEffect } from 'react';

export default function ConnectionStatus({ status }) {
    const [visible, setVisible] = useState(false);
    const [lastStatus, setLastStatus] = useState(status);

    useEffect(() => {
        if (status !== lastStatus) {
            setLastStatus(status);
            setVisible(true);

            // Auto-hide after 3 seconds for connected status
            if (status === 'connected') {
                const timer = setTimeout(() => setVisible(false), 3000);
                return () => clearTimeout(timer);
            }
        }
    }, [status, lastStatus]);

    // Always show if disconnected or connecting
    const shouldShow = visible || status !== 'connected';

    if (!shouldShow) return null;

    const labels = {
        connected: '● Connected',
        connecting: '◌ Connecting...',
        disconnected: '○ Disconnected'
    };

    return (
        <div className={`connection-status ${status}`} id="connection-status">
            {labels[status] || status}
        </div>
    );
}
