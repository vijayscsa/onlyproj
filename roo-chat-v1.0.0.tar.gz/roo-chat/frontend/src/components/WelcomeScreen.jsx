import React from 'react';

const suggestions = [
    {
        icon: '📁',
        title: 'Explore Files',
        desc: 'List files in the home directory',
        prompt: 'List the files and directories in /home/ravinv1/'
    },
    {
        icon: '🔍',
        title: 'Search Code',
        desc: 'Find code patterns in files',
        prompt: 'Search for README files in /home/ravinv1/ and show their contents'
    },
    {
        icon: '📝',
        title: 'Read a File',
        desc: 'View file contents with syntax highlighting',
        prompt: 'Read and explain the contents of /home/ravinv1/appli1/roo-chat/package.json'
    },
    {
        icon: '🛠️',
        title: 'MCP Tools',
        desc: 'Show available MCP tools',
        prompt: 'What MCP tools do you have access to? List and describe each one.'
    },
    {
        icon: '💡',
        title: 'Code Review',
        desc: 'Analyze code quality',
        prompt: 'Review the code architecture of the roo-chat project in /home/ravinv1/appli1/roo-chat/'
    },
    {
        icon: '🏗️',
        title: 'Project Structure',
        desc: 'Understand project layout',
        prompt: 'Analyze the project structure of /home/ravinv1/appli1/roo-chat/ and explain the architecture'
    }
];

export default function WelcomeScreen({ onSuggestionClick }) {
    return (
        <div className="welcome-screen" id="welcome-screen">
            <div className="welcome-logo">🤖</div>
            <h1 className="welcome-title">Welcome to Roo Chat</h1>
            <p className="welcome-subtitle">
                Your AI-powered coding assistant with MCP (Model Context Protocol) integration.
                I can read files, search code, explore directories, and help you with development tasks.
            </p>
            <div className="welcome-cards">
                {suggestions.map((s, idx) => (
                    <div
                        key={idx}
                        className="welcome-card"
                        onClick={() => onSuggestionClick(s.prompt)}
                        id={`suggestion-card-${idx}`}
                    >
                        <div className="card-icon">{s.icon}</div>
                        <div className="card-title">{s.title}</div>
                        <div className="card-desc">{s.desc}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}
