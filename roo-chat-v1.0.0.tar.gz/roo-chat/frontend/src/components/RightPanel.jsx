import React, { useState, useEffect, useCallback } from 'react';

function FileTree({ apiUrl }) {
  const [tree, setTree] = useState([]);
  const [expanded, setExpanded] = useState({});
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileContent, setFileContent] = useState('');
  const rootPath = '/home/ravinv1';

  const loadDir = useCallback(async (dirPath) => {
    try {
      const res = await fetch(`${apiUrl}/files/list`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: dirPath })
      });
      const items = await res.json();
      return items;
    } catch {
      return [];
    }
  }, [apiUrl]);

  useEffect(() => {
    loadDir(rootPath).then(items => setTree(items));
  }, [loadDir, rootPath]);

  const toggleDir = useCallback(async (item) => {
    if (!item.isDirectory) {
      setSelectedFile(item.path);
      try {
        const res = await fetch(`${apiUrl}/files/read`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ path: item.path })
        });
        const data = await res.json();
        setFileContent(data.content || '');
      } catch {
        setFileContent('Error loading file');
      }
      return;
    }

    const key = item.path;
    if (expanded[key]) {
      setExpanded(prev => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
    } else {
      const children = await loadDir(item.path);
      setExpanded(prev => ({ ...prev, [key]: children }));
    }
  }, [apiUrl, expanded, loadDir]);

  const renderItems = (items, depth = 0) => {
    return items.map(item => (
      <React.Fragment key={item.path}>
        <div
          className={`file-tree-item indent-${Math.min(depth, 3)}`}
          onClick={() => toggleDir(item)}
          title={item.path}
        >
          {item.isDirectory ? (
            <svg className="tree-icon folder" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              {expanded[item.path] ? (
                <><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></>
              ) : (
                <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
              )}
            </svg>
          ) : (
            <svg className="tree-icon file" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/>
              <polyline points="13 2 13 9 20 9"/>
            </svg>
          )}
          <span style={{ fontSize: '13px' }}>{item.name}</span>
        </div>
        {expanded[item.path] && renderItems(expanded[item.path], depth + 1)}
      </React.Fragment>
    ));
  };

  return (
    <div>
      <div className="file-tree" id="file-tree">
        {tree.length === 0 ? (
          <div className="empty-state" style={{ padding: '24px' }}>
            <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>Loading file tree…</span>
          </div>
        ) : (
          renderItems(tree)
        )}
      </div>
      {selectedFile && (
        <div style={{ borderTop: '1px solid var(--border-muted)', padding: '8px 12px' }}>
          <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 4, fontFamily: 'var(--font-mono)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {selectedFile}
          </div>
          <pre style={{
            fontSize: 12, color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)',
            background: 'var(--bg-primary)', border: '1px solid var(--border-default)',
            borderRadius: 'var(--radius-md)', padding: 12, maxHeight: 300, overflow: 'auto',
            whiteSpace: 'pre-wrap', wordBreak: 'break-all'
          }}>
            {fileContent.length > 5000 ? fileContent.substring(0, 5000) + '\n... (truncated)' : fileContent}
          </pre>
        </div>
      )}
    </div>
  );
}

function TasksPanel({ tasks }) {
  if (!tasks || tasks.length === 0) {
    return (
      <div className="empty-state" style={{ padding: '48px 24px' }}>
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M9 11l3 3L22 4"/>
          <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
        </svg>
        <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>No tasks yet</span>
      </div>
    );
  }

  return (
    <div className="tasks-panel" id="tasks-panel">
      {[...tasks].reverse().map((task, idx) => (
        <div className="task-item" key={task.id || idx}>
          <div className="task-header">
            <span className="task-title">{task.title}</span>
            <span className={`task-status ${task.status}`}>{task.status}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

function McpServersPanel({ mcpTools }) {
  if (!mcpTools || Object.keys(mcpTools).length === 0) {
    return (
      <div className="empty-state" style={{ padding: '48px 24px' }}>
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="2" y="2" width="20" height="8" rx="2" ry="2"/>
          <rect x="2" y="14" width="20" height="8" rx="2" ry="2"/>
          <line x1="6" y1="6" x2="6.01" y2="6"/>
          <line x1="6" y1="18" x2="6.01" y2="18"/>
        </svg>
        <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>No MCP servers connected</span>
      </div>
    );
  }

  return (
    <div className="mcp-servers-panel" id="mcp-servers-panel">
      {Object.entries(mcpTools).map(([serverName, info]) => (
        <div className="mcp-server-card" key={serverName}>
          <div className="server-header">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--accent-cyan)' }}>
              <rect x="2" y="2" width="20" height="8" rx="2" ry="2"/>
              <rect x="2" y="14" width="20" height="8" rx="2" ry="2"/>
              <line x1="6" y1="6" x2="6.01" y2="6"/>
              <line x1="6" y1="18" x2="6.01" y2="18"/>
            </svg>
            <span className="server-name">{serverName}</span>
            <span className="server-status-badge">
              {info.ready !== false ? '● Active' : '○ Inactive'}
            </span>
          </div>
          {info.tools && info.tools.length > 0 && (
            <>
              <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 4, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Tools ({info.tools.length})
              </div>
              <ul className="mcp-tool-list">
                {info.tools.map((tool, idx) => (
                  <li className="mcp-tool-item" key={idx} title={tool.description}>
                    <span className="tool-dot"/>
                    <span style={{ fontFamily: 'var(--font-mono)' }}>{tool.name}</span>
                  </li>
                ))}
              </ul>
            </>
          )}
          {info.resources && info.resources.length > 0 && (
            <>
              <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 12, marginBottom: 4, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Resources ({info.resources.length})
              </div>
              <ul className="mcp-tool-list">
                {info.resources.map((res, idx) => (
                  <li className="mcp-tool-item" key={idx} title={res.description}>
                    <span className="tool-dot" style={{ background: 'var(--accent-purple)' }}/>
                    <span style={{ fontFamily: 'var(--font-mono)' }}>{res.name || res.uri}</span>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      ))}
    </div>
  );
}

export default function RightPanel({ open, tasks, mcpTools, apiUrl }) {
  const [activeTab, setActiveTab] = useState('tools');

  const tabs = [
    { id: 'tools', label: 'MCP Servers', icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>
    )},
    { id: 'tasks', label: 'Tasks', icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
    )},
    { id: 'files', label: 'Files', icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
    )},
  ];

  return (
    <div className={`right-panel ${open ? '' : 'collapsed'}`} id="right-panel">
      <div className="panel-tabs">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`panel-tab ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>
      <div className="panel-content">
        {activeTab === 'tools' && <McpServersPanel mcpTools={mcpTools} />}
        {activeTab === 'tasks' && <TasksPanel tasks={tasks} />}
        {activeTab === 'files' && <FileTree apiUrl={apiUrl} />}
      </div>
    </div>
  );
}
