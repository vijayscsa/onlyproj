import { useState, useRef, useCallback, useEffect } from 'react';

export function useWebSocket(url) {
  const [status, setStatus] = useState('disconnected'); // connected, disconnected, connecting
  const [initData, setInitData] = useState(null);
  const wsRef = useRef(null);
  const handlersRef = useRef({});
  const reconnectTimerRef = useRef(null);
  const reconnectAttemptsRef = useRef(0);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    setStatus('connecting');
    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onopen = () => {
      setStatus('connected');
      reconnectAttemptsRef.current = 0;
      console.log('🔌 WebSocket connected');
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'init') {
          setInitData(msg);
        }
        // Call registered handler
        if (handlersRef.current[msg.type]) {
          handlersRef.current[msg.type](msg);
        }
        // Call catch-all handler
        if (handlersRef.current['*']) {
          handlersRef.current['*'](msg);
        }
      } catch (err) {
        console.error('WebSocket message parse error:', err);
      }
    };

    ws.onclose = () => {
      setStatus('disconnected');
      console.log('🔌 WebSocket disconnected');

      // Auto-reconnect with backoff
      const delay = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 10000);
      reconnectAttemptsRef.current++;
      reconnectTimerRef.current = setTimeout(connect, delay);
    };

    ws.onerror = (err) => {
      console.error('WebSocket error:', err);
    };
  }, [url]);

  const disconnect = useCallback(() => {
    if (reconnectTimerRef.current) {
      clearTimeout(reconnectTimerRef.current);
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  }, []);

  const send = useCallback((data) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(data));
    }
  }, []);

  const on = useCallback((type, handler) => {
    handlersRef.current[type] = handler;
    return () => {
      delete handlersRef.current[type];
    };
  }, []);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  return { status, send, on, initData, connect, disconnect };
}
