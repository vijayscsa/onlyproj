import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useWebSocket } from './hooks/useWebSocket';
import Sidebar from './components/Sidebar';
import HeaderBar from './components/HeaderBar';
import ChatArea from './components/ChatArea';
import InputArea from './components/InputArea';
import RightPanel from './components/RightPanel';
import WelcomeScreen from './components/WelcomeScreen';
import ConnectionStatus from './components/ConnectionStatus';

const WS_URL = `ws://${window.location.hostname}:8010/ws`;
const API_URL = `http://${window.location.hostname}:8010/api`;

export default function App() {
  const { status, send, on, initData } = useWebSocket(WS_URL);

  // State
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [rightPanelOpen, setRightPanelOpen] = useState(false);
  const [conversations, setConversations] = useState([]);
  const [currentConversationId, setCurrentConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingContent, setStreamingContent] = useState('');
  const [streamingMsgId, setStreamingMsgId] = useState(null);
  const [toolCalls, setToolCalls] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [currentTitle, setCurrentTitle] = useState('New Conversation');
  const [mcpTools, setMcpTools] = useState({});
  const [modelInfo, setModelInfo] = useState({ model: 'gpt-4', baseUrl: '' });

  // Refs
  const messagesEndRef = useRef(null);

  // Scroll to bottom
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingContent, scrollToBottom]);

  // Fetch conversations
  const fetchConversations = useCallback(async () => {
    try {
      const res = await fetch(`${API_URL}/conversations`);
      const data = await res.json();
      setConversations(data);
    } catch (err) {
      console.error('Failed to fetch conversations:', err);
    }
  }, []);

  useEffect(() => {
    fetchConversations();
  }, [fetchConversations]);

  // WebSocket message handlers
  useEffect(() => {
    const handlers = [];

    handlers.push(on('init', (msg) => {
      setModelInfo(msg.model || {});
      setMcpTools(msg.tools || {});
    }));

    handlers.push(on('conversation_created', (msg) => {
      setCurrentConversationId(msg.conversationId);
      fetchConversations();
    }));

    handlers.push(on('conversation_loaded', (msg) => {
      setMessages(msg.messages || []);
      setCurrentConversationId(msg.conversationId);
    }));

    handlers.push(on('conversation_titled', (msg) => {
      setCurrentTitle(msg.title);
      fetchConversations();
    }));

    handlers.push(on('message_saved', () => {
      // User message saved
    }));

    handlers.push(on('stream_start', (msg) => {
      setIsStreaming(true);
      setStreamingContent('');
      setStreamingMsgId(msg.messageId);
    }));

    handlers.push(on('stream_token', (msg) => {
      setStreamingContent(prev => prev + msg.token);
    }));

    handlers.push(on('tool_calls', (msg) => {
      setToolCalls(prev => [...prev, ...msg.toolCalls.map(tc => ({
        ...tc,
        status: 'pending',
        result: null
      }))]);
    }));

    handlers.push(on('tool_executing', (msg) => {
      setToolCalls(prev => prev.map(tc =>
        tc.id === msg.toolCallId
          ? { ...tc, status: 'running', serverName: msg.serverName, toolName: msg.toolName, arguments: msg.arguments }
          : tc
      ));

      setTasks(prev => [...prev, {
        id: msg.taskId,
        title: `${msg.serverName}/${msg.toolName}`,
        status: 'in_progress',
        args: msg.arguments
      }]);
    }));

    handlers.push(on('tool_result', (msg) => {
      setToolCalls(prev => prev.map(tc =>
        tc.id === msg.toolCallId
          ? { ...tc, status: msg.status, result: msg.result }
          : tc
      ));

      setTasks(prev => prev.map(t =>
        t.id === msg.taskId
          ? { ...t, status: msg.status === 'success' ? 'completed' : 'failed', result: msg.result }
          : t
      ));
    }));

    handlers.push(on('tool_loop_continue', () => {
      // Tool loop continuing - reset streaming for next response
      if (streamingContent) {
        setMessages(prev => [...prev, {
          id: streamingMsgId,
          role: 'assistant',
          content: streamingContent,
          tool_calls: toolCalls.length > 0 ? toolCalls : null
        }]);
      }
      setStreamingContent('');
      setToolCalls([]);
    }));

    handlers.push(on('stream_end', (msg) => {
      setIsStreaming(false);

      // Add final message
      setMessages(prev => {
        const newMsg = {
          id: msg.messageId || streamingMsgId,
          role: 'assistant',
          content: streamingContent,
          tool_calls: toolCalls.length > 0 ? toolCalls : null,
          created_at: new Date().toISOString()
        };
        return [...prev, newMsg];
      });

      setStreamingContent('');
      setStreamingMsgId(null);
      setToolCalls([]);
    }));

    handlers.push(on('stream_error', (msg) => {
      setIsStreaming(false);
      setMessages(prev => [...prev, {
        id: 'error-' + Date.now(),
        role: 'assistant',
        content: `❌ Error: ${msg.error}`,
        isError: true
      }]);
      setStreamingContent('');
    }));

    handlers.push(on('aborted', () => {
      setIsStreaming(false);
      if (streamingContent) {
        setMessages(prev => [...prev, {
          id: 'aborted-' + Date.now(),
          role: 'assistant',
          content: streamingContent + '\n\n*[Response aborted]*'
        }]);
      }
      setStreamingContent('');
    }));

    return () => {
      handlers.forEach(unsub => unsub && unsub());
    };
  }, [on, fetchConversations, streamingContent, streamingMsgId, toolCalls]);

  // Send message
  const sendMessage = useCallback((content) => {
    if (!content.trim() || isStreaming) return;

    // Add user message to local state
    const userMsg = {
      id: 'user-' + Date.now(),
      role: 'user',
      content: content.trim(),
      created_at: new Date().toISOString()
    };
    setMessages(prev => [...prev, userMsg]);

    // Send via WebSocket
    send({ type: 'chat', content: content.trim() });
  }, [send, isStreaming]);

  // New conversation
  const newConversation = useCallback(() => {
    setMessages([]);
    setCurrentConversationId(null);
    setCurrentTitle('New Conversation');
    setToolCalls([]);
    setTasks([]);
    send({ type: 'new_conversation' });
  }, [send]);

  // Load conversation
  const loadConversation = useCallback(async (id) => {
    try {
      const res = await fetch(`${API_URL}/conversations/${id}`);
      const data = await res.json();
      setMessages(data.messages || []);
      setCurrentConversationId(id);
      setCurrentTitle(data.title || 'Conversation');
      setTasks(data.tasks || []);
      setToolCalls([]);
      send({ type: 'load_conversation', conversationId: id });
    } catch (err) {
      console.error('Failed to load conversation:', err);
    }
  }, [send]);

  // Delete conversation
  const deleteConversation = useCallback(async (id) => {
    try {
      await fetch(`${API_URL}/conversations/${id}`, { method: 'DELETE' });
      if (currentConversationId === id) {
        setMessages([]);
        setCurrentConversationId(null);
        setCurrentTitle('New Conversation');
      }
      fetchConversations();
    } catch (err) {
      console.error('Failed to delete conversation:', err);
    }
  }, [currentConversationId, fetchConversations]);

  // Abort streaming
  const abortStreaming = useCallback(() => {
    send({ type: 'abort' });
  }, [send]);

  const hasMessages = messages.length > 0 || streamingContent;

  return (
    <div className="app-layout">
      <Sidebar
        open={sidebarOpen}
        conversations={conversations}
        currentId={currentConversationId}
        onNewChat={newConversation}
        onSelectChat={loadConversation}
        onDeleteChat={deleteConversation}
        mcpServers={initData?.mcpServers || []}
        connectionStatus={status}
      />

      <div className="main-content">
        <HeaderBar
          title={currentTitle}
          modelInfo={modelInfo}
          sidebarOpen={sidebarOpen}
          onToggleSidebar={() => setSidebarOpen(p => !p)}
          rightPanelOpen={rightPanelOpen}
          onToggleRightPanel={() => setRightPanelOpen(p => !p)}
        />

        <div className="chat-container">
          <div className="chat-area">
            {hasMessages ? (
              <ChatArea
                messages={messages}
                streamingContent={streamingContent}
                isStreaming={isStreaming}
                toolCalls={toolCalls}
                messagesEndRef={messagesEndRef}
                onSuggestionClick={sendMessage}
              />
            ) : (
              <WelcomeScreen onSuggestionClick={sendMessage} />
            )}

            <InputArea
              onSend={sendMessage}
              onAbort={abortStreaming}
              isStreaming={isStreaming}
              disabled={status !== 'connected'}
            />
          </div>

          <RightPanel
            open={rightPanelOpen}
            tasks={tasks}
            mcpTools={mcpTools}
            apiUrl={API_URL}
          />
        </div>
      </div>

      <ConnectionStatus status={status} />
    </div>
  );
}
