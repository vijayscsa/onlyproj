import dotenv from 'dotenv';
import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import rateLimit from 'express-rate-limit';
import { initDb } from './db.js';
import { setupWebSocket } from './websocket.js';
import { apiRouter } from './routes/api.js';
import { McpManager } from './mcp/manager.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Load .env from project root
dotenv.config({ path: path.join(__dirname, '..', '..', '.env') });

const app = express();
const server = createServer(app);

// Configuration
const PORT = process.env.BACKEND_PORT || 8010;

// Middleware
app.use(cors({
  origin: [
    `http://localhost:${process.env.FRONTEND_PORT || 3010}`,
    'http://localhost:3010',
    'http://localhost:3011',
    'http://localhost:3012'
  ],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000'),
  max: parseInt(process.env.RATE_LIMIT_MAX || '100'),
  message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

// Initialize database
const db = initDb(process.env.DB_PATH || './data/roo-chat.db');

// Initialize MCP Manager
const mcpSettingsPath = path.join(__dirname, '..', '..', 'mcp_settings.json');
const mcpManager = new McpManager(mcpSettingsPath);

// REST API routes
app.use('/api', apiRouter(db, mcpManager));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// WebSocket server
const wss = new WebSocketServer({ server, path: '/ws' });
setupWebSocket(wss, db, mcpManager);

// Start server
async function start() {
  try {
    await mcpManager.initialize();
    console.log('✅ MCP servers initialized');

    server.listen(PORT, '0.0.0.0', () => {
      console.log(`🚀 Roo Chat Backend running on http://localhost:${PORT}`);
      console.log(`📡 WebSocket available at ws://localhost:${PORT}/ws`);
      console.log(`🔧 MCP Servers: ${mcpManager.getServerNames().join(', ') || 'none configured'}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
const shutdown = async () => {
  console.log('\nShutting down gracefully...');
  await mcpManager.shutdown();
  db.close();
  server.close();
  process.exit(0);
};

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

start();
