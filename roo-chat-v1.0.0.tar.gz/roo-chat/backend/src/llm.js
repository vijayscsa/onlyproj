import OpenAI from 'openai';

export class LLMClient {
  constructor() {
    this.client = new OpenAI({
      baseURL: process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1',
      apiKey: process.env.OPENAI_API_KEY || '',
    });
    this.model = process.env.OPENAI_MODEL || 'gpt-4';
  }

  async *streamChat(messages, tools = [], options = {}) {
    const params = {
      model: options.model || this.model,
      messages,
      stream: true,
      temperature: options.temperature ?? 0.7,
      max_tokens: options.maxTokens || 4096,
    };

    if (tools.length > 0) {
      params.tools = tools;
      params.tool_choice = options.toolChoice || 'auto';
    }

    try {
      const stream = await this.client.chat.completions.create(params);
      let currentToolCalls = {};
      let contentBuffer = '';

      for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta;
        const finishReason = chunk.choices[0]?.finish_reason;

        if (delta?.content) {
          contentBuffer += delta.content;
          yield { type: 'content', content: delta.content, accumulated: contentBuffer };
        }

        if (delta?.tool_calls) {
          for (const tc of delta.tool_calls) {
            const idx = tc.index;
            if (!currentToolCalls[idx]) {
              currentToolCalls[idx] = {
                id: tc.id || '',
                type: 'function',
                function: { name: '', arguments: '' }
              };
            }
            if (tc.id) currentToolCalls[idx].id = tc.id;
            if (tc.function?.name) currentToolCalls[idx].function.name += tc.function.name;
            if (tc.function?.arguments) currentToolCalls[idx].function.arguments += tc.function.arguments;
          }
        }

        if (finishReason === 'tool_calls') {
          yield { type: 'tool_calls', toolCalls: Object.values(currentToolCalls) };
          currentToolCalls = {};
        }

        if (finishReason === 'stop') {
          yield { type: 'done', content: contentBuffer, finishReason: 'stop' };
        }
      }
    } catch (error) {
      yield { type: 'error', error: error.message };
    }
  }

  async chat(messages, tools = [], options = {}) {
    const params = {
      model: options.model || this.model,
      messages,
      temperature: options.temperature ?? 0.7,
      max_tokens: options.maxTokens || 4096,
    };

    if (tools.length > 0) {
      params.tools = tools;
      params.tool_choice = options.toolChoice || 'auto';
    }

    const response = await this.client.chat.completions.create(params);
    return response.choices[0];
  }

  getModelInfo() {
    return {
      model: this.model,
      baseUrl: process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1',
    };
  }
}
