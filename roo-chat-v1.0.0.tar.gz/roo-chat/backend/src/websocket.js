import { v4 as uuidv4 } from 'uuid';
import { LLMClient } from './llm.js';

const llmClient = new LLMClient();

export function setupWebSocket(wss, db, mcpManager) {
  const insertConversation = db.prepare('INSERT INTO conversations (id, title) VALUES (?, ?)');
  const insertMessage = db.prepare(
    'INSERT INTO messages (id, conversation_id, role, content, tool_calls, tool_call_id, metadata) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );
  const getMessages = db.prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC');
  const updateConversationTitle = db.prepare('UPDATE conversations SET title = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
  const insertTask = db.prepare('INSERT INTO tasks (id, conversation_id, title, status, description) VALUES (?, ?, ?, ?, ?)');
  const updateTask = db.prepare('UPDATE tasks SET status = ?, result = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');

  wss.on('connection', (ws) => {
    console.log('🔌 Client connected');
    let currentConversationId = null;
    let abortController = null;

    ws.on('message', async (data) => {
      try {
        const msg = JSON.parse(data.toString());
        await handleMessage(ws, msg, db, mcpManager, {
          insertConversation, insertMessage, getMessages,
          updateConversationTitle, insertTask, updateTask,
          getCurrentConversationId: () => currentConversationId,
          setCurrentConversationId: (id) => { currentConversationId = id; },
          getAbortController: () => abortController,
          setAbortController: (ac) => { abortController = ac; }
        });
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({ type: 'error', error: error.message }));
      }
    });

    ws.on('close', () => {
      console.log('🔌 Client disconnected');
      if (abortController) abortController.abort();
    });

    ws.send(JSON.stringify({
      type: 'init',
      model: llmClient.getModelInfo(),
      tools: mcpManager.getToolsInfo(),
      mcpServers: mcpManager.getServerNames()
    }));
  });
}

async function handleMessage(ws, msg, db, mcpManager, stmts) {
  switch (msg.type) {
    case 'chat':
      await handleChat(ws, msg, db, mcpManager, stmts);
      break;
    case 'new_conversation': {
      const id = uuidv4();
      stmts.insertConversation.run(id, 'New Conversation');
      stmts.setCurrentConversationId(id);
      ws.send(JSON.stringify({ type: 'conversation_created', conversationId: id }));
      break;
    }
    case 'load_conversation': {
      stmts.setCurrentConversationId(msg.conversationId);
      const messages = stmts.getMessages.all(msg.conversationId);
      ws.send(JSON.stringify({
        type: 'conversation_loaded',
        conversationId: msg.conversationId,
        messages: messages.map(m => ({
          ...m,
          tool_calls: m.tool_calls ? JSON.parse(m.tool_calls) : null,
          metadata: m.metadata ? JSON.parse(m.metadata) : {}
        }))
      }));
      break;
    }
    case 'abort': {
      const ac = stmts.getAbortController();
      if (ac) ac.abort();
      ws.send(JSON.stringify({ type: 'aborted' }));
      break;
    }
    default:
      ws.send(JSON.stringify({ type: 'error', error: `Unknown message type: ${msg.type}` }));
  }
}

async function handleChat(ws, msg, db, mcpManager, stmts) {
  let conversationId = stmts.getCurrentConversationId();

  if (!conversationId) {
    conversationId = uuidv4();
    stmts.insertConversation.run(conversationId, 'New Conversation');
    stmts.setCurrentConversationId(conversationId);
    ws.send(JSON.stringify({ type: 'conversation_created', conversationId }));
  }

  const userMsgId = uuidv4();
  stmts.insertMessage.run(userMsgId, conversationId, 'user', msg.content, null, null, JSON.stringify({ timestamp: Date.now() }));
  ws.send(JSON.stringify({ type: 'message_saved', messageId: userMsgId, role: 'user' }));

  const history = stmts.getMessages.all(conversationId).map(m => {
    const result = { role: m.role, content: m.content };
    if (m.tool_calls) result.tool_calls = JSON.parse(m.tool_calls);
    if (m.tool_call_id) result.tool_call_id = m.tool_call_id;
    return result;
  });

  const systemMessage = {
    role: 'system',
    content: `You are Roo, an expert AI coding assistant powered by MCP (Model Context Protocol) servers. You have access to tools that let you interact with the filesystem, search code, and perform various operations.

Available MCP servers: ${mcpManager.getServerNames().join(', ') || 'none'}.

Guidelines:
- Be helpful, clear, and actionable
- Use tools when you need to read files, list directories, or search
- Format code with markdown code blocks and specify the language
- Explain your reasoning when using tools
- Be concise but thorough
- When showing file changes, use diff format when appropriate`
  };

  const messages = [systemMessage, ...history];

  const mcpTools = mcpManager.getAllTools();
  const openaiTools = mcpTools.map(t => ({ type: t.type, function: t.function }));

  await streamWithToolLoop(ws, messages, openaiTools, mcpTools, mcpManager, conversationId, stmts);

  // Auto-title after first exchange
  if (history.length <= 1) {
    try {
      const titleResult = await llmClient.chat([
        { role: 'system', content: 'Generate a short title (max 6 words) for this conversation. Reply with only the title, no quotes.' },
        { role: 'user', content: msg.content }
      ]);
      const title = titleResult.message?.content?.trim() || 'New Conversation';
      stmts.updateConversationTitle.run(title, conversationId);
      ws.send(JSON.stringify({ type: 'conversation_titled', conversationId, title }));
    } catch (e) { /* non-critical */ }
  }
}

async function streamWithToolLoop(ws, messages, openaiTools, mcpTools, mcpManager, conversationId, stmts) {
  let iteration = 0;
  const maxIterations = 10;

  while (iteration < maxIterations) {
    iteration++;
    const assistantMsgId = uuidv4();
    let fullContent = '';
    let toolCalls = null;

    ws.send(JSON.stringify({ type: 'stream_start', messageId: assistantMsgId }));

    for await (const chunk of llmClient.streamChat(messages, openaiTools)) {
      switch (chunk.type) {
        case 'content':
          ws.send(JSON.stringify({ type: 'stream_token', messageId: assistantMsgId, token: chunk.content }));
          fullContent = chunk.accumulated;
          break;
        case 'tool_calls':
          toolCalls = chunk.toolCalls;
          ws.send(JSON.stringify({
            type: 'tool_calls', messageId: assistantMsgId,
            toolCalls: toolCalls.map(tc => ({ id: tc.id, name: tc.function.name, arguments: tc.function.arguments }))
          }));
          break;
        case 'error':
          ws.send(JSON.stringify({ type: 'stream_error', messageId: assistantMsgId, error: chunk.error }));
          return;
        case 'done':
          fullContent = chunk.content;
          break;
      }
    }

    stmts.insertMessage.run(
      assistantMsgId, conversationId, 'assistant', fullContent || '',
      toolCalls ? JSON.stringify(toolCalls) : null, null,
      JSON.stringify({ iteration })
    );

    if (!toolCalls || toolCalls.length === 0) {
      ws.send(JSON.stringify({ type: 'stream_end', messageId: assistantMsgId }));
      return;
    }

    messages.push({ role: 'assistant', content: fullContent || null, tool_calls: toolCalls });

    for (const tc of toolCalls) {
      let args = {};
      try { args = JSON.parse(tc.function.arguments); } catch (e) { args = {}; }

      const mcpTool = mcpTools.find(t => t.function.name === tc.function.name);
      let result;

      if (mcpTool) {
        const taskId = uuidv4();
        stmts.insertTask.run(taskId, conversationId, `Tool: ${mcpTool._mcpToolName}`, 'in_progress', JSON.stringify(args));
        ws.send(JSON.stringify({
          type: 'tool_executing', toolCallId: tc.id, serverName: mcpTool._mcpServer,
          toolName: mcpTool._mcpToolName, arguments: args, taskId
        }));

        try {
          result = await mcpManager.callTool(mcpTool._mcpServer, mcpTool._mcpToolName, args);
          stmts.updateTask.run('completed', JSON.stringify(result), taskId);
          ws.send(JSON.stringify({ type: 'tool_result', toolCallId: tc.id, result, taskId, status: 'success' }));
        } catch (error) {
          result = { error: error.message };
          stmts.updateTask.run('failed', JSON.stringify(result), taskId);
          ws.send(JSON.stringify({ type: 'tool_result', toolCallId: tc.id, result, taskId, status: 'error' }));
        }
      } else {
        result = { error: `Unknown tool: ${tc.function.name}` };
      }

      const toolResultContent = typeof result === 'string' ? result :
        (result?.content ? result.content.map(c => c.text || JSON.stringify(c)).join('\n') : JSON.stringify(result));

      const toolMsgId = uuidv4();
      stmts.insertMessage.run(
        toolMsgId, conversationId, 'tool', toolResultContent,
        null, tc.id, JSON.stringify({ toolName: tc.function.name, serverName: mcpTool?._mcpServer })
      );

      messages.push({ role: 'tool', content: toolResultContent, tool_call_id: tc.id });
    }

    ws.send(JSON.stringify({ type: 'tool_loop_continue', iteration }));
  }

  ws.send(JSON.stringify({ type: 'stream_end', messageId: 'max_iterations', warning: 'Maximum tool call iterations reached' }));
}
