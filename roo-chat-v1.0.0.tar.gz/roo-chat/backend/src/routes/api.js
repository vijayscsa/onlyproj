import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import path from 'path';

export function apiRouter(db, mcpManager) {
  const router = Router();

  // Conversations
  router.get('/conversations', (req, res) => {
    const conversations = db.prepare('SELECT * FROM conversations ORDER BY updated_at DESC').all();
    res.json(conversations);
  });

  router.get('/conversations/:id', (req, res) => {
    const conv = db.prepare('SELECT * FROM conversations WHERE id = ?').get(req.params.id);
    if (!conv) return res.status(404).json({ error: 'Not found' });

    const messages = db.prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC')
      .all(req.params.id).map(m => ({
        ...m,
        tool_calls: m.tool_calls ? JSON.parse(m.tool_calls) : null,
        metadata: m.metadata ? JSON.parse(m.metadata) : {}
      }));

    const tasks = db.prepare('SELECT * FROM tasks WHERE conversation_id = ? ORDER BY created_at DESC')
      .all(req.params.id);

    res.json({ ...conv, messages, tasks });
  });

  router.post('/conversations', (req, res) => {
    const id = uuidv4();
    const title = req.body.title || 'New Conversation';
    db.prepare('INSERT INTO conversations (id, title) VALUES (?, ?)').run(id, title);
    res.json({ id, title });
  });

  router.delete('/conversations/:id', (req, res) => {
    db.prepare('DELETE FROM messages WHERE conversation_id = ?').run(req.params.id);
    db.prepare('DELETE FROM tasks WHERE conversation_id = ?').run(req.params.id);
    db.prepare('DELETE FROM checkpoints WHERE conversation_id = ?').run(req.params.id);
    db.prepare('DELETE FROM conversations WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  });

  // MCP
  router.get('/mcp/servers', (req, res) => {
    res.json(mcpManager.getToolsInfo());
  });

  router.get('/mcp/tools', (req, res) => {
    const tools = mcpManager.getAllTools().map(t => ({
      name: t.function.name,
      description: t.function.description,
      parameters: t.function.parameters,
      server: t._mcpServer
    }));
    res.json(tools);
  });

  router.get('/mcp/settings', (req, res) => {
    res.json(mcpManager.getSettings());
  });

  // Model info
  router.get('/model', (req, res) => {
    res.json({
      model: process.env.OPENAI_MODEL || 'gpt-4',
      baseUrl: process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1'
    });
  });

  // File operations for code viewer
  router.post('/files/read', (req, res) => {
    try {
      const { path: filePath } = req.body;
      if (!filePath) return res.status(400).json({ error: 'Path required' });
      const content = fs.readFileSync(filePath, 'utf-8');
      res.json({ content, path: filePath });
    } catch (err) {
      res.status(404).json({ error: err.message });
    }
  });

  router.post('/files/list', (req, res) => {
    try {
      const { path: dirPath } = req.body;
      if (!dirPath) return res.status(400).json({ error: 'Path required' });
      const items = fs.readdirSync(dirPath, { withFileTypes: true })
        .filter(item => !item.name.startsWith('.'))
        .map(item => ({
          name: item.name,
          isDirectory: item.isDirectory(),
          path: path.join(dirPath, item.name)
        }))
        .sort((a, b) => {
          if (a.isDirectory !== b.isDirectory) return a.isDirectory ? -1 : 1;
          return a.name.localeCompare(b.name);
        });
      res.json(items);
    } catch (err) {
      res.status(404).json({ error: err.message });
    }
  });

  return router;
}
