import { spawn } from 'child_process';
import { EventEmitter } from 'events';
import fs from 'fs';

export class McpManager extends EventEmitter {
  constructor(settingsPath) {
    super();
    this.settingsPath = settingsPath;
    this.servers = new Map();
    this.settings = {};
  }

  async initialize() {
    try {
      const raw = fs.readFileSync(this.settingsPath, 'utf-8');
      this.settings = JSON.parse(raw);

      for (const [name, config] of Object.entries(this.settings.mcpServers || {})) {
        if (config.disabled) {
          console.log(`⏭️  MCP server "${name}" is disabled, skipping`);
          continue;
        }
        try {
          await this.startServer(name, config);
        } catch (err) {
          console.error(`❌ Failed to start MCP server "${name}":`, err.message);
        }
      }
    } catch (err) {
      console.warn('⚠️  Could not load MCP settings:', err.message);
    }
  }

  async startServer(name, config) {
    return new Promise((resolve, reject) => {
      const { command, args = [], env = {} } = config;
      console.log(`🔧 Starting MCP server "${name}": ${command} ${args.join(' ')}`);

      const proc = spawn(command, args, {
        stdio: ['pipe', 'pipe', 'pipe'],
        env: { ...process.env, ...env },
        shell: true
      });

      const server = {
        name,
        config,
        process: proc,
        tools: [],
        resources: [],
        pendingRequests: new Map(),
        nextId: 1,
        ready: false,
        buffer: ''
      };

      proc.stdout.on('data', (data) => {
        server.buffer += data.toString();
        const lines = server.buffer.split('\n');
        server.buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.trim()) {
            try {
              const msg = JSON.parse(line.trim());
              this.handleMessage(name, msg);
            } catch (e) {
              // Not JSON, log output
            }
          }
        }
      });

      proc.stderr.on('data', (data) => {
        const msg = data.toString().trim();
        if (msg) console.log(`[MCP:${name}:stderr] ${msg}`);
      });

      proc.on('error', (err) => {
        console.error(`MCP server "${name}" error:`, err);
        reject(err);
      });

      proc.on('exit', (code) => {
        console.log(`MCP server "${name}" exited with code ${code}`);
        this.servers.delete(name);
        this.emit('server-exit', { name, code });
      });

      this.servers.set(name, server);

      // Initialize MCP protocol
      setTimeout(async () => {
        try {
          const initResult = await this.sendRequest(name, 'initialize', {
            protocolVersion: '2024-11-05',
            capabilities: { tools: {}, resources: {}, prompts: {} },
            clientInfo: { name: 'roo-chat', version: '1.0.0' }
          });

          server.ready = true;
          server.capabilities = initResult?.capabilities || {};

          this.sendNotification(name, 'notifications/initialized', {});

          try {
            const toolsResult = await this.sendRequest(name, 'tools/list', {});
            server.tools = toolsResult?.tools || [];
            console.log(`  📦 "${name}" tools: ${server.tools.map(t => t.name).join(', ') || 'none'}`);
          } catch (e) {
            console.log(`  ⚠️  "${name}" does not support tools/list`);
          }

          try {
            const resourcesResult = await this.sendRequest(name, 'resources/list', {});
            server.resources = resourcesResult?.resources || [];
          } catch (e) { /* Resources not supported */ }

          resolve(server);
        } catch (err) {
          console.error(`Failed to initialize MCP server "${name}":`, err.message);
          server.ready = true;
          resolve(server);
        }
      }, 2000);
    });
  }

  sendRequest(serverName, method, params = {}) {
    return new Promise((resolve, reject) => {
      const server = this.servers.get(serverName);
      if (!server) {
        reject(new Error(`MCP server "${serverName}" not found`));
        return;
      }

      const id = server.nextId++;
      const message = { jsonrpc: '2.0', id, method, params };

      const timeout = setTimeout(() => {
        server.pendingRequests.delete(id);
        reject(new Error(`Request to "${serverName}" timed out (${method})`));
      }, (server.config.timeout || 30) * 1000);

      server.pendingRequests.set(id, { resolve, reject, timeout });

      try {
        server.process.stdin.write(JSON.stringify(message) + '\n');
      } catch (err) {
        server.pendingRequests.delete(id);
        clearTimeout(timeout);
        reject(err);
      }
    });
  }

  sendNotification(serverName, method, params = {}) {
    const server = this.servers.get(serverName);
    if (!server) return;
    try {
      server.process.stdin.write(JSON.stringify({ jsonrpc: '2.0', method, params }) + '\n');
    } catch (err) {
      console.error(`Failed to send notification to "${serverName}":`, err.message);
    }
  }

  handleMessage(serverName, msg) {
    const server = this.servers.get(serverName);
    if (!server) return;

    if (msg.id !== undefined && server.pendingRequests.has(msg.id)) {
      const { resolve, reject, timeout } = server.pendingRequests.get(msg.id);
      clearTimeout(timeout);
      server.pendingRequests.delete(msg.id);

      if (msg.error) {
        reject(new Error(msg.error.message || 'MCP error'));
      } else {
        resolve(msg.result);
      }
      return;
    }

    if (msg.method) {
      this.emit('notification', { serverName, method: msg.method, params: msg.params });
    }
  }

  async callTool(serverName, toolName, args = {}) {
    return this.sendRequest(serverName, 'tools/call', { name: toolName, arguments: args });
  }

  getAllTools() {
    const tools = [];
    for (const [serverName, server] of this.servers) {
      if (!server.ready) continue;
      for (const tool of server.tools) {
        tools.push({
          type: 'function',
          function: {
            name: `${serverName}__${tool.name}`,
            description: tool.description || `Tool from ${serverName}`,
            parameters: tool.inputSchema || { type: 'object', properties: {} }
          },
          _mcpServer: serverName,
          _mcpToolName: tool.name
        });
      }
    }
    return tools;
  }

  getToolsInfo() {
    const info = {};
    for (const [serverName, server] of this.servers) {
      info[serverName] = {
        ready: server.ready,
        tools: server.tools.map(t => ({ name: t.name, description: t.description })),
        resources: server.resources.map(r => ({ uri: r.uri, name: r.name, description: r.description }))
      };
    }
    return info;
  }

  getServerNames() { return Array.from(this.servers.keys()); }
  getSettings() { return this.settings; }

  async shutdown() {
    for (const [name, server] of this.servers) {
      console.log(`Stopping MCP server "${name}"...`);
      try { server.process.kill('SIGTERM'); } catch (e) { /* ignore */ }
    }
    this.servers.clear();
  }
}
