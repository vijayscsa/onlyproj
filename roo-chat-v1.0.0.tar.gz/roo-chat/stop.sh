#!/bin/bash
# ============================================
# Roo Chat - Stop Script
# ============================================

echo "🛑 Stopping Roo Chat services..."

# Kill backend
pkill -f "node src/index.js" 2>/dev/null && echo "✅ Backend stopped" || echo "ℹ️  Backend was not running"

# Kill frontend (vite)
pkill -f "vite --port 3010" 2>/dev/null && echo "✅ Frontend stopped" || echo "ℹ️  Frontend was not running"

# Kill MCP servers
pkill -f "@modelcontextprotocol/server-filesystem" 2>/dev/null && echo "✅ MCP filesystem server stopped" || true
pkill -f "@modelcontextprotocol/server-everything" 2>/dev/null && echo "✅ MCP everything server stopped" || true

echo "🏁 All services stopped."
