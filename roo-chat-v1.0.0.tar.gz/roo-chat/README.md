# 🤖 Roo Chat - MCP-Powered AI Coding Assistant

A full-featured chatbot web UI inspired by **Roo Code**, built with React + Node.js and integrated with **MCP (Model Context Protocol)** servers. This application connects to local MCP servers for file system access, code operations, and more — providing a conversational AI coding assistant experience.

![Architecture](https://img.shields.io/badge/Architecture-Frontend%20%2B%20Backend%20%2B%20MCP-blue)
![License](https://img.shields.io/badge/License-MIT-green)
![Node](https://img.shields.io/badge/Node.js-18%2B-brightgreen)

---

## ✨ Features

### Chat Interface
- 💬 **Streaming responses** with real-time token-by-token rendering
- 📝 **Markdown rendering** with syntax highlighting (Prism.js)
- 🔧 **Tool call visualization** — collapsible tool invocations with args/results
- 📋 **Code block copy** — one-click code copying
- 💡 **Suggestion cards** — pre-built prompts for common tasks
- ⏹️ **Abort streaming** — stop generation mid-response
- 📜 **Conversation history** — persistent conversations with auto-titles

### MCP Integration
- 🗂️ **Filesystem MCP Server** — read/write files, list directories, search, edit files
- 🧪 **Everything MCP Server** — demo tools, echo, structured content
- 🔄 **Tool loop** — automatic multi-turn tool calling (up to 10 iterations)
- 📡 **Real-time status** — live connection status for each MCP server

### UI Panels
- 📂 **File Tree Browser** — browse and preview files from the right panel
- ✅ **Task Tracker** — view status of tool executions
- 🔧 **MCP Tools Panel** — see all connected servers and their available tools
- 📊 **Model Info Badge** — shows current LLM model

### Developer Experience
- 🎨 **Premium dark theme** — VS Code / GitHub-inspired design system
- 📱 **Responsive layout** — works on desktop and tablet
- ⌨️ **Keyboard shortcuts** — Enter to send, Shift+Enter for new line
- 🔄 **Auto-reconnect** — WebSocket with exponential backoff

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────┐
│                   Frontend (React)                   │
│                 http://localhost:3010                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────┐  │
│  │ Sidebar   │  │ Chat Area│  │ Right Panel      │  │
│  │ - History │  │ - Msgs   │  │ - MCP Servers    │  │
│  │ - MCP     │  │ - Stream │  │ - Tasks          │  │
│  │   Status  │  │ - Tools  │  │ - File Tree      │  │
│  └──────────┘  └──────────┘  └──────────────────┘  │
│                    │ WebSocket                       │
└────────────────────┼────────────────────────────────┘
                     │
┌────────────────────┼────────────────────────────────┐
│              Backend (Node.js/Express)               │
│                 http://localhost:8010                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────┐  │
│  │ REST API  │  │ WS Server│  │ LLM Client       │  │
│  │ - CRUD    │  │ - Stream │  │ - OpenAI API     │  │
│  │ - Files   │  │ - Chat   │  │ - Tool calling   │  │
│  │ - MCP     │  │ - Tools  │  │ - Streaming      │  │
│  └──────────┘  └──────────┘  └──────────────────┘  │
│                    │                                 │
│  ┌──────────────────────────────────────────────┐   │
│  │              MCP Manager                      │   │
│  │  ┌─────────────────┐  ┌──────────────────┐  │   │
│  │  │ filesystem MCP   │  │ everything MCP    │  │   │
│  │  │ (14 tools)       │  │ (13 tools)        │  │   │
│  │  └─────────────────┘  └──────────────────┘  │   │
│  └──────────────────────────────────────────────┘   │
│                                                      │
│  ┌──────────────────────────────────────────────┐   │
│  │           SQLite Database                     │   │
│  │  conversations | messages | tasks | checkpoints│  │
│  └──────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** 18+ and npm
- **Linux/macOS** or **WSL** (Windows Subsystem for Linux)

### 1. Clone & Configure

```bash
cd /home/ravinv1/appli1/roo-chat

# Copy and edit environment variables
cp .env.example .env
vim .env  # Set your OPENAI_API_KEY
```

### 2. Configure `.env`

```env
# LLM Configuration
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_API_KEY=sk-your-actual-api-key
OPENAI_MODEL=gpt-4

# Server Ports
BACKEND_PORT=8010
FRONTEND_PORT=3010

# Session Secret
SESSION_SECRET=your-secret-key

# Database
DB_PATH=./data/roo-chat.db

# Rate Limiting
RATE_LIMIT_MAX=100
RATE_LIMIT_WINDOW_MS=60000
```

### 3. Install Dependencies

```bash
# Install all dependencies (root + backend + frontend)
npm run install:all
```

### 4. Start the Application

```bash
# Option A: Using the startup script
chmod +x start.sh
./start.sh

# Option B: Manual start
npm run dev
```

### 5. Access the Application

- **Frontend**: http://localhost:3010
- **Backend API**: http://localhost:8010
- **Health Check**: http://localhost:8010/health
- **WebSocket**: ws://localhost:8010/ws

---

## 📁 Project Structure

```
roo-chat/
├── .env                    # Environment variables (API keys, ports)
├── .env.example            # Template for environment variables
├── mcp_settings.json       # MCP server configuration (Roo Code compatible)
├── package.json            # Root package.json with dev scripts
├── start.sh                # Startup script
├── stop.sh                 # Stop script
├── README.md               # This file
│
├── backend/
│   ├── package.json        # Backend dependencies
│   ├── data/               # SQLite database storage
│   │   └── roo-chat.db     # Auto-created on first run
│   └── src/
│       ├── index.js        # Express server entry point
│       ├── db.js           # SQLite database initialization
│       ├── llm.js          # OpenAI LLM client (streaming + tool calling)
│       ├── websocket.js    # WebSocket handler (chat loop + tool execution)
│       ├── routes/
│       │   └── api.js      # REST API routes
│       └── mcp/
│           └── manager.js  # MCP server lifecycle & JSON-RPC communication
│
└── frontend/
    ├── package.json        # Frontend dependencies
    ├── vite.config.js      # Vite config with API proxy
    ├── index.html          # HTML entry point
    └── src/
        ├── main.jsx        # React entry point
        ├── App.jsx         # Main app component
        ├── styles/
        │   └── index.css   # Complete design system (1200+ lines)
        ├── hooks/
        │   └── useWebSocket.js  # WebSocket hook with auto-reconnect
        └── components/
            ├── Sidebar.jsx          # Conversation list sidebar
            ├── HeaderBar.jsx        # Top bar with model info
            ├── ChatArea.jsx         # Message list + markdown rendering
            ├── InputArea.jsx        # Chat input with auto-resize
            ├── RightPanel.jsx       # MCP tools + tasks + file tree
            ├── WelcomeScreen.jsx    # Landing page with suggestions
            └── ConnectionStatus.jsx # Connection indicator
```

---

## 🔧 MCP Configuration

The `mcp_settings.json` file follows the **Roo Code** format:

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/home/ravinv1"],
      "disabled": false,
      "alwaysAllow": ["read_file", "list_directory", "search_files", "get_file_info"],
      "timeout": 30
    },
    "everything": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-everything"],
      "disabled": false,
      "alwaysAllow": [],
      "timeout": 30
    }
  }
}
```

### Adding a New MCP Server

1. Edit `mcp_settings.json`
2. Add a new entry under `mcpServers`
3. Restart the backend

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check |
| GET | `/api/conversations` | List all conversations |
| GET | `/api/conversations/:id` | Get conversation with messages |
| POST | `/api/conversations` | Create new conversation |
| DELETE | `/api/conversations/:id` | Delete conversation |
| GET | `/api/mcp/servers` | Get MCP server info |
| GET | `/api/mcp/tools` | List all available tools |
| GET | `/api/mcp/settings` | Get MCP settings |
| GET | `/api/model` | Get current model info |
| POST | `/api/files/read` | Read file contents |
| POST | `/api/files/list` | List directory contents |

### WebSocket Messages

| Type | Direction | Description |
|------|-----------|-------------|
| `chat` | Client → Server | Send user message |
| `new_conversation` | Client → Server | Create new conversation |
| `load_conversation` | Client → Server | Load existing conversation |
| `abort` | Client → Server | Abort streaming |
| `init` | Server → Client | Connection initialized |
| `stream_start` | Server → Client | Streaming started |
| `stream_token` | Server → Client | Token chunk |
| `stream_end` | Server → Client | Streaming finished |
| `tool_calls` | Server → Client | LLM requesting tool calls |
| `tool_executing` | Server → Client | Tool execution started |
| `tool_result` | Server → Client | Tool execution result |

---

## 🛑 Stopping the Application

```bash
# Option A: Using the stop script
chmod +x stop.sh
./stop.sh

# Option B: Ctrl+C in the terminal running start.sh

# Option C: Kill specific processes
pkill -f "node src/index.js"
pkill -f "vite --port 3010"
```

---

## 🖥️ For MacBook Deployment

To run this on a MacBook:

1. Copy the entire `roo-chat/` folder to your Mac
2. Ensure Node.js 18+ is installed (`brew install node`)
3. Run `npm run install:all`
4. Edit `.env` with your API key
5. Run `./start.sh`

The application works on macOS, Linux, and WSL identically.

---

## 📝 License

MIT License - Feel free to modify and extend.
