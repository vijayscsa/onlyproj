#!/bin/bash
# ============================================
# Roo Chat - Startup Script
# ============================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "🤖 Roo Chat - MCP-Powered AI Coding Assistant"
echo "=============================================="
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
  echo "❌ Node.js is not installed. Please install Node.js 18+ first."
  exit 1
fi

NODE_VERSION=$(node --version)
echo "✅ Node.js: $NODE_VERSION"

# Check if .env exists
if [ ! -f ".env" ]; then
  echo "⚠️  No .env file found. Creating from .env.example..."
  cp .env.example .env
  echo "📝 Please edit .env and set your OPENAI_API_KEY before continuing."
  echo "   vim .env"
  exit 1
fi

# Check if API key is set
if grep -q "sk-your-api-key-here" .env; then
  echo "⚠️  OPENAI_API_KEY is not configured in .env"
  echo "   Please edit .env and set a valid API key."
  exit 1
fi

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
  echo "📦 Installing root dependencies..."
  npm install
fi

if [ ! -d "backend/node_modules" ]; then
  echo "📦 Installing backend dependencies..."
  cd backend && npm install && cd ..
fi

if [ ! -d "frontend/node_modules" ]; then
  echo "📦 Installing frontend dependencies..."
  cd frontend && npm install && cd ..
fi

echo ""
echo "🚀 Starting Roo Chat..."
echo "   Frontend: http://localhost:3010"
echo "   Backend:  http://localhost:8010"
echo "   WebSocket: ws://localhost:8010/ws"
echo ""

# Start backend and frontend concurrently
npx concurrently \
  --names "BACKEND,FRONTEND" \
  --prefix-colors "blue,green" \
  "cd backend && node src/index.js" \
  "cd frontend && npx vite --port 3010 --host 0.0.0.0"
