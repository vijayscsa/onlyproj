#!/bin/bash

# RTF Job Run Agent - Package for MacOS Transfer
# This script creates a clean package of your project for easy transfer to MacBook

echo "=========================================="
echo "RTF Job Run Agent - Packaging Script"
echo "=========================================="
echo ""

# Set variables
PROJECT_DIR="/home/ravinv1/mcp-chat-client-n"
PACKAGE_NAME="rtf-job-agent-$(date +%Y%m%d-%H%M%S)"
TEMP_DIR="/tmp/$PACKAGE_NAME"
OUTPUT_FILE="$HOME/$PACKAGE_NAME.tar.gz"

echo "Project directory: $PROJECT_DIR"
echo "Package name: $PACKAGE_NAME"
echo ""

# Create temporary directory
echo "Creating temporary directory..."
mkdir -p "$TEMP_DIR"

# Copy project files (excluding unnecessary files)
echo "Copying project files..."
rsync -av \
  --exclude='node_modules' \
  --exclude='.next' \
  --exclude='__pycache__' \
  --exclude='.venv' \
  --exclude='venv' \
  --exclude='.git' \
  --exclude='*.pyc' \
  --exclude='.env' \
  --exclude='pnpm-lock.yaml' \
  "$PROJECT_DIR/" "$TEMP_DIR/"

# Ensure .env.example exists
echo "Checking for .env.example..."
if [ -f "$PROJECT_DIR/backend/.env" ]; then
  if [ ! -f "$TEMP_DIR/backend/.env.example" ]; then
    echo "Creating .env.example from .env (removing sensitive data)..."
    cp "$PROJECT_DIR/backend/.env" "$TEMP_DIR/backend/.env.example"
    # Clear sensitive values in .env.example
    sed -i 's/\(GOOGLE_API_KEY=\).*/\1your_api_key_here/' "$TEMP_DIR/backend/.env.example"
    sed -i 's/\(API_KEY=\).*/\1your_api_key_here/' "$TEMP_DIR/backend/.env.example"
  fi
fi

# Create README for MacOS
echo "Creating MacOS README..."
cat > "$TEMP_DIR/START_HERE.txt" << 'EOF'
RTF Job Run Agent - MacOS Setup
================================

Welcome! Follow these steps to get started on your MacBook:

Step 1: Extract this archive
-----------------------------
The archive should auto-extract. If not:
  tar -xzf rtf-job-agent-*.tar.gz

Step 2: Read the setup guides
------------------------------
We've included two guides:

1. MACOS_QUICKSTART.md (Quick cheat sheet)
   - Perfect if you know what you're doing
   - Has all the essential commands

2. MACOS_SETUP_GUIDE.md (Detailed guide)
   - Step-by-step instructions
   - Includes troubleshooting
   - Perfect for beginners

Step 3: Install prerequisites
------------------------------
On your MacBook, open Terminal and run:

  brew install node python@3.12 git

Step 4: Set up the project
---------------------------
Follow either guide above. In summary:

Frontend:
  cd frontend
  npm install
  npm run dev

Backend:
  cd backend
  python3 -m venv venv
  source venv/bin/activate
  pip install -e .
  cp .env.example .env
  # Edit .env and add your Google API key
  uvicorn app.main:app --reload --port 3032

Step 5: Access the application
-------------------------------
Open browser: http://localhost:3000
Login: rtfuser / Password@123

Need help? Check the guides or contact support!

Happy coding! 🚀
EOF

# Create package
echo "Creating compressed archive..."
cd /tmp
tar -czf "$OUTPUT_FILE" "$PACKAGE_NAME"

# Cleanup
echo "Cleaning up temporary files..."
rm -rf "$TEMP_DIR"

# Show results
echo ""
echo "=========================================="
echo "✅ Package created successfully!"
echo "=========================================="
echo ""
echo "Package location: $OUTPUT_FILE"
echo "Package size: $(du -h "$OUTPUT_FILE" | cut -f1)"
echo ""
echo "To transfer to your MacBook:"
echo ""
echo "Option 1 - Using scp:"
echo "  On your MacBook, run:"
echo "  scp $(whoami)@<this-server-ip>:$OUTPUT_FILE ~/Downloads/"
echo ""
echo "Option 2 - Using rsync:"
echo "  On your MacBook, run:"
echo "  rsync -avz $(whoami)@<this-server-ip>:$OUTPUT_FILE ~/Downloads/"
echo ""
echo "Option 3 - Download via browser:"
echo "  Copy the file to a web-accessible location or use SFTP client"
echo ""
echo "After transfer, extract on MacBook:"
echo "  cd ~/Downloads"
echo "  tar -xzf $PACKAGE_NAME.tar.gz"
echo "  cd $PACKAGE_NAME"
echo "  cat START_HERE.txt"
echo ""
echo "=========================================="
