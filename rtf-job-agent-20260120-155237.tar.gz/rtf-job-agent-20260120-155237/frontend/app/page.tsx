"use client";

import { useState } from "react";
import { ChatInterface } from "@/components/chat-interface";
import { LoginPage } from "@/components/login-page";

export default function Home() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = (email: string, password: string) => {
    // Validate credentials
    const VALID_USERNAME = "rtfuser";
    const VALID_PASSWORD = "Password@123";

    if (email === VALID_USERNAME && password === VALID_PASSWORD) {
      console.log("Login successful:", email);
      setIsAuthenticated(true);
    } else {
      console.log("Login failed - Invalid credentials");
      alert("Invalid username or password. Please try again.\n\nValid credentials:\nUsername: rtfuser\nPassword: Password@123");
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return <ChatInterface onLogout={handleLogout} />;
}
