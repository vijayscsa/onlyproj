"use client";

import { useState } from "react";
import { Eye, EyeOff, User, Lock } from "lucide-react";
import Image from "next/image";

interface LoginPageProps {
    onLogin: (email: string, password: string) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [rememberMe, setRememberMe] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onLogin(email, password);
    };

    return (
        <div className="flex w-full h-screen bg-black overflow-hidden">
            {/* Left Side - Branding */}
            <div className="hidden lg:flex lg:w-1/2 relative bg-gradient-to-br from-zinc-950 via-zinc-900 to-black border-r border-zinc-800/50">
                {/* Subtle background gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-yellow-900/5 via-transparent to-purple-900/5" />

                <div className="relative z-10 flex flex-col justify-center px-16 xl:px-24 w-full">
                    {/* Logo and Title */}
                    <div className="mb-16">
                        <div className="flex items-center gap-4 mb-4">
                            <div className="w-16 h-16 relative">
                                <Image
                                    src="/logo.png"
                                    alt="RTF DP&E Job Run Agent Logo"
                                    width={64}
                                    height={64}
                                    className="object-contain"
                                />
                            </div>
                        </div>
                        <h1 className="text-4xl xl:text-5xl font-bold text-white mb-2">
                            RTF DP&E Job Run Agent v1.2
                        </h1>
                        <p className="text-zinc-400 text-lg">
                            Commonwealth Bank of Australia
                        </p>
                    </div>

                    {/* Feature List */}
                    <div className="space-y-6">
                        <div className="flex items-start gap-4 group">
                            <div className="w-6 h-6 rounded-full bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-center mt-1 group-hover:bg-yellow-500/20 transition-colors">
                                <svg className="w-3 h-3 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                </svg>
                            </div>
                            <div>
                                <h3 className="text-white font-medium text-lg mb-1">
                                    AI Powered Job Run Management
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Right Side - Login Form */}
            <div className="flex-1 flex items-center justify-center p-8 bg-gradient-to-br from-zinc-50 via-white to-zinc-100">
                <div className="w-full max-w-md">
                    {/* Mobile Logo */}
                    <div className="lg:hidden flex justify-center mb-8">
                        <div className="w-12 h-12 relative">
                            <Image
                                src="/logo.png"
                                alt="RTF DP&E Job Run Agent Logo"
                                width={48}
                                height={48}
                                className="object-contain"
                            />
                        </div>
                    </div>

                    {/* Login Card */}
                    <div className="bg-white rounded-2xl shadow-xl border border-zinc-200 p-8 lg:p-10">
                        <div className="mb-8">
                            <h2 className="text-2xl lg:text-3xl font-bold text-zinc-900 mb-2">
                                Log on to RTF DP&E Job Run Agent v1.2
                            </h2>
                            <p className="text-zinc-600 text-sm">
                                Enter your credentials to access your account
                            </p>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-6">
                            {/* Email Field */}
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-zinc-700 mb-2">
                                    Email or Username
                                </label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                        <User className="h-5 w-5 text-zinc-400" />
                                    </div>
                                    <input
                                        id="email"
                                        type="text"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        placeholder="Enter your email"
                                        className="w-full pl-12 pr-4 py-3 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                                        required
                                    />
                                </div>
                            </div>

                            {/* Password Field */}
                            <div>
                                <label htmlFor="password" className="block text-sm font-medium text-zinc-700 mb-2">
                                    Password
                                </label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                        <Lock className="h-5 w-5 text-zinc-400" />
                                    </div>
                                    <input
                                        id="password"
                                        type={showPassword ? "text" : "password"}
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        placeholder="Enter your password"
                                        className="w-full pl-12 pr-12 py-3 bg-zinc-50 border border-zinc-300 rounded-lg text-zinc-900 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                                        required
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute inset-y-0 right-0 pr-4 flex items-center text-zinc-400 hover:text-zinc-600 transition-colors"
                                    >
                                        {showPassword ? (
                                            <EyeOff className="h-5 w-5" />
                                        ) : (
                                            <Eye className="h-5 w-5" />
                                        )}
                                    </button>
                                </div>
                            </div>

                            {/* Remember Me & Forgot Password */}
                            <div className="flex items-center justify-between">
                                <label className="flex items-center gap-2 cursor-pointer group">
                                    <input
                                        type="checkbox"
                                        checked={rememberMe}
                                        onChange={(e) => setRememberMe(e.target.checked)}
                                        className="w-4 h-4 rounded border-zinc-300 text-yellow-500 focus:ring-yellow-500 focus:ring-2 cursor-pointer"
                                    />
                                    <span className="text-sm text-zinc-700 group-hover:text-zinc-900 transition-colors">
                                        Remember me
                                    </span>
                                </label>
                                <button
                                    type="button"
                                    className="text-sm text-zinc-600 hover:text-yellow-600 transition-colors"
                                >
                                    Forgot password?
                                </button>
                            </div>

                            {/* Submit Button */}
                            <button
                                type="submit"
                                className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-semibold py-3 px-6 rounded-lg shadow-lg shadow-yellow-500/30 hover:shadow-yellow-500/50 transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
                            >
                                Log on
                            </button>
                        </form>

                        {/* Additional Options */}
                        <div className="mt-6 text-center">
                            <p className="text-sm text-zinc-600">
                                Don't have an account?{" "}
                                <button className="text-yellow-600 hover:text-yellow-700 font-medium transition-colors">
                                    Sign up
                                </button>
                            </p>
                        </div>
                    </div>

                    {/* Footer */}
                    <div className="mt-6 text-center">
                        <p className="text-xs text-zinc-500">
                            © 2026 Commonwealth Bank of Australia. All rights reserved.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}
