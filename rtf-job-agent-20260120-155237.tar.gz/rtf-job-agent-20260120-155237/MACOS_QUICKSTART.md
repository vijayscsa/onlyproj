# MacBook Quick Setup - Cheat Sheet

## 🚀 Super Quick Start (For Experienced Developers)

### 1️⃣ Transfer Files (Choose One Method)

```bash
# Using SCP
scp -r user@linux-server:/home/ravinv1/mcp-chat-client-n ~/Projects/

# Using rsync (recommended)
rsync -avz user@linux-server:/home/ravinv1/mcp-chat-client-n ~/Projects/
```

### 2️⃣ Frontend Setup

```bash
cd ~/Projects/mcp-chat-client-n/frontend
npm install                    # Install dependencies
npm run dev                    # Start dev server → http://localhost:3000
```

### 3️⃣ Backend Setup

```bash
cd ~/Projects/mcp-chat-client-n/backend
python3 -m venv venv          # Create virtual environment
source venv/bin/activate       # Activate venv
pip install -e .               # Install dependencies
cp .env.example .env           # Copy env file
# Edit .env and add your GOOGLE_API_KEY
uvicorn app.main:app --reload --port 3032  # Start backend
```

### 4️⃣ Login & Test

- Open: http://localhost:3000
- Username: `rtfuser`
- Password: `Password@123`

---

## 📋 Prerequisites Checklist

```bash
# Install everything at once
brew install node python@3.12 git

# Verify installations
node --version    # Should be v18+
python3 --version # Should be 3.12+
npm --version
git --version
```

---

## ⚡ Common Commands

### Frontend

```bash
# Development
npm run dev              # Start dev server
npm run build            # Build for production
npm start                # Run production build
npm run lint             # Check for errors

# Clean install
rm -rf node_modules .next package-lock.json
npm install
```

### Backend

```bash
# Activate virtual environment (do this first!)
source venv/bin/activate

# Run server
uvicorn app.main:app --reload --port 3032

# Check what's running on port
lsof -ti:3032

# Kill process on port
lsof -ti:3032 | xargs kill -9
```

---

## 🐛 Quick Fixes

### Port Already in Use

```bash
# Frontend (3000)
lsof -ti:3000 | xargs kill -9

# Backend (3032)
lsof -ti:3032 | xargs kill -9
```

### Module Not Found

```bash
# Frontend
rm -rf node_modules && npm install

# Backend
pip install --upgrade -e .
```

### Environment Variables

```bash
# Backend .env file must have:
GOOGLE_API_KEY=your_key_here
PORT=3032
CORS_ORIGINS=http://localhost:3000
```

---

## 📁 Important File Locations

```
Frontend:
- Main page: frontend/app/page.tsx
- Login: frontend/components/login-page.tsx
- Chat: frontend/components/chat-interface.tsx
- Styles: frontend/app/globals.css
- Logo: frontend/public/logo.png

Backend:
- Main API: backend/app/main.py
- Agent logic: backend/app/agent.py
- Config: backend/.env
```

---

## 🔑 Access Points

| Service | URL | Credentials |
|---------|-----|-------------|
| Frontend | http://localhost:3000 | rtfuser / Password@123 |
| Backend API | http://localhost:3032 | N/A |
| API Docs | http://localhost:3032/docs | N/A |

---

## 💡 Pro Tips

1. **Use two terminal tabs:** One for frontend, one for backend
2. **Keep virtual env activated:** Backend won't work without it
3. **Check logs:** Terminal shows all errors clearly
4. **Auto-reload enabled:** Both servers restart on file changes
5. **Use VS Code:** Great for editing both Python and TypeScript

---

## 🎯 Step-by-Step for Complete Beginners

### Terminal 1 - Backend

```bash
# 1. Go to backend folder
cd ~/Projects/mcp-chat-client-n/backend

# 2. Create Python environment (first time only)
python3 -m venv venv

# 3. Activate it (do this every time!)
source venv/bin/activate

# 4. Install packages (first time only)
pip install -e .

# 5. Set up environment (first time only)
cp .env.example .env
# Then edit .env file and add your Google API key

# 6. Start the server
uvicorn app.main:app --reload --port 3032

# ✅ You should see "Uvicorn running on http://0.0.0.0:3032"
```

### Terminal 2 - Frontend

```bash
# 1. Open a NEW terminal tab/window
# 2. Go to frontend folder
cd ~/Projects/mcp-chat-client-n/frontend

# 3. Install packages (first time only)
npm install

# 4. Start the server
npm run dev

# ✅ You should see "Local: http://localhost:3000"
```

### Browser

```
1. Open: http://localhost:3000
2. You'll see the login page
3. Enter username: rtfuser
4. Enter password: Password@123
5. Click "Log on"
6. You're in! 🎉
```

---

## 🔄 Daily Workflow

Every time you want to work on the project:

**Terminal 1 (Backend):**
```bash
cd ~/Projects/mcp-chat-client-n/backend
source venv/bin/activate
uvicorn app.main:app --reload --port 3032
```

**Terminal 2 (Frontend):**
```bash
cd ~/Projects/mcp-chat-client-n/frontend
npm run dev
```

**Browser:**
- Go to http://localhost:3000

---

## 📞 Need More Help?

See the full guide: `MACOS_SETUP_GUIDE.md`

---

**That's it! You're all set! 🚀**
