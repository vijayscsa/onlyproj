# AI for FR - Chatbot UI

A modern, premium chatbot interface for AI-powered financial analysis, built with Next.js, React, and Tailwind CSS.

## 🎨 Design Features

This project features a **split-screen authentication interface** inspired by modern banking applications:

### Login Page
- **Left Panel**: Dark-themed branding section featuring:
  - AI for FR logo (yellow/gold diamond icon)
  - Company branding (Commonwealth Bank of Australia)
  - Feature highlights with checkmarks:
    - AI-Powered Financial Analysis
    - Sector Performance Tracking
    - Automated Report Generation
  - Subtle gradient background effects

- **Right Panel**: Clean, light-themed login form with:
  - Email/Username input with user icon
  - Password input with lock icon and show/hide toggle
  - "Remember me" checkbox
  - "Forgot password?" link
  - Premium yellow/gold "Log on" button with gradient and shadow effects
  - Sign up option
  - Responsive design that works on all devices

### Chat Interface
Once authenticated, users access a premium chat interface with:
- **Left Sidebar**: MCP (Model Context Protocol) tools selector with AI for FR branding
- **Main Chat Area**: 
  - Header with user info and logout button
  - Glassmorphism effects
  - Smooth animations and transitions
  - Message streaming support
  - Tool usage indicators
- **Dark Theme**: Professional dark color scheme with yellow/gold accents
- **Responsive**: Works seamlessly on desktop, tablet, and mobile

## 🚀 Getting Started

### Prerequisites
- Node.js 22.14.0 or higher
- npm or pnpm package manager

### Installation

1. **Navigate to the frontend directory**:
   ```bash
   cd /home/ravinv1/mcp-chat-client-n/frontend
   ```

2. **Set Node.js version** (if using asdf):
   ```bash
   asdf local nodejs 22.14.0
   ```

3. **Install dependencies** (if not already installed):
   ```bash
   npm install
   # or
   pnpm install
   ```

4. **Run the development server**:
   ```bash
   npm run dev
   # or
   pnpm dev
   ```

5. **Open your browser**:
   Navigate to [http://localhost:3000](http://localhost:3000)

### Backend Setup

The backend is a Python FastAPI application with LangGraph and MCP integration.

1. **Navigate to the backend directory**:
   ```bash
   cd /home/ravinv1/mcp-chat-client-n/backend
   ```

2. **Set up Python environment**:
   ```bash
   # The project uses uv for dependency management
   # Install dependencies (if needed)
   uv sync
   ```

3. **Configure environment variables**:
   ```bash
   cp .env.example .env
   # Edit .env with your API keys and configuration
   ```

4. **Run the backend server**:
   ```bash
   uvicorn app.main:app --reload --port 3032
   ```

## 📁 Project Structure

```
mcp-chat-client-n/
├── frontend/
│   ├── app/
│   │   ├── globals.css          # Global styles with custom CSS variables
│   │   ├── layout.tsx           # Root layout with metadata
│   │   └── page.tsx             # Main page with auth state management
│   ├── components/
│   │   ├── chat-interface.tsx   # Main chat UI component
│   │   ├── login-page.tsx       # Login/authentication page
│   │   ├── mcp-selector.tsx     # MCP tools selector
│   │   ├── message-input.tsx    # Chat input component
│   │   └── message-list.tsx     # Message display component
│   ├── public/
│   │   └── logo.png             # AI for FR logo
│   ├── types.ts                 # TypeScript type definitions
│   └── package.json             # Frontend dependencies
└── backend/
    ├── app/
    │   ├── main.py              # FastAPI application
    │   ├── agent.py             # LangGraph agent logic
    │   ├── config.py            # Configuration settings
    │   └── schemas.py           # Pydantic models
    └── pyproject.toml           # Python dependencies
```

## 🎨 Design System

### Color Palette
- **Primary**: Yellow/Gold (#eab308) - Used for CTAs and accents
- **Background**: Deep black (#09090b) - Main background
- **Foreground**: Off-white (#fafafa) - Text color
- **Borders**: Zinc-800 (#27272a) - Subtle borders
- **Muted**: Zinc-900 (#18181b) - Secondary backgrounds

### Typography
- **Sans Serif**: Geist Sans (primary font)
- **Monospace**: Geist Mono (code blocks)

### Effects
- **Glassmorphism**: Frosted glass effect on panels
- **Gradients**: Subtle background gradients for depth
- **Shadows**: Layered shadows for elevation
- **Animations**: Smooth transitions and hover effects

## 🔐 Authentication

The current implementation uses a **demo authentication system**:
- Any email/password combination will grant access
- In production, replace with proper authentication (OAuth, JWT, etc.)
- The `handleLogin` function in `app/page.tsx` should be updated with real validation

## 🛠️ Technologies Used

### Frontend
- **Next.js 16** - React framework with App Router
- **React 19** - UI library
- **TypeScript** - Type safety
- **Tailwind CSS v4** - Utility-first styling
- **Lucide React** - Icon library
- **Framer Motion** - Animations
- **React Markdown** - Message rendering
- **@microsoft/fetch-event-source** - SSE streaming

### Backend
- **FastAPI** - Modern Python web framework
- **LangGraph** - Agent orchestration
- **LangChain** - LLM integration
- **MCP (Model Context Protocol)** - Tool integration
- **Uvicorn** - ASGI server

## 📝 Key Features

1. **Premium UI/UX**: Modern, professional design with attention to detail
2. **Authentication Flow**: Smooth transition from login to chat
3. **Real-time Streaming**: SSE-based message streaming
4. **Tool Integration**: MCP tools for enhanced AI capabilities
5. **Responsive Design**: Works on all screen sizes
6. **Dark Theme**: Easy on the eyes for extended use
7. **Glassmorphism**: Modern visual effects
8. **Type Safety**: Full TypeScript support

## 🔧 Customization

### Changing Colors
Edit `frontend/app/globals.css` to modify the color scheme:
```css
:root {
  --primary: #eab308;        /* Change primary color */
  --background: #09090b;     /* Change background */
  /* ... other variables */
}
```

### Updating Branding
1. Replace `frontend/public/logo.png` with your logo
2. Update text in `components/login-page.tsx`
3. Modify metadata in `app/layout.tsx`

### Backend Configuration
Edit `backend/.env` to configure:
- API keys (Google Gemini, etc.)
- MCP server URLs
- CORS settings
- Port numbers

## 📱 Responsive Breakpoints

- **Mobile**: < 768px (md breakpoint)
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

## 🚀 Deployment

### Frontend (Vercel)
```bash
cd frontend
vercel deploy
```

### Backend (Docker)
```bash
cd backend
docker build -t ai-fr-backend .
docker run -p 3032:3032 ai-fr-backend
```

## 📄 License

This project is based on the original MCP Chat Client codebase.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📞 Support

For issues or questions, please refer to the original project documentation or create an issue in the repository.

---

**Built with ❤️ using Next.js, React, and modern web technologies**
