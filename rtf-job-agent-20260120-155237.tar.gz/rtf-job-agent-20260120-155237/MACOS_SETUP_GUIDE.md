# MacOS Setup Guide - RTF Job Run Agent

Complete guide to set up the RTF Job Run Agent application on your MacBook.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Getting the Source Code](#getting-the-source-code)
3. [Frontend Setup](#frontend-setup)
4. [Backend Setup](#backend-setup)
5. [Running the Application](#running-the-application)
6. [Troubleshooting](#troubleshooting)

---

## 📦 Prerequisites

### 1. Install Homebrew (if not already installed)

Open Terminal and run:

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### 2. Install Node.js (for Frontend)

```bash
# Install Node.js using Homebrew
brew install node

# Verify installation
node --version  # Should show v18+ or v20+
npm --version
```

Or use nvm (Node Version Manager) for better version control:

```bash
# Install nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# Close and reopen terminal, then:
nvm install 20
nvm use 20
```

### 3. Install Python (for Backend)

MacOS comes with Python, but install the latest version:

```bash
# Install Python 3.12 or higher
brew install python@3.12

# Verify installation
python3 --version
```

### 4. Install Git (if not already installed)

```bash
brew install git
```

---

## 📥 Getting the Source Code

### Option 1: Using SCP (Secure Copy from Linux to Mac)

From your **MacBook Terminal**:

```bash
# Create a directory for the project
mkdir -p ~/Projects
cd ~/Projects

# Copy the entire project from Linux server to MacBook
# Replace 'ravinv1' with your Linux username and IP address
scp -r ravinv1@<LINUX_IP_ADDRESS>:/home/ravinv1/mcp-chat-client-n ./

# Example:
# scp -r ravinv1@192.168.1.100:/home/ravinv1/mcp-chat-client-n ./
```

### Option 2: Using rsync (Better for large projects)

```bash
# More efficient transfer
rsync -avz --progress ravinv1@<LINUX_IP_ADDRESS>:/home/ravinv1/mcp-chat-client-n ~/Projects/

# Example:
# rsync -avz --progress ravinv1@192.168.1.100:/home/ravinv1/mcp-chat-client-n ~/Projects/
```

### Option 3: Create a Git Repository (Recommended for ongoing development)

**On your Linux server:**

```bash
cd /home/ravinv1/mcp-chat-client-n
git init
git add .
git commit -m "Initial commit - RTF Job Run Agent"

# Optional: Push to GitHub/GitLab
# git remote add origin <your-repo-url>
# git push -u origin main
```

**On your MacBook:**

```bash
cd ~/Projects
git clone <your-repo-url>
# Or if using local git:
# git clone ravinv1@<LINUX_IP>:/home/ravinv1/mcp-chat-client-n
```

### Option 4: Manual Download (if you have the files as ZIP)

1. Download the project ZIP file
2. Extract to `~/Projects/mcp-chat-client-n`

---

## 🎨 Frontend Setup

### 1. Navigate to Frontend Directory

```bash
cd ~/Projects/mcp-chat-client-n/frontend
```

### 2. Install Dependencies

```bash
# Using npm
npm install

# OR using pnpm (faster, recommended)
npm install -g pnpm
pnpm install
```

### 3. Verify Installation

```bash
# Check if node_modules was created
ls -la node_modules

# You should see folders like: next, react, tailwindcss, etc.
```

### 4. Configure Environment (if needed)

Create a `.env.local` file for any frontend environment variables:

```bash
# Create .env.local file
cat > .env.local << 'EOF'
NEXT_PUBLIC_API_URL=http://localhost:3032
EOF
```

---

## 🐍 Backend Setup

### 1. Navigate to Backend Directory

```bash
cd ~/Projects/mcp-chat-client-n/backend
```

### 2. Create Python Virtual Environment

```bash
# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Your prompt should now show (venv)
```

### 3. Install Python Dependencies

The project uses `uv` for dependency management, but you can also use `pip`:

#### Option A: Using UV (Recommended - Faster)

```bash
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Add to PATH (add to ~/.zshrc or ~/.bash_profile)
export PATH="$HOME/.cargo/bin:$PATH"

# Restart terminal or run:
source ~/.zshrc  # or source ~/.bash_profile

# Install dependencies
uv sync
```

#### Option B: Using pip

```bash
# Install from pyproject.toml
pip install -e .

# OR install manually
pip install fastapi uvicorn langchain-google-genai langgraph langchain-mcp-adapters python-dotenv httpx sse-starlette pydantic pydantic-settings mcp
```

### 4. Configure Environment Variables

```bash
# Copy example environment file
cp .env.example .env

# Edit the .env file with your settings
nano .env  # or use vim, code, or any text editor
```

**Important Environment Variables to Configure:**

```bash
# Edit .env file
GOOGLE_API_KEY=your_google_gemini_api_key_here
MCP_SERVER_URL=http://localhost:8000
CORS_ORIGINS=http://localhost:3000
PORT=3032
```

To get a Google Gemini API key:
1. Go to https://makersuite.google.com/app/apikey
2. Create a new API key
3. Copy and paste it into your `.env` file

---

## 🚀 Running the Application

### Terminal 1: Start the Backend

```bash
# Navigate to backend directory
cd ~/Projects/mcp-chat-client-n/backend

# Activate virtual environment
source venv/bin/activate

# Start the backend server
uvicorn app.main:app --reload --host 0.0.0.0 --port 3032
```

You should see:
```
INFO:     Uvicorn running on http://0.0.0.0:3032
INFO:     Application startup complete.
```

### Terminal 2: Start the Frontend

Open a **new terminal window/tab**:

```bash
# Navigate to frontend directory
cd ~/Projects/mcp-chat-client-n/frontend

# Start the development server
npm run dev

# OR with pnpm
pnpm dev
```

You should see:
```
▲ Next.js 16.0.7
- Local:        http://localhost:3000
✓ Ready in 2.1s
```

### 3. Access the Application

Open your browser and go to:
- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:3032/docs (FastAPI Swagger UI)

### 4. Login Credentials

- **Username:** `rtfuser`
- **Password:** `Password@123`

---

## 🔧 Project Structure

```
~/Projects/mcp-chat-client-n/
├── frontend/                  # Next.js React application
│   ├── app/
│   │   ├── page.tsx          # Auth & routing
│   │   ├── layout.tsx        # Root layout
│   │   └── globals.css       # Global styles
│   ├── components/
│   │   ├── login-page.tsx    # Login UI
│   │   ├── chat-interface.tsx
│   │   ├── mcp-selector.tsx
│   │   ├── message-input.tsx
│   │   └── message-list.tsx
│   ├── public/
│   │   └── logo.png
│   ├── package.json
│   └── tsconfig.json
│
├── backend/                   # Python FastAPI backend
│   ├── app/
│   │   ├── main.py           # FastAPI app
│   │   ├── agent.py          # LangGraph logic
│   │   ├── config.py
│   │   └── schemas.py
│   ├── .env                  # Environment variables
│   ├── pyproject.toml
│   └── requirements.txt
│
├── README.md
├── QUICKSTART.md
└── MACOS_SETUP_GUIDE.md
```

---

## 🛠️ Troubleshooting

### Frontend Issues

#### Port 3000 already in use

```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Or run on different port
npm run dev -- -p 3001
```

#### Module not found errors

```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json .next
npm install
```

### Backend Issues

#### Port 3032 already in use

```bash
# Kill process on port 3032
lsof -ti:3032 | xargs kill -9

# Or change port in command
uvicorn app.main:app --reload --port 3033
```

#### Python module errors

```bash
# Make sure virtual environment is activated
source venv/bin/activate

# Reinstall dependencies
pip install --upgrade -e .
```

#### Google API Key errors

Check your `.env` file and ensure:
```bash
GOOGLE_API_KEY=AIza...your-actual-key-here
```

### Database/MCP Connection Issues

If the backend can't connect to MCP servers:
- Check MCP server URLs in `.env`
- Ensure MCP servers are running
- Check firewall settings

---

## 📝 Development Tips

### Hot Reload

Both frontend and backend support hot reload:
- **Frontend:** Edit any `.tsx` file and see changes instantly
- **Backend:** With `--reload` flag, changes to `.py` files auto-restart server

### Viewing Logs

**Frontend logs:**
- Open browser DevTools (F12 or Cmd+Option+I)
- Check Console tab

**Backend logs:**
- Visible in the terminal where uvicorn is running
- Or check FastAPI docs at http://localhost:3032/docs

### Code Editing

Recommended IDEs for MacBook:
- **VS Code:** `brew install --cask visual-studio-code`
- **Cursor:** https://cursor.sh
- **WebStorm/PyCharm:** JetBrains IDEs

---

## 🚢 Production Deployment

### Building for Production

#### Frontend

```bash
cd frontend
npm run build
npm start  # Runs production build
```

#### Backend

```bash
cd backend
gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:3032
```

### Docker Deployment (Optional)

Create `docker-compose.yml` in project root:

```yaml
version: '3.8'

services:
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - NEXT_PUBLIC_API_URL=http://localhost:3032

  backend:
    build: ./backend
    ports:
      - "3032:3032"
    env_file:
      - ./backend/.env
```

Then run:
```bash
docker-compose up
```

---

## 🔐 Security Notes

1. **Never commit `.env` files** to Git
2. Change default credentials in production
3. Use HTTPS in production
4. Set proper CORS origins
5. Keep dependencies updated

---

## 📚 Additional Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [LangChain Documentation](https://python.langchain.com/)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)

---

## 🆘 Getting Help

If you encounter issues:

1. Check the terminal logs for error messages
2. Verify all prerequisites are installed
3. Ensure all environment variables are set
4. Check if ports are available
5. Review the troubleshooting section above

---

## ✅ Success Checklist

- [ ] Node.js installed (v18+)
- [ ] Python installed (3.12+)
- [ ] Source code copied to MacBook
- [ ] Frontend dependencies installed (`npm install`)
- [ ] Backend virtual environment created
- [ ] Backend dependencies installed
- [ ] Environment variables configured (`.env` files)
- [ ] Backend running on port 3032
- [ ] Frontend running on port 3000
- [ ] Can access http://localhost:3000
- [ ] Can login with rtfuser/Password@123
- [ ] Chat interface loads successfully

---

**Congratulations! Your RTF Job Run Agent is now running on your MacBook! 🎉**
