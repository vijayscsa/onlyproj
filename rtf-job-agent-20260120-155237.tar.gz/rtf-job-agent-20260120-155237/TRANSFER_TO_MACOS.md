# Transfer Guide: Linux Server → MacBook

Complete guide to transfer your RTF Job Run Agent from Linux to MacBook.

---

## 🎯 Overview

You have 3 main options to transfer the project to your MacBook:

1. **Automated Package Script** (Recommended - Easiest)
2. **Direct Transfer** (Quick but transfers everything)
3. **Git Repository** (Best for ongoing development)

---

## ✅ Option 1: Automated Package Script (RECOMMENDED)

This is the **easiest and cleanest** method. It creates a compressed package without unnecessary files.

### On Linux Server:

```bash
# Navigate to project
cd /home/ravinv1/mcp-chat-client-n

# Run the packaging script
./package-for-macos.sh

# The script will create a .tar.gz file in your home directory
# Example: ~/rtf-job-agent-20260120-153000.tar.gz
```

### Transfer to MacBook:

**On your MacBook Terminal:**

```bash
# Replace <LINUX_IP> with your Linux server's IP address
# Replace <USERNAME> with your Linux username (ravinv1)
# Replace <PACKAGE_NAME> with the actual filename shown by the script

scp ravinv1@<LINUX_IP>:~/rtf-job-agent-*.tar.gz ~/Downloads/

# Example:
# scp ravinv1@192.168.1.100:~/rtf-job-agent-20260120-153000.tar.gz ~/Downloads/
```

### Extract on MacBook:

```bash
# Go to Downloads
cd ~/Downloads

# Extract the package
tar -xzf rtf-job-agent-*.tar.gz

# Enter the directory
cd rtf-job-agent-*

# Read the getting started guide
cat START_HERE.txt

# Move to Projects folder (optional but recommended)
mv ~/Downloads/rtf-job-agent-* ~/Projects/rtf-job-agent
cd ~/Projects/rtf-job-agent
```

### What This Method Includes:

✅ All source code (frontend & backend)  
✅ Configuration files  
✅ Documentation (all .md files)  
✅ Logo and assets  

### What It Excludes (saves space):

❌ node_modules (will reinstall on MacBook)  
❌ .next build folder  
❌ Python virtual environment  
❌ __pycache__ files  
❌ .git folder  

**Benefits:** Clean, small package size (~10MB vs ~500MB+)

---

## ⚡ Option 2: Direct Transfer with SCP/rsync

Transfer the entire project as-is.

### Method A: Using SCP

**On your MacBook:**

```bash
# Create Projects directory
mkdir -p ~/Projects

# Transfer entire directory
scp -r ravinv1@<LINUX_IP>:/home/ravinv1/mcp-chat-client-n ~/Projects/

# Example:
# scp -r ravinv1@192.168.1.100:/home/ravinv1/mcp-chat-client-n ~/Projects/
```

### Method B: Using rsync (Better for large transfers)

**On your MacBook:**

```bash
# Transfer with progress bar and compression
rsync -avz --progress ravinv1@<LINUX_IP>:/home/ravinv1/mcp-chat-client-n ~/Projects/

# To exclude large folders:
rsync -avz --progress \
  --exclude='node_modules' \
  --exclude='.next' \
  --exclude='.venv' \
  --exclude='__pycache__' \
  ravinv1@<LINUX_IP>:/home/ravinv1/mcp-chat-client-n ~/Projects/
```

**Benefits:** Simple, straightforward  
**Drawbacks:** Large file size if you don't exclude folders

---

## 🌟 Option 3: Git Repository (BEST for Ongoing Development)

Set up a Git repository for version control and easy syncing.

### Step 1: Initialize Git on Linux Server

```bash
cd /home/ravinv1/mcp-chat-client-n

# Initialize git repository
git init

# Create .gitignore
cat > .gitignore << 'EOF'
# Dependencies
node_modules/
.pnpm-store/

# Build outputs
.next/
dist/
build/

# Python
__pycache__/
*.py[cod]
.venv/
venv/
*.egg-info/

# Environment variables
.env
.env.local

# Logs
*.log

# OS files
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
EOF

# Add all files
git add .

# Commit
git commit -m "Initial commit: RTF Job Run Agent"
```

### Step 2A: Push to GitHub (Recommended)

1. **Create a new repository on GitHub:**
   - Go to https://github.com/new
   - Name it: `rtf-job-run-agent`
   - Set to Private (if it contains sensitive code)
   - Don't initialize with README (we already have files)

2. **Push from Linux:**

```bash
# Add remote
git remote add origin https://github.com/YOUR_USERNAME/rtf-job-run-agent.git

# Push code
git branch -M main
git push -u origin main
```

3. **Clone on MacBook:**

```bash
cd ~/Projects
git clone https://github.com/YOUR_USERNAME/rtf-job-run-agent.git
cd rtf-job-run-agent
```

### Step 2B: Use as Local Git Repository

If you don't want to use GitHub:

**On your MacBook:**

```bash
cd ~/Projects
git clone ravinv1@<LINUX_IP>:/home/ravinv1/mcp-chat-client-n rtf-job-agent
cd rtf-job-agent
```

**Benefits:**
- ✅ Version control
- ✅ Easy updates
- ✅ Can sync changes both ways
- ✅ Track all modifications

---

## 🔍 Finding Your Linux Server IP Address

On your Linux server:

```bash
# Option 1: Show all network interfaces
ip addr show

# Option 2: Show external IP
curl ifconfig.me

# Option 3: Using hostname
hostname -I
```

Look for an IP like `192.168.x.x` or `10.x.x.x`

---

## 📋 Pre-Transfer Checklist

Before transferring, verify on Linux:

```bash
cd /home/ravinv1/mcp-chat-client-n

# Check project structure
ls -la

# Verify frontend files exist
ls frontend/

# Verify backend files exist
ls backend/

# Check documentation files
ls *.md
```

You should see:
- `frontend/` folder
- `backend/` folder
- `README.md`
- `MACOS_SETUP_GUIDE.md`
- `MACOS_QUICKSTART.md`

---

## 🚀 After Transfer: Quick Setup Commands

Once files are on your MacBook, set up quickly:

### Terminal 1 - Backend

```bash
cd ~/Projects/rtf-job-agent/backend
python3 -m venv venv
source venv/bin/activate
pip install -e .
cp .env.example .env
# Edit .env and add your Google API key
uvicorn app.main:app --reload --port 3032
```

### Terminal 2 - Frontend

```bash
cd ~/Projects/rtf-job-agent/frontend
npm install
npm run dev
```

### Browser

Open: http://localhost:3000  
Login: `rtfuser` / `Password@123`

---

## 🆘 Troubleshooting Transfer Issues

### "Permission denied" error

```bash
# On MacBook, use your Linux username and password
# Make sure you can SSH first:
ssh ravinv1@<LINUX_IP>
```

### "Connection refused"

- Check if SSH is enabled on Linux server
- Verify firewall allows SSH (port 22)
- Confirm IP address is correct

### "No route to host"

- Make sure both computers are on same network (or have network path)
- Check IP address with `ip addr show` on Linux

### Transfer too slow

- Use rsync with compression: `rsync -avz`
- Use wired connection instead of WiFi
- Exclude large folders (node_modules, .next, etc.)

---

## 💾 Storage Space Requirements

**On MacBook:**

- Source code only: ~10 MB
- With docs and assets: ~15 MB
- After npm install: ~500 MB (frontend)
- After pip install: ~50 MB (backend)
- **Total needed:** ~600 MB free space

---

## 📊 Comparison of Methods

| Method | Difficulty | Speed | Size | Best For |
|--------|-----------|-------|------|----------|
| Package Script | Easy | Medium | Small (~10MB) | One-time transfer |
| SCP/rsync | Easy | Fast | Large (~500MB+) | Quick access |
| Git | Medium | Medium | Small (~10MB) | Ongoing development |

---

## ✅ Post-Transfer Verification

After setup on MacBook, verify everything works:

```bash
# 1. Check Node.js
node --version    # Should be v18+

# 2. Check Python
python3 --version # Should be 3.12+

# 3. Check frontend dependencies
cd ~/Projects/rtf-job-agent/frontend
ls node_modules   # Should see many packages

# 4. Check backend dependencies
cd ~/Projects/rtf-job-agent/backend
source venv/bin/activate
pip list           # Should see fastapi, uvicorn, etc.

# 5. Test the application
# Start both servers and login
```

---

## 🎓 Next Steps

After successful transfer and setup:

1. **Read the documentation:**
   - `MACOS_SETUP_GUIDE.md` - Comprehensive setup
   - `MACOS_QUICKSTART.md` - Quick reference
   - `README.md` - Project overview

2. **Configure your environment:**
   - Add Google API key to `.env`
   - Customize branding if needed
   - Review configuration settings

3. **Start developing:**
   - Both servers auto-reload on changes
   - Make edits and see results immediately
   - Use Git for version control

---

## 📞 Support

If you encounter any issues:

1. Check the `MACOS_SETUP_GUIDE.md` troubleshooting section
2. Review terminal error messages carefully
3. Verify all prerequisites are installed
4. Check environment variables in `.env` files

---

**Ready to transfer? Choose your method above and get started! 🚀**
