# Quick Start Guide - AI for FR

## 🚀 Running the Application

### Option 1: Frontend Only (Recommended for UI Testing)

1. **Navigate to frontend directory**:
   ```bash
   cd /home/ravinv1/mcp-chat-client-n/frontend
   ```

2. **Start the development server**:
   ```bash
   npm run dev
   ```

3. **Open in browser**:
   - Navigate to: http://localhost:3000
   - You'll see the login page
   - Enter any email/password to access the chat interface

### Option 2: Full Stack (Frontend + Backend)

#### Terminal 1 - Backend:
```bash
cd /home/ravinv1/mcp-chat-client-n/backend
source .venv/bin/activate  # or activate your virtual environment
uvicorn app.main:app --reload --port 3032
```

#### Terminal 2 - Frontend:
```bash
cd /home/ravinv1/mcp-chat-client-n/frontend
npm run dev
```

## 🎯 What to Expect

### 1. Login Page (Initial View)
- **Left Side**: Dark panel with AI for FR branding
  - Yellow/gold diamond logo
  - "AI for FR" title
  - "Commonwealth Bank of Australia" subtitle
  - Three feature highlights with checkmarks
  
- **Right Side**: Light panel with login form
  - Email/Username field
  - Password field (with show/hide toggle)
  - Remember me checkbox
  - Forgot password link
  - Yellow "Log on" button
  - Sign up option

### 2. Chat Interface (After Login)
- **Header**: 
  - AI for FR logo (mobile)
  - "AI Assistant" title
  - User badge
  - Logout button

- **Left Sidebar** (Desktop):
  - AI for FR branding
  - MCP Tools selector

- **Main Chat Area**:
  - Welcome message
  - Chat input at bottom
  - Message history (when you start chatting)

## 🔑 Demo Credentials

**Any credentials work!** The current implementation accepts any email/password combination.

Examples:
- Email: `demo@example.com`, Password: `password`
- Email: `test@test.com`, Password: `test123`
- Email: `admin`, Password: `admin`

## 🎨 UI Features to Notice

1. **Glassmorphism Effects**: Frosted glass panels throughout
2. **Smooth Animations**: Hover effects on buttons and inputs
3. **Responsive Design**: Resize your browser to see mobile/tablet views
4. **Dark Theme**: Professional dark color scheme
5. **Yellow Accents**: Gold/yellow highlights matching the branding
6. **Icon Integration**: User, lock, eye icons in forms

## 🛠️ Troubleshooting

### Port Already in Use
If port 3000 is busy:
```bash
npm run dev -- -p 3001
```

### Dependencies Missing
```bash
cd frontend
npm install
```

### Backend Connection Issues
- Make sure backend is running on port 3032
- Check the API URL in `components/chat-interface.tsx` (line 43)
- Update if your backend is on a different host/port

## 📸 Screenshots

The UI matches the design shown in your uploaded image:
- Split-screen login layout
- Dark left panel with branding
- Light right panel with form
- Yellow/gold accent colors
- Professional, modern aesthetic

## 🔄 Logout

Click the "Logout" button in the top-right corner of the chat interface to return to the login page.

## 📝 Next Steps

1. **Customize Branding**: 
   - Replace logo in `frontend/public/logo.png`
   - Update text in `components/login-page.tsx`

2. **Add Real Authentication**:
   - Implement proper login validation in `app/page.tsx`
   - Add JWT tokens or session management
   - Connect to your authentication backend

3. **Configure Backend**:
   - Update `.env` with your API keys
   - Configure MCP servers
   - Adjust CORS settings if needed

4. **Deploy**:
   - Frontend: Deploy to Vercel, Netlify, or similar
   - Backend: Deploy to your preferred hosting service

---

**Enjoy your new AI for FR chatbot interface! 🎉**
