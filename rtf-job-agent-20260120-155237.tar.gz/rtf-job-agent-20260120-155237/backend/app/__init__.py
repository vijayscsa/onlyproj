# FastAPI + LangGraph Backend with MCP Integration
