# Temporal AI-Powered Durable Auto-Remediation & Incident Response Platform

Production-ready DevSecOps/SRE platform combining **Temporal** (durable execution), **AI/LLMs** (intelligent decisioning), and **observability** (Prometheus + Grafana + OTel) for self-healing infrastructure.

## Quick Start (Local)

1. Install Temporal CLI: https://docs.temporal.io/cli
2. `temporal server start-dev`
3. `uv sync` (or `pip install -e .`)
4. `python -m src.worker`
5. In another terminal: `uvicorn src.api.main:app --reload`
6. Trigger example workflow via curl or Temporal UI (http://localhost:8233)

See `AGENTS.md` for full architecture, coding standards, and development process.  
See `.claude/skills/` for modular instructions that Claude Code / compatible agents load on-demand.

## Key Features Implemented in v1

- `IntelligentAutoRemediationWorkflow` with AI analysis + decision gate + human approval path
- Durable Activities for Prometheus queries, LLM calls, K8s remediation, verification
- Webhook trigger endpoint (simulates Grafana/Prometheus alertmanager webhook)
- OpenTelemetry tracing + Prometheus metrics export from worker
- Pydantic models for all AI structured outputs and workflow state
- Example compensation (Saga) pattern stub
- Time-skipping ready test structure

## Project Goals & KPIs (tracked in Grafana)

- MTTR reduction 50-80%
- >60% incidents auto-remediated
- >99.9% workflow execution success
- Full audit + replay history
- AI confidence feedback loop

This codebase is designed to be maintained and extended by AI coding agents using the `AGENTS.md` + `.claude/skills/*` system.

## Next Steps / Roadmap

- Add more remediation patterns (certificate rotation, node drain, security scanning)
- Production Helm charts + ArgoCD / Flux deployment
- Multi-LLM routing + cost tracking
- Self-improving loop (store successful remediations as few-shot examples)
- Integration with existing incident management (PagerDuty, ServiceNow)

Built following the architecture in `attachments/myfirst.md`.
