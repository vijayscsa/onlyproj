"""Temporal Activities for the AI SRE Platform.

All side-effecting, retryable, and potentially long-running work lives here.
Activities are the unit of failure/retry in Temporal.

Each activity should be:
- Idempotent where possible
- Have clear timeouts and retry policies defined in the Workflow
- Emit OpenTelemetry spans automatically (via interceptor)
- Use structured logging
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime
from typing import Any

import structlog
from kubernetes import client as k8s_client, config as k8s_config
from temporalio import activity

from src.core.models import (
    ObservabilitySnapshot,
    RemediationRequest,
    RemediationResult,
    WorkflowState,
)
from src.utils.llm_client import LLMClient
from src.utils.prometheus import query_prometheus  # type: ignore  # placeholder

logger = structlog.get_logger(__name__)

# Lazy K8s client (works inside cluster or with kubeconfig locally)
try:
    k8s_config.load_incluster_config()
except Exception:
    try:
        k8s_config.load_kube_config()
    except Exception:
        logger.warning("k8s.config.failed", msg="Running without K8s client (dry-run mode only)")

k8s_apps_v1 = k8s_client.AppsV1Api() if "k8s_config" in dir() else None  # type: ignore


@activity.defn(name="fetch_observability_data")
async def fetch_observability_data(service: str, namespace: str = "default") -> ObservabilitySnapshot:
    """Query Prometheus for current metrics, logs (if Loki integrated), and active alerts."""
    activity.logger.info("activity.start", activity="fetch_observability_data", service=service)

    # In production: use aiohttp + Prometheus HTTP API or prometheus-api-client
    # Here we simulate + allow override via env for demo
    metrics = {
        "error_rate": float(os.getenv("DEMO_ERROR_RATE", "0.08")),
        "p99_latency_ms": float(os.getenv("DEMO_P99", "1250")),
        "cpu_usage": 78.4,
        "memory_usage": 91.2,
    }

    # Real implementation would do:
    # promql = f'rate(http_requests_total{{service="{service}"}}[5m])'
    # results = await query_prometheus(promql)

    snapshot = ObservabilitySnapshot(
        service=service,
        namespace=namespace,
        metrics=metrics,
        logs_sample=[
            "2026-06-25T22:10:00Z ERROR OutOfMemoryError in PaymentProcessor.process()",
            "2026-06-25T22:10:05Z WARN High GC pressure detected",
        ],
        alerts=[f"HighErrorRate_{service}"],
        raw_promql_results={"http_error_rate": metrics["error_rate"]},
    )
    return snapshot


@activity.defn(name="ai_analysis")
async def ai_analysis(snapshot: dict[str, Any], trigger_source: str = "webhook") -> dict[str, Any]:
    """Call LLM for structured root cause analysis and remediation recommendation."""
    activity.logger.info("activity.start", activity="ai_analysis", trigger=trigger_source)

    client = LLMClient(provider=os.getenv("LLM_PROVIDER", "openai"))
    result = await client.analyze_incident(snapshot, trigger_source=trigger_source)
    return result.model_dump()


@activity.defn(name="execute_remediation")
async def execute_remediation(request: dict[str, Any]) -> dict[str, Any]:
    """Perform the actual remediation action (kubectl, cloud API, Ansible, etc.).

    IMPORTANT: This is where all mutating actions happen. Never put side effects in Workflow.
    """
    req = RemediationRequest.model_validate(request)
    activity.logger.info(
        "remediation.start",
        action=req.action.value,
        target=req.target,
        dry_run=req.dry_run,
    )

    if req.dry_run or k8s_apps_v1 is None:
        # Safe dry-run / demo mode
        await asyncio.sleep(0.5)
        return RemediationResult(
            success=True,
            action=req.action,
            output=f"DRY-RUN: Would have executed {req.action.value} on {req.target}",
            rollback_possible=True,
            compensation_activity="rollback_deployment" if req.action.value == "scale_deployment" else None,
        ).model_dump()

    # Real K8s example (expand for each action type)
    if req.action == "restart_pod":
        # In real code: find pods by label and delete them (they get recreated by deployment)
        output = f"Restarted pods for {req.target.get('service')} in {req.target.get('namespace')}"
    elif req.action == "scale_deployment":
        replicas = req.parameters.get("replicas", 5)
        # k8s_apps_v1.patch_namespaced_deployment_scale(...)
        output = f"Scaled deployment {req.target.get('service')} to {replicas} replicas"
    else:
        output = f"Action {req.action.value} executed (stub)"

    return RemediationResult(
        success=True,
        action=req.action,
        output=output,
        rollback_possible=True,
        compensation_activity="rollback_deployment" if "scale" in req.action.value else None,
    ).model_dump()


@activity.defn(name="verify_outcome")
async def verify_outcome(
    service: str, namespace: str, previous_metrics: dict[str, float]
) -> dict[str, Any]:
    """Re-query key metrics to determine if remediation was successful."""
    activity.logger.info("activity.start", activity="verify_outcome", service=service)

    # Simulate improvement
    new_metrics = {
        "error_rate": max(0.001, previous_metrics.get("error_rate", 0.1) * 0.15),
        "p99_latency_ms": max(150, previous_metrics.get("p99_latency_ms", 1000) * 0.6),
    }

    return ObservabilitySnapshot(
        service=service,
        namespace=namespace,
        metrics=new_metrics,
        alerts=[] if new_metrics["error_rate"] < 0.02 else ["StillDegraded"],
    ).model_dump()


@activity.defn(name="notify_and_audit")
async def notify_and_audit(state: dict[str, Any], final_status: str) -> None:
    """Send notifications (Slack, Teams, PagerDuty) and ensure audit trail.

    The full workflow history in Temporal is the primary audit source.
    This activity enriches external systems.
    """
    activity.logger.info(
        "audit.close",
        workflow_id=state.get("workflow_id"),
        status=final_status,
        remediations=len(state.get("remediation_executed", [])),
    )

    # TODO: Integrate Slack SDK / webhook, PagerDuty, ServiceNow, etc.
    # Example: httpx.post(os.getenv("SLACK_WEBHOOK"), json={"text": f"Workflow {state['workflow_id']} {final_status}"})
    pass
