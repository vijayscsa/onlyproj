"""FastAPI service exposing webhook endpoints to trigger Temporal workflows.

This simulates integration with:
- Grafana Alertmanager webhooks
- Prometheus Alertmanager
- Custom monitoring systems
- Manual trigger UI
"""

from __future__ import annotations

import os
from datetime import datetime

import structlog
from fastapi import FastAPI, HTTPException
from temporalio.client import Client

from src.core.models import TriggerPayload
from src.workflows.intelligent_auto_remediation import IntelligentAutoRemediationWorkflow

logger = structlog.get_logger(__name__)

app = FastAPI(
    title="Temporal AI SRE Trigger API",
    description="Webhook receiver that starts durable IntelligentAutoRemediationWorkflows",
    version="0.1.0",
)

_temporal_client: Client | None = None


async def get_temporal_client() -> Client:
    global _temporal_client
    if _temporal_client is None:
        _temporal_client = await Client.connect(
            os.getenv("TEMPORAL_HOST", "localhost:7233"),
            namespace=os.getenv("TEMPORAL_NAMESPACE", "default"),
        )
    return _temporal_client


@app.post("/webhook/grafana", status_code=202)
async def grafana_webhook(payload: dict) -> dict:
    """Accepts Grafana webhook payload and starts a remediation workflow.

    Example Grafana payload (simplified):
    {
      "alerts": [{"labels": {"alertname": "HighErrorRate", "service": "payment-api", "namespace": "prod"}}],
      "status": "firing"
    }
    """
    try:
        # Minimal parsing for demo — production would have richer mapping
        alert = payload.get("alerts", [{}])[0].get("labels", {})
        trigger = TriggerPayload(
            alert_name=alert.get("alertname", "UnknownAlert"),
            service=alert.get("service", "unknown-service"),
            namespace=alert.get("namespace", "default"),
            severity=alert.get("severity", "medium"),
            description=payload.get("message", "Anomaly detected via Grafana"),
            metrics={"error_rate": 0.15},  # Would parse from commonAnnotations or external query
            labels=alert,
        )

        client = await get_temporal_client()
        handle = await client.start_workflow(
            IntelligentAutoRemediationWorkflow.run,
            trigger,
            id=f"remediation-{trigger.service}-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
            task_queue=os.getenv("TEMPORAL_TASK_QUEUE", "sre-remediation-queue"),
        )

        logger.info("workflow.started_via_webhook", workflow_id=handle.id, service=trigger.service)
        return {"status": "accepted", "workflow_id": handle.id, "run_id": handle.first_execution_run_id}

    except Exception as exc:
        logger.error("webhook.failed", error=str(exc))
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/health")
async def health() -> dict:
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}


@app.get("/workflow/{workflow_id}/status")
async def get_workflow_status(workflow_id: str) -> dict:
    """Query live workflow status (uses Temporal Query)."""
    client = await get_temporal_client()
    handle = client.get_workflow_handle(workflow_id)
    try:
        status = await handle.query(IntelligentAutoRemediationWorkflow.get_status)
        return status
    except Exception as exc:
        raise HTTPException(status_code=404, detail=f"Workflow not found or query failed: {exc}") from exc
