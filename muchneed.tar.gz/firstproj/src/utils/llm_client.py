"""LLM client wrapper supporting multiple providers via LiteLLM or direct SDKs.

Provides structured output (Pydantic) for the AI Analysis Activity.
Handles retries, token tracking, and audit logging.
"""

from __future__ import annotations

import json
import os
from typing import Any

import structlog
from openai import AsyncOpenAI
from pydantic import BaseModel

from src.core.models import AIAnalysisResult
from src.core.prompts import SYSTEM_PROMPT_REMEDIATION_ANALYST, USER_PROMPT_TEMPLATE

logger = structlog.get_logger(__name__)


class LLMClient:
    """Async LLM client with structured output support."""

    def __init__(self, provider: str = "openai", model: str | None = None) -> None:
        self.provider = provider.lower()
        self.model = model or os.getenv("LLM_MODEL", "gpt-4o-mini")
        self.api_key = os.getenv("OPENAI_API_KEY") or os.getenv("ANTHROPIC_API_KEY") or os.getenv("XAI_API_KEY")

        if self.provider == "openai":
            self.client = AsyncOpenAI(api_key=self.api_key)
        elif self.provider == "anthropic":
            # For simplicity in v1 we use OpenAI-compatible endpoint or LiteLLM
            # In production use litellm or direct anthropic.AsyncAnthropic
            self.client = AsyncOpenAI(
                api_key=self.api_key,
                base_url="https://api.anthropic.com/v1" if not os.getenv("ANTHROPIC_BASE_URL") else None,
            )
        else:
            # Fallback / xAI / local via LiteLLM proxy or direct OpenAI compatible
            self.client = AsyncOpenAI(
                api_key=self.api_key or "sk-local",
                base_url=os.getenv("LLM_BASE_URL", "http://localhost:8000/v1"),
            )

    async def analyze_incident(
        self,
        snapshot: dict[str, Any],
        trigger_source: str = "webhook",
    ) -> AIAnalysisResult:
        """Call LLM with structured output and return validated Pydantic model."""
        user_prompt = USER_PROMPT_TEMPLATE.format(
            service=snapshot.get("service", "unknown"),
            namespace=snapshot.get("namespace", "default"),
            trigger_source=trigger_source,
            description=snapshot.get("description", "Anomaly detected"),
            severity=snapshot.get("severity", "medium"),
            metrics_json=json.dumps(snapshot.get("metrics", {}), indent=2),
            logs_sample="\n".join(snapshot.get("logs_sample", [])[:5]) or "No logs available",
            alerts="\n".join(snapshot.get("alerts", [])) or "None",
        )

        logger.info(
            "llm.analysis.start",
            provider=self.provider,
            model=self.model,
            prompt_length=len(user_prompt),
        )

        try:
            # Using OpenAI JSON mode + Pydantic validation for reliability
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT_REMEDIATION_ANALYST},
                    {"role": "user", "content": user_prompt},
                ],
                response_format={"type": "json_object"},
                temperature=0.1,
                max_tokens=1500,
            )

            content = response.choices[0].message.content
            if not content:
                raise ValueError("Empty response from LLM")

            # Parse + validate with Pydantic (extra safety layer)
            result = AIAnalysisResult.model_validate_json(content)

            logger.info(
                "llm.analysis.success",
                confidence=result.confidence,
                severity=result.severity,
                actions=[a.value for a in result.recommended_actions],
                tokens=response.usage.total_tokens if response.usage else None,
            )
            return result

        except Exception as exc:
            logger.error("llm.analysis.failed", error=str(exc), exc_info=True)
            # Fallback conservative result
            return AIAnalysisResult(
                severity="high",
                root_cause="LLM analysis failed — falling back to conservative escalation",
                confidence=0.3,
                recommended_actions=["escalate"],
                rationale=f"LLM call failed with error: {exc}. Manual investigation required.",
                estimated_impact="Unknown — treat as high severity until investigated",
                requires_human_approval=True,
                suggested_approval_message="LLM analysis encountered an error. Please review the raw observability data and decide on remediation manually.",
            )
