"""Prometheus query helpers (stub for v1).

In production replace with aiohttp calls to Prometheus HTTP API or prometheus-api-client library.
"""

from __future__ import annotations

from typing import Any


async def query_prometheus(promql: str, time: str | None = None) -> dict[str, Any]:
    """Execute PromQL query against Prometheus.

    Returns parsed result. Add caching + circuit breaker in real impl.
    """
    # Placeholder — replace with real HTTP call
    return {
        "status": "success",
        "data": {
            "resultType": "vector",
            "result": [{"metric": {"__name__": "up"}, "value": [1234567890.0, "1"]}],
        },
    }
