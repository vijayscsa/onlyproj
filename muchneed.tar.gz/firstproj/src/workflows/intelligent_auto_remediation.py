"""IntelligentAutoRemediationWorkflow

The flagship durable workflow for the platform.

Features:
- Triggered by webhook, schedule, or signal
- Fetches observability data
- AI-powered root cause + recommendation
- Decision gate with human-in-the-loop via Signal
- Safe remediation execution (Activities)
- Outcome verification loop
- Full audit + compensation support
- ContinueAsNew for very long-running cases
"""

from __future__ import annotations

import asyncio
from datetime import timedelta
from typing import Any

import structlog
from temporalio import workflow
from temporalio.common import RetryPolicy
from temporalio.exceptions import ActivityError, ApplicationError

# Import models and activity stubs (Temporal will replace with real implementations at runtime)
from src.core.models import (
    AIAnalysisResult,
    Decision,
    ObservabilitySnapshot,
    RemediationAction,
    RemediationRequest,
    RemediationResult,
    Severity,
    TriggerPayload,
    WorkflowState,
)
from src.activities import (  # noqa: E402
    ai_analysis,
    execute_remediation,
    fetch_observability_data,
    notify_and_audit,
    verify_outcome,
)

logger = structlog.get_logger(__name__)

# Custom retry policy for production resilience
DEFAULT_RETRY_POLICY = RetryPolicy(
    initial_interval=timedelta(seconds=1),
    maximum_interval=timedelta(minutes=5),
    backoff_coefficient=2.0,
    maximum_attempts=5,
    non_retryable_error_types=["ApplicationError"],  # Customize as needed
)


@workflow.defn(name="IntelligentAutoRemediationWorkflow")
class IntelligentAutoRemediationWorkflow:
    """Durable, AI-augmented incident response and auto-remediation workflow."""

    def __init__(self) -> None:
        self.state = WorkflowState(workflow_id=workflow.info().workflow_id)
        self._approval_signal: asyncio.Future[str] | None = None
        self._cancel_signal = False

    @workflow.signal
    async def approve_remediation(self, notes: str = "") -> None:
        """Human approval signal handler."""
        logger.info("signal.received", signal="approve_remediation", notes=notes)
        if self._approval_signal:
            self._approval_signal.set_result(notes)
        self.state.human_approval_notes = notes

    @workflow.signal
    async def reject_remediation(self, reason: str = "") -> None:
        logger.info("signal.received", signal="reject_remediation", reason=reason)
        self.state.final_status = "escalated"
        self._cancel_signal = True

    @workflow.query
    def get_status(self) -> dict[str, Any]:
        """Real-time status for dashboards / human operators."""
        return self.state.model_dump(mode="json")

    @workflow.run
    async def run(self, payload: TriggerPayload | dict[str, Any]) -> WorkflowState:
        """Main workflow entrypoint. Durable execution guaranteed by Temporal."""
        if isinstance(payload, dict):
            payload = TriggerPayload.model_validate(payload)

        self.state.trigger_source = "webhook"  # or parse from payload
        self.state.initial_snapshot = ObservabilitySnapshot(
            service=payload.service,
            namespace=payload.namespace,
            metrics=payload.metrics,
            alerts=[payload.description],
        )

        workflow.logger.info(
            "workflow.started",
            workflow_id=workflow.info().workflow_id,
            service=payload.service,
            trigger=payload.alert_name,
        )

        try:
            # 1. Fetch fresh observability data (Activity)
            snapshot = await workflow.execute_activity(
                activities.fetch_observability_data,
                args=[payload.service, payload.namespace],
                start_to_close_timeout=timedelta(seconds=30),
                retry_policy=DEFAULT_RETRY_POLICY,
            )
            self.state.initial_snapshot = snapshot

            # 2. AI Analysis (durable LLM call - state will survive if workflow crashes mid-call)
            ai_result: AIAnalysisResult = await workflow.execute_activity(
                activities.ai_analysis,
                args=[snapshot.model_dump(), self.state.trigger_source],
                start_to_close_timeout=timedelta(minutes=2),  # LLMs can be slow
                retry_policy=RetryPolicy(
                    initial_interval=timedelta(seconds=5),
                    maximum_interval=timedelta(minutes=1),
                    backoff_coefficient=1.5,
                    maximum_attempts=3,
                ),
            )
            self.state.ai_analysis = ai_result

            # 3. Decision Gate
            decision = self._make_decision(ai_result)
            self.state.decision = decision

            if decision == Decision.HUMAN_APPROVAL:
                workflow.logger.info("decision.human_approval_required", confidence=ai_result.confidence)
                # Wait for human signal with timeout
                self._approval_signal = asyncio.Future()
                try:
                    approval_notes = await asyncio.wait_for(
                        self._approval_signal, timeout=workflow.timedelta(hours=4)
                    )
                    self.state.human_approval_notes = approval_notes
                    workflow.logger.info("human.approved", notes=approval_notes)
                except asyncio.TimeoutError:
                    workflow.logger.warning("human.approval_timeout")
                    self.state.final_status = "escalated"
                    return self.state

            if decision == Decision.ESCALATE or self._cancel_signal:
                self.state.final_status = "escalated"
                await self._notify_and_audit("escalated")
                return self.state

            if decision == Decision.AUTO_REMEDIATE or (
                decision == Decision.HUMAN_APPROVAL and self.state.human_approval_notes
            ):
                # 4. Execute remediation (one or more actions)
                for action in ai_result.recommended_actions:
                    if action == RemediationAction.NO_ACTION:
                        continue

                    req = RemediationRequest(
                        action=action,
                        target={"service": payload.service, "namespace": payload.namespace},
                        reason=ai_result.rationale,
                        dry_run=False,
                    )
                    result: RemediationResult = await workflow.execute_activity(
                        activities.execute_remediation,
                        args=[req.model_dump()],
                        start_to_close_timeout=timedelta(minutes=5),
                        retry_policy=DEFAULT_RETRY_POLICY,
                    )
                    self.state.remediation_executed.append(result.model_dump())

                    # Optional: compensation registration example (Saga)
                    if result.rollback_possible and result.compensation_activity:
                        # In real impl: workflow.set_signal_handler or use compensation workflow
                        workflow.logger.info("compensation.registered", action=action.value)

            # 5. Verify outcome (loop with backoff if needed)
            for attempt in range(3):
                verify_snapshot = await workflow.execute_activity(
                    activities.verify_outcome,
                    args=[payload.service, payload.namespace, self.state.initial_snapshot.metrics],
                    start_to_close_timeout=timedelta(seconds=45),
                    retry_policy=DEFAULT_RETRY_POLICY,
                )
                self.state.verification_snapshots.append(verify_snapshot)

                if self._is_remediation_successful(verify_snapshot):
                    self.state.final_status = "success"
                    break

                if attempt < 2:
                    await workflow.sleep(timedelta(minutes=2))  # backoff
            else:
                self.state.final_status = "failed"

            # 6. Notify, audit, close loop
            await self._notify_and_audit(self.state.final_status or "unknown")

            workflow.logger.info(
                "workflow.completed",
                status=self.state.final_status,
                remediations=len(self.state.remediation_executed),
            )
            return self.state

        except Exception as exc:
            self.state.error_history.append(str(exc))
            self.state.final_status = "failed"
            workflow.logger.error("workflow.failed", error=str(exc), exc_info=True)
            await self._notify_and_audit("failed")
            raise ApplicationError(f"Workflow failed: {exc}") from exc

    def _make_decision(self, ai_result: AIAnalysisResult) -> Decision:
        """Simple policy-based decision gate. Extend with more rules as needed."""
        if ai_result.requires_human_approval or ai_result.confidence < 0.65:
            return Decision.HUMAN_APPROVAL
        if ai_result.severity in (Severity.CRITICAL, Severity.HIGH) and any(
            a in (RemediationAction.DRAIN_NODE, RemediationAction.ROLLBACK_DEPLOYMENT, RemediationAction.PATCH_SECURITY)
            for a in ai_result.recommended_actions
        ):
            return Decision.HUMAN_APPROVAL
        if RemediationAction.ESCALATE in ai_result.recommended_actions:
            return Decision.ESCALATE
        return Decision.AUTO_REMEDIATE

    def _is_remediation_successful(self, snapshot: ObservabilitySnapshot) -> bool:
        """Simple success heuristic. In production: compare against SLOs or ML baseline."""
        error_rate = snapshot.metrics.get("error_rate", 1.0)
        latency = snapshot.metrics.get("p99_latency_ms", 9999)
        return error_rate < 0.02 and latency < 800

    async def _notify_and_audit(self, status: str) -> None:
        """Always runs. Sends notifications and ensures full history is recorded."""
        try:
            await workflow.execute_activity(
                activities.notify_and_audit,
                args=[self.state.model_dump(), status],
                start_to_close_timeout=timedelta(seconds=30),
                retry_policy=DEFAULT_RETRY_POLICY,
            )
        except ActivityError:
            workflow.logger.warning("notify.failed_but_continuing", status=status)
            # Audit history is still in Temporal even if notification fails
