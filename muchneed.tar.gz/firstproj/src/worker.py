"""Temporal Worker entrypoint.

Run with: python -m src.worker
This worker registers all Workflows and Activities and connects to the Temporal cluster.
"""

import asyncio
import os

import structlog
from temporalio.client import Client
from temporalio.contrib.opentelemetry import TracingInterceptor
from temporalio.worker import Worker

from src.activities import (
    ai_analysis,
    execute_remediation,
    fetch_observability_data,
    notify_and_audit,
    verify_outcome,
)
from src.workflows.intelligent_auto_remediation import IntelligentAutoRemediationWorkflow

logger = structlog.get_logger(__name__)


async def main() -> None:
    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")
    namespace = os.getenv("TEMPORAL_NAMESPACE", "default")

    logger.info("worker.connecting", host=temporal_host, namespace=namespace)

    client = await Client.connect(
        temporal_host,
        namespace=namespace,
        interceptors=[TracingInterceptor()],  # Enables OTel tracing
    )

    worker = Worker(
        client,
        task_queue=os.getenv("TEMPORAL_TASK_QUEUE", "sre-remediation-queue"),
        workflows=[IntelligentAutoRemediationWorkflow],
        activities=[
            fetch_observability_data,
            ai_analysis,
            execute_remediation,
            verify_outcome,
            notify_and_audit,
        ],
        max_concurrent_activities=50,
        max_concurrent_workflow_tasks=100,
    )

    logger.info("worker.started", task_queue=worker.task_queue)
    await worker.run()


if __name__ == "__main__":
    asyncio.run(main())
