"""Core Pydantic models for the Temporal AI SRE Platform.

These models are used for:
- Workflow input/state
- Activity inputs/outputs
- AI structured responses (guaranteed JSON via Pydantic + provider JSON mode)
- Observability data
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class RemediationAction(str, Enum):
    RESTART_POD = "restart_pod"
    SCALE_DEPLOYMENT = "scale_deployment"
    ROLLBACK_DEPLOYMENT = "rollback_deployment"
    DRAIN_NODE = "drain_node"
    PATCH_SECURITY = "patch_security"
    RESTART_SERVICE = "restart_service"
    CUSTOM_SCRIPT = "custom_script"
    NO_ACTION = "no_action"
    ESCALATE = "escalate"


class Decision(str, Enum):
    AUTO_REMEDIATE = "auto_remediate"
    HUMAN_APPROVAL = "human_approval"
    ESCALATE = "escalate"
    IGNORE = "ignore"


class ObservabilitySnapshot(BaseModel):
    """Snapshot of relevant metrics/logs at trigger time or verification time."""
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    service: str
    namespace: str = "default"
    metrics: dict[str, float] = Field(default_factory=dict)  # e.g. {"error_rate": 0.12, "p99_latency_ms": 2450}
    logs_sample: list[str] = Field(default_factory=list, max_items=10)
    alerts: list[str] = Field(default_factory=list)
    raw_promql_results: dict[str, Any] = Field(default_factory=dict)


class AIAnalysisResult(BaseModel):
    """Structured output from LLM analysis activity. Enforced via Pydantic + JSON mode."""
    severity: Severity
    root_cause: str = Field(..., min_length=20, description="Concise root cause hypothesis")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Model confidence in analysis")
    recommended_actions: list[RemediationAction]
    rationale: str = Field(..., min_length=30)
    estimated_impact: str
    requires_human_approval: bool = Field(
        default=False, description="True if action is high-risk or confidence < threshold"
    )
    suggested_approval_message: str | None = None


class WorkflowState(BaseModel):
    """Persisted state inside the Workflow. Enables durability + resume after crash."""
    workflow_id: str
    trigger_source: Literal["webhook", "schedule", "signal", "manual"] = "webhook"
    initial_snapshot: ObservabilitySnapshot
    ai_analysis: AIAnalysisResult | None = None
    decision: Decision | None = None
    remediation_executed: list[dict[str, Any]] = Field(default_factory=list)
    verification_snapshots: list[ObservabilitySnapshot] = Field(default_factory=list)
    final_status: Literal["success", "failed", "escalated", "pending_approval"] | None = None
    human_approval_notes: str | None = None
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None
    error_history: list[str] = Field(default_factory=list)


class RemediationRequest(BaseModel):
    action: RemediationAction
    target: dict[str, str]  # e.g. {"deployment": "api", "namespace": "prod"}
    parameters: dict[str, Any] = Field(default_factory=dict)
    dry_run: bool = False
    reason: str


class RemediationResult(BaseModel):
    success: bool
    action: RemediationAction
    output: str
    rollback_possible: bool = True
    compensation_activity: str | None = None  # Name of compensating activity if needed
    metrics_after: dict[str, float] | None = None


class TriggerPayload(BaseModel):
    """Incoming webhook payload (e.g. from Grafana Alertmanager or custom Prometheus alert)."""
    alert_name: str
    service: str
    namespace: str = "default"
    severity: Severity = Severity.MEDIUM
    description: str
    metrics: dict[str, float] = Field(default_factory=dict)
    labels: dict[str, str] = Field(default_factory=dict)
    runbook_url: str | None = None
