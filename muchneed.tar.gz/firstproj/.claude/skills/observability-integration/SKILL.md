---
name: observability-integration
description: Use when adding or modifying Prometheus queries, Grafana dashboards, OpenTelemetry instrumentation, alert webhook handling, or correlation between workflow executions and infrastructure metrics. Covers closed-loop feedback from observability into Temporal workflows.
---

# Observability Integration Skill

## When to Use
- Adding new PromQL queries in `fetch_observability_data` or `verify_outcome`
- Creating/updating Grafana dashboards or alert rules that trigger workflows
- Adding custom metrics from Workflows/Activities (success rate, AI confidence, MTTR, etc.)
- Setting up distributed tracing or improving correlation in Grafana

## Architecture Reminder
Observability is both **input** (triggers + context for AI) and **output** (verification + dashboards).

Flow:
Prometheus/Grafana Alert → Webhook (FastAPI) → Temporal Workflow → AI Decision → Remediation (Activity) → Re-query metrics (verify) → Close loop

## Key Files
- `src/activities/__init__.py` → `fetch_observability_data`, `verify_outcome`
- `src/utils/prometheus.py` (stub — replace with real client)
- `src/api/main.py` → webhook receiver
- `configs/` → prometheus.yml, grafana provisioning
- `deploy/k8s/observability/` → ServiceMonitors, dashboards

## Instructions

### Adding a New Metric to AI Context
1. In `fetch_observability_data` (or a dedicated activity), add PromQL query.
2. Include result in `ObservabilitySnapshot.metrics` or `raw_promql_results`.
3. The AI prompt template automatically includes `metrics_json`.

### Creating Grafana Alert that Triggers Workflow
In Grafana:
- Create alert rule on your service metrics + Temporal metrics (e.g. high workflow failure rate)
- In "Contact point" use Webhook → point to your FastAPI `/webhook/grafana`
- Or use Alertmanager with custom receiver that calls the Temporal webhook.

### Exposing Workflow Metrics
Add a Prometheus exporter in the worker (or sidecar) that scrapes:
- Number of active workflows per type
- AI decision distribution (auto vs human)
- Remediation success rate
- Average confidence score

Use `prometheus_client` + custom collector or OpenTelemetry metrics bridge.

### Correlation in Grafana
Recommended panels:
- Workflow executions timeline (from Temporal metrics) overlaid on service error rate / latency
- AI confidence histogram + remediation outcome
- MTTR before/after platform adoption

Import community Temporal dashboards and extend them.

## Best Practices
- Use consistent labels (`service`, `namespace`, `workflow_id`) across all metrics and traces.
- Instrument LLM calls with OTel for token usage + latency attribution.
- Make `verify_outcome` compare against SLOs or dynamic baselines, not just static thresholds.

See `AGENTS.md` section on Observability Enhancements for full vision.
