---
name: ai-integration
description: Use when implementing, improving, or debugging the AI/LLM layer (analysis activity, prompts, structured output, multi-provider support, cost tracking, feedback loops). Covers LLMClient, Pydantic validation, prompt engineering, and durability of agentic state inside Temporal.
---

# AI Integration Skill

## When to Use
- Modifying `src/utils/llm_client.py` or prompts
- Adding new LLM providers or switching models
- Improving structured output reliability (JSON mode + Pydantic)
- Implementing feedback loop (store successful remediations as few-shot examples)
- Adding token usage / cost metrics

## Key Components
- `src/utils/llm_client.py` — AsyncOpenAI wrapper with fallback + logging
- `src/core/prompts.py` — SYSTEM_PROMPT + USER_PROMPT_TEMPLATE (version these carefully)
- `src/core/models.py` — `AIAnalysisResult` Pydantic model (the contract)
- `src/activities/__init__.py` — `ai_analysis` activity that calls the client

## Instructions for Changes

### Updating Prompts
1. Edit `src/core/prompts.py`
2. Keep `SYSTEM_PROMPT_REMEDIATION_ANALYST` strict about JSON-only output and conservative high-risk actions
3. Test with real incidents — measure confidence calibration vs actual success
4. Add few-shot examples inside the user template for better performance on edge cases

### Adding a New Provider (xAI, local vLLM, etc.)
Extend `LLMClient.__init__`:
```python
if self.provider == "xai":
    self.client = AsyncOpenAI(base_url="https://api.x.ai/v1", api_key=...)
elif self.provider == "litellm":
    import litellm
    # litellm handles routing
```

### Making AI More Reliable
- Always use `response_format={"type": "json_object"}` + Pydantic `model_validate_json`
- Add fallback conservative result on any LLM failure (already implemented)
- Log full prompt + raw response + token count for audit + debugging
- Track `confidence` vs `actual_outcome` in `notify_and_audit` for future RL / few-shot improvement

### Durability Pattern (Most Important)
The Workflow itself stores `self.state.ai_analysis`. If the workflow is terminated and restarted (or continues after crash), the previous AI decision is still available. The next LLM call can be made conditional on previous state.

Example future improvement: "If similar incident occurred in last 7 days and was successfully remediated, include that history in the prompt."

## Testing AI Changes
- Unit test the `LLMClient` with mocked responses
- Integration test the full workflow with time-skipping + mocked `ai_analysis` activity that returns fixed `AIAnalysisResult`
- Manually trigger via webhook and inspect Temporal history for the exact prompt sent and JSON received

## Security Note
Never log raw API keys. Never put secrets in Workflow history. LLM calls happen only inside Activities.
