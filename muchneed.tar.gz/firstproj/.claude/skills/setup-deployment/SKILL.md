---
name: setup-deployment
description: Use this skill when setting up the Temporal cluster, Kubernetes manifests, Docker images, local dev environment, or production deployment of the AI SRE remediation platform. Covers Helm, docker-compose, environment variables, and initial worker/API deployment.
---

# Setup & Deployment Skill

## When to Use
- First-time project setup on a new machine or cluster
- Creating or modifying Dockerfiles, docker-compose, K8s manifests, or Helm values
- Configuring Temporal Cloud vs self-hosted
- Setting up local dev with `temporal server start-dev`
- Adding new environment variables or secrets management

## Prerequisites
- Docker + Kubernetes (minikube/kind or real cluster) or access to Temporal Cloud
- Temporal CLI installed
- `uv` or Python 3.11+ with pip
- kubectl configured

## Step-by-Step Instructions

### 1. Local Development Environment (Fastest for iteration)
```bash
# Terminal 1: Temporal dev server (includes Web UI at :8233)
temporal server start-dev --ui-port 8233

# Terminal 2: Install Python deps
cd /path/to/firstproj
uv sync --dev

# Terminal 3: Start worker (registers workflows + activities)
python -m src.worker

# Terminal 4: Start webhook API
uvicorn src.api.main:app --reload --port 8000
```

Test with:
```bash
curl -X POST http://localhost:8000/webhook/grafana \
  -H "Content-Type: application/json" \
  -d '{"alerts":[{"labels":{"alertname":"HighErrorRate","service":"payment-api","namespace":"prod"}}]}'
```

Check progress in Temporal UI: http://localhost:8233

### 2. Full Local Stack with docker-compose (includes Prometheus + Grafana)
See `deploy/docker/docker-compose.yml` (create if missing using this skill).

Key services to include:
- temporal (auto-setup + UI)
- postgres (Temporal persistence)
- prometheus
- grafana (with provisioning for Temporal dashboards)
- worker + api (your containers)

### 3. Production Kubernetes Deployment
1. Deploy Temporal via official Helm chart:
   ```bash
   helm repo add temporal https://temporalio.github.io/helm-charts
   helm install temporal temporal/temporal --namespace temporal --create-namespace \
     -f deploy/k8s/temporal/values.yaml
   ```

2. Build and push worker + api images:
   ```bash
   docker build -t ghcr.io/yourorg/temporal-ai-worker:latest -f deploy/docker/Dockerfile.worker .
   docker push ...
   ```

3. Deploy workers as Deployment + ServiceAccount with least-privilege RBAC (see `deploy/k8s/workers/`).

4. Configure Prometheus to scrape:
   - Temporal metrics endpoint
   - Your worker metrics (if exposed)
   - Application targets

5. Import Grafana dashboards from temporalio/dashboards repo + custom ones in `configs/grafana/`.

### 4. Environment Variables (critical)
```bash
TEMPORAL_HOST=localhost:7233
TEMPORAL_TASK_QUEUE=sre-remediation-queue
LLM_PROVIDER=openai          # or anthropic, xai, litellm
LLM_MODEL=gpt-4o-mini
OPENAI_API_KEY=sk-...
# For K8s in-cluster: no extra config needed
```

### 5. Verification Checklist
- [ ] Temporal UI shows registered workflows and task queue
- [ ] Worker logs show "worker.started"
- [ ] Webhook returns 202 + workflow_id
- [ ] Workflow completes successfully in UI (check history for AI decision + remediation)
- [ ] Prometheus targets are up (Temporal + custom)
- [ ] Grafana shows Temporal dashboard + your service metrics correlated

## Common Pitfalls & Fixes
- **Connection refused to Temporal**: Check TEMPORAL_HOST and that server is running on correct port.
- **LLM calls fail**: Verify API key and that JSON mode is supported by model.
- **K8s permissions**: Worker ServiceAccount needs `get`/`patch` on deployments/pods in target namespaces.
- **Workflow history too large**: Use `workflow.continue_as_new()` for long-running remediation loops.

## References
- Official Temporal Helm chart docs
- `AGENTS.md` → Deployment section
- `deploy/k8s/` directory for manifests
