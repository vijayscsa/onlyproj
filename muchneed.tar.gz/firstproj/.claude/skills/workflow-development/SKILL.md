---
name: workflow-development
description: Use when creating, modifying, or reviewing Temporal Workflows and Activities for the AI SRE platform. Covers structure, primitives (retries, signals, queries, compensation), AI durability patterns, testing with time-skipping, and best practices from AGENTS.md.
---

# Workflow Development Skill

## When to Use
- Adding a new remediation workflow (e.g. certificate rotation, security patching, node maintenance)
- Modifying `IntelligentAutoRemediationWorkflow` or its activities
- Implementing new decision gates, human-in-the-loop flows, or Saga compensation
- Writing or updating tests in `tests/`

## Core Principles (from AGENTS.md)
- **Workflows** = durable business logic & orchestration (pure, replayable)
- **Activities** = all side effects, I/O, LLM calls, K8s actions, notifications
- Every Workflow must have corresponding Pydantic models in `src/core/models.py`
- Use custom `RetryPolicy` with exponential backoff
- Instrument with OpenTelemetry (interceptor on Worker)
- All mutating actions → Activities only

## Step-by-Step: Adding a New Remediation Workflow

1. **Define models** (if new types needed) in `src/core/models.py`:
   - Extend `RemediationAction` enum if new action type
   - Add new Pydantic models for input/state if complex

2. **Implement Activities** in `src/activities/__init__.py` (or new file + import):
   - Use `@activity.defn(name="your_activity_name")`
   - Make idempotent
   - Return Pydantic models or dicts
   - Add structured logging + OTel spans (automatic via interceptor)

3. **Create Workflow** in `src/workflows/your_new_workflow.py`:
   - `@workflow.defn(name="YourWorkflowName")`
   - Class with `__init__` for state + signal futures
   - `@workflow.run` async def run(self, input_model)
   - Use `workflow.execute_activity(YourActivity.func, args=[...], start_to_close_timeout=..., retry_policy=...)`
   - Add Signals for human approval: `@workflow.signal async def approve_xxx(self, notes: str)`
   - Add Queries: `@workflow.query def get_status(self)`
   - Implement compensation/Saga where needed

4. **Register in Worker** (`src/worker.py`):
   - Add Workflow class to `workflows=[...]`
   - Add activity functions to `activities=[...]`

5. **Write Tests** (`tests/test_your_workflow.py`):
   - Use `temporalio.testing.WorkflowEnvironment` + time-skipping
   - Mock activities with `env.register_activity(...)` or patch
   - Assert on final state, signals, timers

6. **Update docs** and optionally add example to `remediation-patterns` skill.

## Recommended Temporal Primitives for This Platform

- **Retries**: Always pass explicit `RetryPolicy` to `execute_activity`
- **Timers / Sleep**: `await workflow.sleep(timedelta(minutes=5))` for backoff between verification attempts
- **Signals**: Human approval, external events (e.g. "deployment finished")
- **Queries**: Real-time status for dashboards / on-call engineers
- **ContinueAsNew**: For very long-running remediation + learning loops
- **Compensation**: Register compensating activities; on failure path call them in reverse order
- **Versioning**: Use `workflow.get_version("feature-x", 1, 2)` before changing logic

## AI + Durability Pattern (Critical)
```python
# Inside Workflow
ai_result = await workflow.execute_activity(ai_analysis, args=[snapshot], ...)
self.state.ai_analysis = ai_result   # Persisted automatically by Temporal

# If workflow crashes here → on resume, ai_result is still in self.state
# LLM conversation can continue from last known point
```

Never put LLM calls or long I/O directly in Workflow code.

## Testing Best Practices
```python
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

@pytest.mark.asyncio
async def test_auto_remediation_success():
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(env.client, task_queue="test", workflows=[IntelligentAutoRemediationWorkflow], activities=[...]):
            handle = await env.client.start_workflow(...)
            result = await handle.result()
            assert result.final_status == "success"
```

Use `env.sleep()` and `env.now` to test timers without real waiting.

## Common Anti-Patterns to Avoid
- Putting `kubectl` / `openai` calls inside `@workflow.run` → will break determinism
- Missing timeouts on activities → can cause stuck workflows
- Not handling `asyncio.TimeoutError` on `wait_for_signal`
- Changing Workflow logic without versioning → breaks replay of old executions

## Files to Touch
- `src/core/models.py`
- `src/activities/__init__.py`
- `src/workflows/*.py`
- `src/worker.py`
- `tests/`
- Update `AGENTS.md` if new patterns emerge

See existing `IntelligentAutoRemediationWorkflow` as the canonical example.
