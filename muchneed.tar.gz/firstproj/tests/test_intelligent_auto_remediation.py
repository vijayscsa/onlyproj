"""Example time-skipping test for the main workflow.

Run with: pytest tests/ -q --asyncio-mode=auto
"""

import pytest
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

from src.activities import (
    ai_analysis,
    execute_remediation,
    fetch_observability_data,
    notify_and_audit,
    verify_outcome,
)
from src.core.models import TriggerPayload
from src.workflows.intelligent_auto_remediation import IntelligentAutoRemediationWorkflow


@pytest.mark.asyncio
async def test_auto_remediation_success_path():
    async with await WorkflowEnvironment.start_time_skipping() as env:
        # Register mocked activities that return happy-path data
        async with Worker(
            env.client,
            task_queue="test-queue",
            workflows=[IntelligentAutoRemediationWorkflow],
            activities=[
                fetch_observability_data,
                ai_analysis,  # Will use real LLM if key present; in CI use mock
                execute_remediation,
                verify_outcome,
                notify_and_audit,
            ],
        ):
            payload = TriggerPayload(
                alert_name="HighErrorRate",
                service="test-service",
                namespace="default",
                description="Simulated high error rate for test",
                metrics={"error_rate": 0.12, "p99_latency_ms": 1500},
            )

            handle = await env.client.start_workflow(
                IntelligentAutoRemediationWorkflow.run,
                payload,
                id="test-remediation-success",
                task_queue="test-queue",
            )

            result = await handle.result()
            assert result.final_status in ("success", "failed")  # Depending on mock data
            assert result.ai_analysis is not None
            print("Test completed. Final status:", result.final_status)
