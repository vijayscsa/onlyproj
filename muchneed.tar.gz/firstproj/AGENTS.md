# AGENTS.md - Temporal AI-Powered Durable Auto-Remediation & Incident Response Platform

**Project Purpose**  
This is a production-grade DevSecOps/SRE platform that transforms reactive observability into proactive, intelligent, self-healing infrastructure using **Temporal** as the durable orchestration engine + **AI (LLM)** for dynamic decision-making + **Prometheus/Grafana/OpenTelemetry** for closed-loop observability.

It addresses high MTTR, toil, brittle scripts, and lack of auditability in incident response, self-healing, security patching, CI/CD gates, and remediation workflows.

**Core Value Proposition** (from design doc)  
- Crash-proof, stateful, long-running workflows that survive failures and resume exactly where left off.  
- AI-augmented activities for intelligent RCA, decisioning, and adaptive remediation.  
- Full auditability via immutable Temporal history + OpenTelemetry traces.  
- Human-in-the-loop via Signals when confidence is low or high-risk actions.  
- Measurable KPIs: 50-80% MTTR reduction, >60% auto-remediation rate, >99.9% workflow reliability.

## Tech Stack & Architecture

**Orchestration**  
- Temporal Cluster (self-hosted on K8s via Helm or Temporal Cloud)  
- Python SDK (`temporalio`) for Workflows + Activities (primary; Go/TS/Java also supported)  
- Workers deployed as scalable K8s Deployments with RBAC/IAM

**AI Layer**  
- LLM providers: OpenAI, Anthropic, xAI (Grok), or local via LiteLLM / vLLM  
- Structured outputs (JSON mode / Pydantic) for RCA, severity, recommended actions, confidence  
- Conversation / agent state persisted inside Temporal Workflow for durability across interruptions

**Observability & Triggers**  
- Prometheus: scrapes Temporal metrics + app/infra metrics + custom workflow metrics  
- Grafana: unified dashboards (Temporal + app metrics + workflow timelines) + alert webhooks  
- OpenTelemetry: distributed tracing across Workflow → Activity → LLM calls → K8s actions  
- Alert sources → Temporal via webhook (FastAPI endpoint), Schedule, or Signal

**Supporting**  
- FastAPI + Uvicorn for trigger webhooks and human approval UI (optional)  
- Kubernetes + Helm for all components  
- Secrets: Kubernetes Secrets / External Secrets Operator / Vault  
- Python: 3.11+, pydantic, structlog, opentelemetry-instrumentation, prometheus-client (for custom metrics)

**High-Level Data Flow**  
1. Prometheus/Grafana anomaly or scheduled trigger → Webhook/Signal/Schedule starts `IntelligentAutoRemediationWorkflow`  
2. `FetchObservabilityData` Activity (PromQL queries)  
3. `AIAnalysis` Activity (structured prompt → LLM → Pydantic model)  
4. `DecisionGate` (rules + confidence threshold → auto | human-approval Signal | escalate)  
5. `ExecuteRemediation` (kubectl, cloud SDKs, Ansible, security tools — always in Activity with retries + compensation)  
6. `VerifyOutcome` (re-query metrics, loop or close)  
7. `NotifyAndAudit` (Slack/Teams/PagerDuty + full immutable history)  
8. Optional Saga compensation on failure/rollback.

**Project Structure (key paths)**  
```
firstproj/
├── AGENTS.md                 # This file - ALWAYS loaded by agents
├── README.md
├── pyproject.toml
├── .claude/skills/           # Modular on-demand skills for Claude Code / compatible agents
│   ├── setup-deployment/
│   ├── workflow-development/
│   ├── ai-integration/
│   ├── observability-integration/
│   ├── security-devsecops/
│   ├── testing-debugging/
│   └── remediation-patterns/
├── src/
│   ├── workflows/            # Temporal Workflow definitions (durable business logic)
│   ├── activities/           # Atomic, retryable, versioned Activities (side-effects + AI)
│   ├── core/                 # Shared models (Pydantic), config, logging, telemetry
│   ├── api/                  # FastAPI webhook trigger server + human approval endpoints
│   ├── utils/                # PromQL helpers, LLM client wrapper, K8s client
│   └── worker.py             # Temporal Worker entrypoint (multi-activity registration)
├── deploy/
│   ├── k8s/                  # Manifests / Helm values for Temporal, Workers, Observability
│   └── docker/               # Dockerfiles for worker, api, etc.
├── configs/                  # prometheus.yml, grafana dashboards (provisioning), temporal config
├── scripts/                  # setup.sh, generate-dashboard.py, etc.
├── tests/                    # pytest + Temporal time-skipping tests
└── docs/                     # Architecture diagrams, runbooks, KPI dashboards
```

## Coding Standards & Conventions (Strict)

1. **Every Workflow and Activity must be in its own file** under `src/workflows/` and `src/activities/`.  
2. Use **Pydantic v2** models for all inputs/outputs, especially AI structured responses and Workflow state.  
3. **Type hints everywhere** + `async` for I/O-bound Activities (Prometheus queries, LLM calls, HTTP). Sync OK for CPU/K8s client if wrapped.  
4. **Structured logging** with `structlog` + correlation IDs from Temporal context (`workflow.logger`). Never use print().  
5. **OpenTelemetry instrumentation** on all Activities and external calls (auto-instrument where possible).  
6. **Retries**: Define custom `RetryPolicy` with exponential backoff in Workflow. Never rely on default for production.  
7. **Compensation / Saga**: Every mutating Activity that can fail after partial progress must have a compensating Activity registered via `workflow.set_signal_handler` or explicit compensation workflow.  
8. **Versioning**: Use Workflow versioning (`workflow.get_version`) or ContinueAsNew for long-running / evolving logic. Never break existing executions.  
9. **Security**: All external actions (kubectl, cloud APIs) run inside Activities with least-privilege ServiceAccounts / IAM roles. No credentials in code. Use `os.environ` + K8s secrets projected as files or env.  
10. **AI Prompts**: Store system prompts + few-shot examples in `src/core/prompts/`. Use Pydantic for output validation. Log full prompt + response + token usage for audit + cost tracking.  
11. **Idempotency**: All Activities must be idempotent or safely retryable (use unique IDs, check-before-act where possible).  
12. **Testing**: Every new Workflow/Activity requires a corresponding test in `tests/` using `temporalio.testing` + time-skipping for timers.  
13. **Observability first**: Emit custom Prometheus metrics from Workflow (via activity or interceptor) for executions, decisions, remediation success rate, AI confidence distribution.

## Development Workflow (for AI Agents & Humans)

**When adding a new remediation capability** (e.g. certificate rotation, pod restart policy, security patch):  
1. Read `AGENTS.md` + relevant `.claude/skills/` (especially `workflow-development`, `remediation-patterns`, `ai-integration`).  
2. Define Pydantic models in `src/core/models.py` (or new file).  
3. Implement Activities in `src/activities/` (one file per logical action).  
4. Compose in a new Workflow under `src/workflows/`.  
5. Add to Worker registration.  
6. Write time-skipping test.  
7. Update Grafana dashboard + Prometheus alert rules if new metrics.  
8. Document in `docs/` and add example to `remediation-patterns` skill if reusable pattern.

**Local Development**  
```bash
# 1. Start Temporal dev server (recommended)
temporal server start-dev --ui-port 8233 --port 7233

# 2. (Optional) Start full docker-compose stack
docker compose -f deploy/docker/docker-compose.yml up -d

# 3. Install deps (uv recommended)
uv sync

# 4. Run worker
python -m src.worker

# 5. Run trigger API (for webhook testing)
uvicorn src.api.main:app --reload --port 8000

# 6. Trigger via curl or Grafana webhook
```

**Deployment**  
See `.claude/skills/setup-deployment/SKILL.md` and `deploy/k8s/` READMEs. Start with Temporal Cloud for speed, then migrate to self-hosted Helm.

**Key Temporal Primitives to Master**  
- `workflow.execute_activity` with `start_to_close_timeout`, `retry_policy`  
- `workflow.wait_for_signal` / `workflow.signal` for human-in-loop  
- `workflow.query` for real-time status dashboards  
- `workflow.continue_as_new` for very long / evolving workflows  
- `workflow.set_signal_handler` + compensation logic  
- OpenTelemetry interceptors on Worker + Workflow

**AI Durability Pattern**  
Store full conversation history + intermediate decisions as Workflow state (Pydantic model). On resume after crash, LLM continues from last known good state. Never store API keys or secrets in Workflow history.

**KPI Tracking (must be implemented)**  
- Workflow execution count / success / failure rate (Temporal metrics + custom)  
- Auto-remediation success %  
- Average time from alert to close  
- AI decision confidence vs actual outcome (feedback loop)  
- Toil hours saved (manual vs automated)  
All exposed in Grafana + exported for executive dashboards.

**Security & Compliance Notes**  
- Immutable replayable history = perfect audit trail for SOC2, ISO, FedRAMP.  
- All sensitive actions require explicit `ExecuteRemediation` Activity with policy checks.  
- Use mTLS between Temporal components and Workers.  
- Version all Workflows; test upgrades with `temporal workflow reset`.

This file is the single source of truth for project conventions. Update it when architecture or standards evolve. All agents and developers must follow it.

**References**  
- Original design: `myfirst.md` (attached in conversation history)  
- Temporal docs: https://docs.temporal.io/  
- Temporal Python SDK examples + testing guide  
- Agent Skills standard: https://agentskills.io
