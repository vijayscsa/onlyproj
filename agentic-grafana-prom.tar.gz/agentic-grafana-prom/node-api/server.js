const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 8036;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
    res.json({ message: 'Node API for Agentic Grafana Integration Running' });
});

app.get('/health', (req, res) => {
    res.json({ status: 'healthy', timestamp: new Date() });
});

app.get('/config/dashboards', (req, res) => {
    res.json({
        dashboards: [
            { uid: 'rtf-ab-prod-metrics', url: 'https://sandpit.metrics.cba/d/rtf-ab-prod-metrics' },
            { uid: 'fed8aoc4eqiv4b', url: 'https://sandpit.metrics.cba/d/fed8aoc4eqiv4b' }
        ]
    });
});

app.listen(PORT, () => {
    console.log(`🚀 Node API running on http://localhost:${PORT}`);
});
