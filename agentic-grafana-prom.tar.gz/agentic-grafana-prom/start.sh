#!/bin/bash
set -e

# Configuration
PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$PROJECT_ROOT/backend"
FRONTEND_DIR="$PROJECT_ROOT/frontend"
NODE_API_DIR="$PROJECT_ROOT/node-api"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}Starting Agentic Grafana Assistant...${NC}"

# 1. Setup Backend
echo -e "${GREEN}1. Setting up Python Backend (Port 8031)...${NC}"
cd "$BACKEND_DIR"
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "Created venv"
fi
source venv/bin/activate
pip install -r requirements.txt --quiet
# Run in background
nohup uvicorn app.main:app --host 0.0.0.0 --port 8031 --reload > backend.log 2>&1 &
BACKEND_PID=$!
echo "Backend running (PID: $BACKEND_PID)"

# 2. Setup Node API
echo -e "${GREEN}2. Setting up Node API (Port 8036)...${NC}"
cd "$NODE_API_DIR"
if [ ! -d "node_modules" ]; then
    npm install --silent
fi
nohup node server.js > node_api.log 2>&1 &
NODE_API_PID=$!
echo "Node API running (PID: $NODE_API_PID)"

# 3. Setup Frontend
echo -e "${GREEN}3. Setting up Frontend (Port 3031)...${NC}"
cd "$FRONTEND_DIR"
if [ ! -d "node_modules" ]; then
    npm install --silent
fi
nohup npm run dev > frontend.log 2>&1 &
FRONTEND_PID=$!
echo "Frontend running (PID: $FRONTEND_PID)"

echo -e "${BLUE}=======================================${NC}"
echo -e "${GREEN}✅ All services started!${NC}"
echo -e "Frontend UI:  http://localhost:3031"
echo -e "Backend API:  http://localhost:8031"
echo -e "Node API:     http://localhost:8036"
echo -e "${BLUE}=======================================${NC}"
echo "Logs are in respective directories (backend.log, frontend.log, node_api.log)"
echo "To stop: kill $BACKEND_PID $NODE_API_PID $FRONTEND_PID"

# Keep script running to maintain PIDs (optional, but good for tracking)
wait
