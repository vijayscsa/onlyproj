/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
        "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
        "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    ],
    theme: {
        extend: {
            colors: {
                'grafana-dark': '#111217',
                'grafana-panel': '#181b1f',
                'grafana-blue': '#225ed8',
            },
        },
    },
    plugins: [],
};
