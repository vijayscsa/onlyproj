import Chat from '@/components/Chat';

export default function Home() {
    return (
        <main className="h-screen w-full bg-[#111217]">
            <Chat />
        </main>
    );
}
