/** @type {import('next').NextConfig} */
const nextConfig = {
    // No special config for now
}

module.exports = nextConfig
