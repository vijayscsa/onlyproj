# Agentic Grafana Assistant

This application provides an AI-powered Chat interface to interact with your specific Grafana dashboards and Kubernetes metrics.

## Features
- **Natural Language Query**: Ask "How is RTF AB Prod Metrics performing?"
- **Backend Agent (Python/FastAPI)**: Handles complex logic, connects to Grafana/Prometheus simulated MCP tools, and uses LangChain with CBA GenAI.
- **Frontend (Next.js)**: Modern Chat UI with Markdown support.
- **Node API**: Compliance/Integration service.

## Setup

1. **Extract**:
   ```bash
   tar -xzf agentic-grafana-prom.tar.gz
   cd agentic-grafana-prom
   ```

2. **Configure Environment**:
   Copy `backend/.env.example` to `backend/.env` and update:
   - `OPENAI_API_KEY`: Your CBA GenAI Key.
   - `GRAFANA_USER` / `GRAFANA_PASSWORD`: Your credentials.

3. **Run**:
   ```bash
   chmod +x start.sh
   ./start.sh
   ```

## Services
- **Frontend UI**: http://localhost:3031
- **Backend API**: http://localhost:8031/docs
- **Node API**: http://localhost:8036

## Architecture
- **Frontend**: Next.js 14, React, Tailwind, Axios.
- **Backend**: FastAPI, LangChain, OpenAI (CBA GenAI Endpoint).
- **LLM**: Claude 3.5 Sonnet (via Bedrock/CBA).
