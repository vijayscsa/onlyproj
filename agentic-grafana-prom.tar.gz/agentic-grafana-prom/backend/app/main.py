from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import os
import uvicorn
from contextlib import asynccontextmanager
from dotenv import load_dotenv

# Import components (we'll implement next)
from app.agent.grafana_agent import GrafanaAgent

# Load environment variables
load_dotenv()

# Global Agent instance
agent_instance = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global agent_instance
    print("🚀 Initializing Grafana Agent...")
    try:
        agent_instance = GrafanaAgent()
        print("✅ Grafana Agent initialized successfully")
    except Exception as e:
        print(f"❌ Failed to initialize Agent: {e}")
    yield
    print("🛑 Shutting down Grafana Agent...")


app = FastAPI(
    title="AgenticAI Grafana Assistant",
    description="Backend API for querying Kubernetes platform metrics via Grafana/Prometheus",
    version="1.0.0",
    lifespan=lifespan
)

# CORS (allow frontend)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = "default"


class ChatResponse(BaseModel):
    response: str
    conversation_id: str
    tools_used: List[str] = []


@app.get("/")
async def root():
    return {"status": "Agentic Grafana API is running"}


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    if not agent_instance:
        raise HTTPException(status_code=503, detail="Agent not initialized")
    
    try:
        result = await agent_instance.atext_query(request.message, request.conversation_id)
        return ChatResponse(
            response=result.get("output", "No response generated"),
            conversation_id=request.conversation_id,
            tools_used=result.get("tools_used", []) 
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health_check():
    return {"status": "ok"}


if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8031, reload=True)
