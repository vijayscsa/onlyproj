#!/bin/bash
# Stop all AIOps services
echo "Stopping AIOps services..."
kill $(lsof -t -i:8006) 2>/dev/null && echo "  Stopped backend (port 8006)" || echo "  Backend not running"
kill $(lsof -t -i:3001) 2>/dev/null && echo "  Stopped frontend (port 3001)" || echo "  Frontend not running"
echo "Done."
