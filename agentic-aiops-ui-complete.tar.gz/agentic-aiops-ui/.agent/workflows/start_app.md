---
description: Start the full AIOps application stack (Backend + Frontend)
---

This workflow starts both the Python backend agent service and the React frontend development server.

## Prerequisites

- Python 3.10+
- Node.js 18+
- Active virtual environment (optional but recommended)

## 1. Start the Backend Service

The backend handles the AI agent logic and PagerDuty integration.

```bash
# Navigate to backend directory
cd /home/ravinv1/.gemini/antigravity/scratch/agentic-aiops-ui/backend/python-agent

# Install dependencies if needed
pip install -r requirements.txt || pip install fastapi uvicorn[standard] python-dotenv langchain langchain-openai httpx starlette websockets pydantic python-multipart

# Start the server (runs on port 8006)
# Note: If API keys are missing, it will start in MOCK MODE
// turbo
python3 main.py
```

## 2. Start the Frontend Application

The frontend provides the dashboard and chat interface.

```bash
# Navigate to frontend directory
cd /home/ravinv1/.gemini/antigravity/scratch/agentic-aiops-ui/frontend

# Install dependencies if needed
npm install

# Start the development server (runs on port 3001)
// turbo
npm run dev
```

## 3. Access the Application

- **Frontend UI:** http://localhost:3001
- **Backend API:** http://localhost:8006/docs
- **Health Check:** http://localhost:8006/health
