#!/bin/bash
# =============================================================
#  AIOps Agentic UI - Complete Startup Script
#  Run this after extracting the tar.gz archive
# =============================================================
set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$PROJECT_DIR/backend/python-agent"
FRONTEND_DIR="$PROJECT_DIR/frontend"

echo "=================================================="
echo "  AIOps Agentic UI - Startup Script"
echo "=================================================="
echo ""
echo "Project directory: $PROJECT_DIR"
echo ""

# ----------------------------------------------------------
# Step 1: Kill any existing processes on ports 8006 and 3001
# ----------------------------------------------------------
echo "🔄 Step 1: Cleaning up old processes..."
kill $(lsof -t -i:8006) 2>/dev/null && echo "  Killed process on port 8006" || echo "  Port 8006 is free"
kill $(lsof -t -i:3001) 2>/dev/null && echo "  Killed process on port 3001" || echo "  Port 3001 is free"
sleep 1

# ----------------------------------------------------------
# Step 2: Install Python dependencies
# ----------------------------------------------------------
echo ""
echo "📦 Step 2: Installing Python dependencies..."
cd "$BACKEND_DIR"
pip install -r requirements.txt --quiet
echo "  ✅ Python dependencies installed"

# ----------------------------------------------------------
# Step 3: Install Frontend dependencies
# ----------------------------------------------------------
echo ""
echo "📦 Step 3: Installing Frontend dependencies..."
cd "$FRONTEND_DIR"
npm install --silent 2>/dev/null
echo "  ✅ Frontend dependencies installed"

# ----------------------------------------------------------
# Step 4: Start Backend (port 8006)
# ----------------------------------------------------------
echo ""
echo "🚀 Step 4: Starting Backend on port 8006..."
cd "$BACKEND_DIR"
nohup python3 main.py > "$BACKEND_DIR/backend.log" 2>&1 &
BACKEND_PID=$!
echo "  Backend PID: $BACKEND_PID"

# Wait for backend to initialize
echo "  Waiting for backend to start..."
for i in {1..10}; do
    if curl -s http://localhost:8006/health > /dev/null 2>&1; then
        echo "  ✅ Backend is healthy!"
        break
    fi
    if [ $i -eq 10 ]; then
        echo "  ❌ Backend failed to start. Check $BACKEND_DIR/backend.log"
        cat "$BACKEND_DIR/backend.log"
        exit 1
    fi
    sleep 1
done

# Verify stats endpoint
echo "  Testing stats endpoint..."
STATS=$(curl -s http://localhost:8006/api/incidents/stats/summary)
echo "  Stats response: $STATS"

# ----------------------------------------------------------
# Step 5: Start Frontend (port 3001)
# ----------------------------------------------------------
echo ""
echo "🚀 Step 5: Starting Frontend on port 3001..."
cd "$FRONTEND_DIR"
nohup npm run dev > "$FRONTEND_DIR/frontend.log" 2>&1 &
FRONTEND_PID=$!
echo "  Frontend PID: $FRONTEND_PID"
sleep 3

# ----------------------------------------------------------
# Summary
# ----------------------------------------------------------
echo ""
echo "=================================================="
echo "  ✅ All services started successfully!"
echo "=================================================="
echo ""
echo "  🌐 Frontend UI:    http://localhost:3001"
echo "  🔧 Backend API:    http://localhost:8006"
echo "  📊 API Docs:       http://localhost:8006/docs"
echo "  ❤️  Health Check:   http://localhost:8006/health"
echo "  📈 Stats:          http://localhost:8006/api/incidents/stats/summary"
echo ""
echo "  Backend PID:  $BACKEND_PID  (log: $BACKEND_DIR/backend.log)"
echo "  Frontend PID: $FRONTEND_PID (log: $FRONTEND_DIR/frontend.log)"
echo ""
echo "  To stop all services:"
echo "    kill $BACKEND_PID $FRONTEND_PID"
echo "    # or: kill \$(lsof -t -i:8006) \$(lsof -t -i:3001)"
echo ""
echo "  ⚠️  Running in MOCK MODE (simulated data)."
echo "  To use real data, set these before running:"
echo "    export PAGERDUTY_USER_API_KEY='your-key'"
echo "    export OPENAI_API_KEY='your-key'"
echo "=================================================="
