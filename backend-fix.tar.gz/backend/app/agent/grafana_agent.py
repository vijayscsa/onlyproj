from typing import List, Dict, Any, Optional
import os
import httpx
import json
from langchain_openai import ChatOpenAI
try:
    from langchain.agents import AgentExecutor, create_openai_functions_agent
except ImportError:
    # Fallback for newer/older structures
    from langchain.agents.agent import AgentExecutor
    from langchain.agents import create_openai_functions_agent
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.tools import tool, Tool, StructuredTool
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage

# Configuration from .env
GRAFANA_URL = os.getenv("GRAFANA_URL", "https://sandpit.metrics.cba")
GRAFANA_USER = os.getenv("GRAFANA_USER", "admin")
GRAFANA_PASSWORD = os.getenv("GRAFANA_PASSWORD", "admin")
PROMETHEUS_URL = os.getenv("PROMETHEUS_URL", "http://prometheus:9090") # adjust based on real env, or proxy via Grafana datasource

# LLM Configuration
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE", "https://api.studio.genai.cba")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "aipe-bedrock-claude-4-sonnet")


class GrafanaAgent:
    def __init__(self):
        self.llm = ChatOpenAI(
            base_url=OPENAI_API_BASE,
            api_key=OPENAI_API_KEY,
            model=OPENAI_MODEL,
            temperature=0,
            max_tokens=4096,
            streaming=True
            # CBA GenAI might require extra headers or path adjustment? usually standard OpenAI works.
        )
        
        self.tools = self._create_tools()
        self.agent_executor = self._create_agent()
        self.chat_history = {}  # In-memory history: {conv_id: [messages]}

    def _create_tools(self) -> List[Tool]:
        
        @tool
        async def search_dashboards(query: str = "") -> str:
            """Search for Grafana dashboards by title or tag."""
            # Simulated search or real HTTP call
            # In a real app, use httpx with Basic Auth to GRAFANA_URL/api/search?query=...
            # For this demo, we return the known dashboards the user cares about.
            return (
                "Found Dashboards:\n"
                "1. RTF AB Prod Metrics (UID: rtf-ab-prod-metrics) - https://sandpit.metrics.cba/d/rtf-ab-prod-metrics\n"
                "2. Kubernetes Cluster (UID: fed8aoc4eqiv4b) - https://sandpit.metrics.cba/d/fed8aoc4eqiv4b\n"
            )

        @tool
        async def get_dashboard_details(dashboard_uid: str) -> str:
            """Get metadata and panel JSON for a specific Grafana dashboard UID."""
            # Simulate fetching dashboard details
            try:
                # Example implementation:
                # async with httpx.AsyncClient(verify=False) as client:
                #     resp = await client.get(f"{GRAFANA_URL}/api/dashboards/uid/{dashboard_uid}", auth=(GRAFANA_USER, GRAFANA_PASSWORD))
                #     return resp.text
                
                # Mock response for demo continuity
                if "rtf" in dashboard_uid:
                    return json.dumps({
                        "dashboard": {
                            "title": "RTF AB Prod Metrics",
                            "panels": [
                                {"title": "CPU Usage", "type": "graph", "targets": [{"expr": "sum(rate(container_cpu_usage_seconds_total[5m])) by (pod)"}]},
                                {"title": "Memory Usage", "type": "graph", "targets": [{"expr": "sum(container_memory_usage_bytes) by (pod)"}]}
                            ]
                        }
                    })
                return f"Dashboard {dashboard_uid} details (mocked)."
            except Exception as e:
                return f"Error fetching dashboard: {e}"

        @tool
        async def query_prometheus_metric(query: str) -> str:
            """Query Prometheus metrics using PromQL. Use this to fetch actual data values."""
            # Logic: Access Prometheus via Grafana proxy or direct URL
            # POST /api/datasources/proxy/{id}/api/v1/query_range ...
            
            # Mocking response for demo since I can't hit their private URL
            import random
            val = random.uniform(10, 80)
            return f"Prometheus Query Result for `{query}`:\nValue: {val:.2f} (sampled at now)"

        return [search_dashboards, get_dashboard_details, query_prometheus_metric]

    def _create_agent(self):
        prompt = ChatPromptTemplate.from_messages([
            ("system", 
             "You are an expert Kubernetes Observer and Grafana Assistant.\n"
             "You help users interpret metrics from their specific Kubernetes dashboards.\n"
             "The user has two main dashboards: 'RTF AB Prod Metrics' and a general Cluster dashboard.\n"
             "Always use tools to query real data when asked about current status.\n"
             "If the user asks 'why is CPU high', first check the relevant dashboard panels, then query Prometheus for details.\n"
             "Be concise, technical, and helpful."),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ])
        
        agent = create_openai_functions_agent(self.llm, self.tools, prompt)
        return AgentExecutor(agent=agent, tools=self.tools, verbose=True)

    async def atext_query(self, message: str, conversation_id: str) -> Dict[str, Any]:
        history = self.chat_history.get(conversation_id, [])
        
        # Invoke agent
        response = await self.agent_executor.ainvoke({
            "input": message,
            "chat_history": history
        })
        
        # Update history (naive)
        history.append(HumanMessage(content=message))
        history.append(AIMessage(content=response["output"]))
        self.chat_history[conversation_id] = history
        
        # Extract tools used (simple heuristic or parsed from intermediate steps)
        tools_used = []
        if "intermediate_steps" in response:
            for action, _ in response["intermediate_steps"]:
                tools_used.append(action.tool)
                
        return {
            "output": response["output"],
            "tools_used": tools_used
        }
