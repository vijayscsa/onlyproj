"use client";

import { useState, useEffect, useRef } from "react";
import axios from "axios";
import { Send, Bot, User, Activity, Search, Server, RefreshCw } from "lucide-react";
import ReactMarkdown from "react-markdown";

type Message = {
    role: "user" | "assistant";
    content: string;
    tools?: string[];
    timestamp: Date;
};

export default function Chat() {
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState("");
    const [loading, setLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        setMessages([
            {
                role: "assistant",
                content: "Hello! I am your AgenticAI Grafana Assistant. Ask me about your Kubernetes metrics or dashboards.",
                timestamp: new Date(),
            },
        ]);
    }, []);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || loading) return;

        const userMsg: Message = {
            role: "user",
            content: input,
            timestamp: new Date(),
        };
        setMessages((prev) => [...prev, userMsg]);
        setInput("");
        setLoading(true);

        try {
            // Direct call to Backend API (running on port 8031)
            const res = await axios.post("http://localhost:8031/api/chat", {
                message: userMsg.content,
                conversation_id: "default",
            });

            const aiMsg: Message = {
                role: "assistant",
                content: res.data.response,
                tools: res.data.tools_used,
                timestamp: new Date(),
            };
            setMessages((prev) => [...prev, aiMsg]);
        } catch (error) {
            console.error("Error:", error);
            const errorMsg: Message = {
                role: "assistant",
                content: "⚠️ Sorry, I encountered an error connecting to the agent backend.",
                timestamp: new Date(),
            };
            setMessages((prev) => [...prev, errorMsg]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-screen bg-[#111217] text-gray-200 font-sans">
            {/* Header */}
            <header className="flex items-center justify-between px-6 py-4 bg-[#181b1f] border-b border-gray-800 shadow-md">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-600 rounded-lg shadow-lg shadow-blue-900/20">
                        <Activity className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-lg font-bold text-white tracking-tight">AgenticAI Grafana Assistant</h1>
                        <p className="text-xs text-gray-400 flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                            Connected to Platform Metrics
                        </p>
                    </div>
                </div>
            </header>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
                {messages.map((msg, idx) => (
                    <div
                        key={idx}
                        className={`flex w-full ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                        <div
                            className={`flex max-w-[85%] rounded-2xl p-5 shadow-sm ${msg.role === "user"
                                ? "bg-blue-600 text-white rounded-br-none"
                                : "bg-[#22252b] border border-gray-800 rounded-bl-none" // Grafana panel style
                                }`}
                        >
                            <div className="flex flex-col gap-2 w-full">
                                {/* Name/Icon Header */}
                                <div className="flex items-center gap-2 mb-1 opacity-70 text-xs font-medium uppercase tracking-wider">
                                    {msg.role === "assistant" ? (
                                        <>
                                            <Bot className="w-3 h-3" /> Agentic AI
                                        </>
                                    ) : (
                                        <>
                                            You <User className="w-3 h-3" />
                                        </>
                                    )}
                                </div>

                                {/* Message Content */}
                                <div className="prose prose-invert prose-sm max-w-none leading-relaxed">
                                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                                </div>

                                {/* Tools Used Badge */}
                                {msg.tools && msg.tools.length > 0 && (
                                    <div className="mt-3 pt-3 border-t border-gray-700/50 flex flex-wrap gap-2">
                                        {msg.tools.map((tool, i) => (
                                            <span
                                                key={i}
                                                className="inline-flex items-center gap-1 px-2 py-1 text-[10px] font-mono font-semibold text-blue-300 bg-blue-900/30 rounded border border-blue-800/50"
                                            >
                                                {tool.includes("prometheus") ? <Activity className="w-3 h-3" /> : <Search className="w-3 h-3" />}
                                                {tool}
                                            </span>
                                        ))}
                                    </div>
                                )}

                                <span className="text-[10px] opacity-40 self-end mt-1">
                                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                            </div>
                        </div>
                    </div>
                ))}

                {loading && (
                    <div className="flex justify-start w-full animate-pulse">
                        <div className="bg-[#22252b] border border-gray-800 rounded-2xl rounded-bl-none p-4 flex items-center gap-3">
                            <RefreshCw className="w-4 h-4 animate-spin text-blue-400" />
                            <span className="text-sm text-gray-400">Analyzing metrics...</span>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-4 bg-[#181b1f] border-t border-gray-800">
                <form onSubmit={handleSubmit} className="max-w-4xl mx-auto relative flex items-center gap-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Ask about cluster health, CPU usage, or dashboard anomalies..."
                        className="w-full bg-[#111217] text-white border border-gray-700 rounded-xl px-4 py-3 pr-12 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all placeholder-gray-500 shadow-inner"
                        disabled={loading}
                    />
                    <button
                        type="submit"
                        disabled={!input.trim() || loading}
                        className="absolute right-2 p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-lg shadow-blue-900/20"
                    >
                        <Send className="w-4 h-4" />
                    </button>
                </form>
                <p className="text-center text-xs text-gray-600 mt-2">
                    Powered by LLM & Grafana/Prometheus MCP
                </p>
            </div>
        </div>
    );
}
