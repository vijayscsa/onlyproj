from typing import List, Dict, Any, Optional
import os
import httpx
import json
import traceback
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.tools import tool, Tool, StructuredTool
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage

# Explicitly load .env from the backend directory
backend_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
env_path = os.path.join(backend_dir, ".env")
load_dotenv(env_path)

# Configuration from .env
GRAFANA_URL = os.getenv("GRAFANA_URL", "https://sandpit.metrics.cba")
GRAFANA_USER = os.getenv("GRAFANA_USER", "admin")
GRAFANA_PASSWORD = os.getenv("GRAFANA_PASSWORD", "admin")
PROMETHEUS_URL = os.getenv("PROMETHEUS_URL", "http://prometheus:9090") 

# LLM Configuration
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE", "https://api.studio.genai.cba")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "dummy-key-if-none") 
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "aipe-bedrock-claude-4-sonnet")

class GrafanaAgent:
    def __init__(self):
        print(f"🔌 CONFIG CHECK:")
        print(f"   - URL: {OPENAI_API_BASE}")
        print(f"   - Model: {OPENAI_MODEL}")
        print(f"   - Key: {OPENAI_API_KEY[:5]}...{OPENAI_API_KEY[-4:] if len(OPENAI_API_KEY)>10 else ''}")
        print(f"   - Env Path: {env_path}")
        
        # Create a custom HTTP client that ignores SSL errors (Fix for Corporate Proxies)
        http_client = httpx.Client(verify=False, timeout=60.0)
        
        self.llm = ChatOpenAI(
            base_url=OPENAI_API_BASE,
            api_key=OPENAI_API_KEY,
            model=OPENAI_MODEL,
            temperature=0,
            max_tokens=4096,
            streaming=True,
            http_client=http_client  # Inject custom client
        )
        
        self.tools = self._create_tools()
        self.agent_executor = self._create_agent()
        self.chat_history = {}

    def _create_tools(self) -> List[Tool]:
        
        @tool
        async def search_dashboards(query: str = "") -> str:
            """Search for Grafana dashboards by title or tag."""
            return (
                "Found Dashboards:\n"
                "1. RTF AB Prod Metrics (UID: rtf-ab-prod-metrics) - https://sandpit.metrics.cba/d/rtf-ab-prod-metrics\n"
                "2. Kubernetes Cluster (UID: fed8aoc4eqiv4b) - https://sandpit.metrics.cba/d/fed8aoc4eqiv4b\n"
            )

        @tool
        async def get_dashboard_details(dashboard_uid: str) -> str:
            """Get metadata and panel JSON for a specific Grafana dashboard UID."""
            if "rtf" in dashboard_uid:
                return json.dumps({
                    "dashboard": {
                        "title": "RTF AB Prod Metrics",
                        "panels": [
                            {"title": "CPU Usage", "type": "graph", "targets": [{"expr": "sum(rate(container_cpu_usage_seconds_total[5m])) by (pod)"}]},
                            {"title": "Memory Usage", "type": "graph", "targets": [{"expr": "sum(container_memory_usage_bytes) by (pod)"}]}
                        ]
                    }
                })
            return f"Dashboard {dashboard_uid} details (mocked for demo)."

        @tool
        async def query_prometheus_metric(query: str) -> str:
            """Query Prometheus metrics using PromQL."""
            import random
            val = random.uniform(10, 80)
            return f"Prometheus Query Result for `{query}`:\nValue: {val:.2f} (sampled at now)"

        return [search_dashboards, get_dashboard_details, query_prometheus_metric]

    def _create_agent(self):
        prompt = ChatPromptTemplate.from_messages([
            ("system", 
             "You are an expert Kubernetes Observer and Grafana Assistant.\n"
             "You help users interpret metrics from their specific Kubernetes dashboards.\n"
             "The user has two main dashboards: 'RTF AB Prod Metrics' and a general Cluster dashboard.\n"
             "Always use tools to query real data when asked about current status.\n"
             "Be concise, technical, and helpful."),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ])
        
        # USE NEW tool_calling_agent
        agent = create_tool_calling_agent(self.llm, self.tools, prompt)
        return AgentExecutor(agent=agent, tools=self.tools, verbose=True, handle_parsing_errors=True)

    async def atext_query(self, message: str, conversation_id: str) -> Dict[str, Any]:
        try:
            history = self.chat_history.get(conversation_id, [])
            
            print(f"🤖 Invoking Agent with: {message}")
            response = await self.agent_executor.ainvoke({
                "input": message,
                "chat_history": history
            })
            
            output = response["output"]
            history.append(HumanMessage(content=message))
            history.append(AIMessage(content=output))
            self.chat_history[conversation_id] = history
            
            tools_used = []
            if "intermediate_steps" in response:
                for action, _ in response["intermediate_steps"]:
                    tools_used.append(action.tool)
                    
            return {
                "output": output,
                "tools_used": tools_used
            }
        except Exception as e:
            error_trace = traceback.format_exc()
            print(f"❌ AGENT ERROR:\n{error_trace}")
            return {
                "output": f"Error interacting with Agent: {str(e)}. Please check backend logs.",
                "tools_used": []
            }
